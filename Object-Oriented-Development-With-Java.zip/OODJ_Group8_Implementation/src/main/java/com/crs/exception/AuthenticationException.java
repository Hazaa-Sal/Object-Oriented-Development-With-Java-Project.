/*
 * Authentication Exception for CRS Application
 */
package com.crs.exception;

/**
 * Thrown when authentication fails (invalid credentials, deactivated account,
 * etc.)
 */
public class AuthenticationException extends CRSException {

    public AuthenticationException(String message) {
        super(message);
    }

    public AuthenticationException(String message, Throwable cause) {
        super(message, cause);
    }
}
