/*
 * Custom Exceptions for CRS Application
 * Demonstrates proper exception hierarchy for OOP requirements
 */
package com.crs.exception;

/**
 * Base exception for all CRS-related errors
 * Provides a common parent for domain-specific exceptions
 */
public class CRSException extends Exception {

    public CRSException(String message) {
        super(message);
    }

    public CRSException(String message, Throwable cause) {
        super(message, cause);
    }
}
