/*
 * Eligibility Exception for CRS Application
 */
package com.crs.exception;

/**
 * Thrown when eligibility check fails or student is ineligible
 */
public class EligibilityException extends CRSException {

    private double cgpa;
    private int failedCourses;

    public EligibilityException(String message) {
        super(message);
    }

    public EligibilityException(String message, double cgpa, int failedCourses) {
        super(message);
        this.cgpa = cgpa;
        this.failedCourses = failedCourses;
    }

    public double getCgpa() {
        return cgpa;
    }

    public int getFailedCourses() {
        return failedCourses;
    }
}
