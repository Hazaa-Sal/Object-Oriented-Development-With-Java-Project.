/*
 * Recovery Exception for CRS Application
 */
package com.crs.exception;

/**
 * Thrown when recovery operations fail (max attempts exceeded, invalid state,
 * etc.)
 */
public class RecoveryException extends CRSException {

    private int attemptNumber;

    public RecoveryException(String message) {
        super(message);
        this.attemptNumber = 0;
    }

    public RecoveryException(String message, int attemptNumber) {
        super(message);
        this.attemptNumber = attemptNumber;
    }

    public RecoveryException(String message, Throwable cause) {
        super(message, cause);
    }

    public int getAttemptNumber() {
        return attemptNumber;
    }
}
