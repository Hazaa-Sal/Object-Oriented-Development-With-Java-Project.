/*
 * Enhanced Course Recovery Panel
 * Full GUI implementation for recovery plan management
 * 
 * PERMISSION GUARD: Only ACADEMIC_OFFICER can access this panel
 * Course Admin is explicitly BLOCKED from Course Recovery
 */
package com.crs.gui;

import com.crs.model.Student;
import com.crs.model.Component;
import com.crs.model.Milestone;
import com.crs.model.Recommendation;
import com.crs.model.RecoveryRecord;
import com.crs.service.*;
import com.crs.strategy.*;
import com.crs.exception.RecoveryException;
import com.crs.util.RecoveryDataHandler;

// Email service for notifications
import crs.EmailService;

// Permission imports
import crs.CurrentSession;
import crs.User;
import crs.PermissionService;
import crs.UnauthorizedActionException;

import javax.swing.*;
import javax.swing.table.*;
import java.awt.*;
import java.util.List;
import java.util.HashMap;
import java.util.Map;

/**
 * Enhanced Course Recovery Panel with:
 * - Full 1st/2nd/3rd attempt UI
 * - Strategy pattern visualization
 * - File persistence integration
 * 
 * PERMISSION: Requires COURSE_RECOVERY module access
 * BLOCKED ROLES: COURSE_ADMIN
 */
public class CourseRecoveryPanel extends JPanel {

    private StudentService studentService;
    private RecommendationService recommendationService;
    private RecoveryService recoveryService;
    private ReportService reportService;
    private EmailService emailService;
    private Runnable goBackCallback;

    // UI Components
    private JComboBox<String> studentCombo;
    private JTable failedComponentsTable;
    private DefaultTableModel tableModel;
    private JTextArea statusArea;
    private JLabel attemptInfoLabel;

    public CourseRecoveryPanel(
            StudentService studentService,
            RecommendationService recommendationService,
            RecoveryService recoveryService,
            ReportService reportService,
            EmailService emailService,
            Runnable goBackCallback) {

        // ========================================
        // PERMISSION GUARD - Defense in Depth
        // ========================================
        User currentUser = CurrentSession.getUser();

        // Check if user is logged in
        if (currentUser == null) {
            throw new UnauthorizedActionException("No user logged in - cannot access Course Recovery");
        }

        // CRITICAL: Course Admin cannot access Course Recovery
        if (currentUser.getRole() == User.Role.COURSE_ADMIN) {
            System.out.println("[SECURITY] Course Admin blocked from Course Recovery Panel");
            throw new UnauthorizedActionException(currentUser, "Course Recovery Management");
        }

        // Verify permission via PermissionService
        PermissionService.Module requiredModule = (currentUser.getRole() == User.Role.STUDENT)
                ? PermissionService.Module.MY_RECOVERY_STATUS
                : PermissionService.Module.COURSE_RECOVERY;

        PermissionService.checkAccessOrThrow(currentUser, requiredModule);

        System.out.println("[ACCESS] " + currentUser.getName() + " (" + currentUser.getRole() +
                ") accessed Course Recovery Panel");
        // ========================================

        this.studentService = studentService;
        this.recommendationService = recommendationService;
        this.recoveryService = recoveryService;
        this.reportService = reportService;
        this.emailService = emailService;
        this.goBackCallback = goBackCallback;

        setLayout(new BorderLayout(10, 10));
        setBackground(new Color(248, 250, 252));
        setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        initializeComponents();
        loadStudents();
    }

    private void initializeComponents() {
        // Header
        add(createHeaderPanel(), BorderLayout.NORTH);

        // Main content
        add(createMainPanel(), BorderLayout.CENTER);

        // Action buttons
        add(createActionPanel(), BorderLayout.SOUTH);
    }

    private JPanel createHeaderPanel() {
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(new Color(79, 70, 229));
        header.setBorder(BorderFactory.createEmptyBorder(15, 20, 15, 20));

        JLabel title = new JLabel("📚 Course Recovery Plan Management");
        title.setFont(new Font("Segoe UI", Font.BOLD, 22));
        title.setForeground(Color.WHITE);

        JButton backBtn = new JButton("← Back");
        backBtn.setFont(new Font("Segoe UI", Font.BOLD, 12));
        backBtn.addActionListener(e -> {
            saveAllData();
            goBackCallback.run();
        });

        header.add(title, BorderLayout.WEST);
        header.add(backBtn, BorderLayout.EAST);

        return header;
    }

    private JPanel createMainPanel() {
        JPanel main = new JPanel(new BorderLayout(10, 10));
        main.setOpaque(false);

        // Top: Student selection + attempt info
        JPanel topPanel = new JPanel(new BorderLayout(10, 0));
        topPanel.setOpaque(false);

        JPanel selectPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        selectPanel.setOpaque(false);
        selectPanel.add(new JLabel("Select Student:"));

        studentCombo = new JComboBox<>();
        studentCombo.setPreferredSize(new Dimension(300, 30));
        studentCombo.addActionListener(e -> loadStudentData());
        selectPanel.add(studentCombo);

        topPanel.add(selectPanel, BorderLayout.WEST);

        // Attempt strategy info
        attemptInfoLabel = new JLabel();
        attemptInfoLabel.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        updateAttemptInfo();
        topPanel.add(attemptInfoLabel, BorderLayout.CENTER);

        main.add(topPanel, BorderLayout.NORTH);

        // Center: Failed components table
        main.add(createTablePanel(), BorderLayout.CENTER);

        // Right: Status area
        main.add(createStatusPanel(), BorderLayout.EAST);

        return main;
    }

    private JPanel createTablePanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(Color.WHITE);
        panel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(226, 232, 240)),
                BorderFactory.createEmptyBorder(10, 10, 10, 10)));

        JLabel tableTitle = new JLabel("🔴 Failed Components & Recovery Status");
        tableTitle.setFont(new Font("Segoe UI", Font.BOLD, 14));
        tableTitle.setBorder(BorderFactory.createEmptyBorder(0, 0, 10, 0));
        panel.add(tableTitle, BorderLayout.NORTH);

        String[] columns = { "Component", "Score", "Attempts", "Status", "Max Score", "Action" };
        tableModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return column == 5; // Only action column
            }
        };

        failedComponentsTable = new JTable(tableModel);
        failedComponentsTable.setRowHeight(35);
        failedComponentsTable.setFont(new Font("Segoe UI", Font.PLAIN, 12));

        // Custom header
        JTableHeader header = failedComponentsTable.getTableHeader();
        header.setBackground(new Color(79, 70, 229));
        header.setForeground(Color.WHITE);
        header.setFont(new Font("Segoe UI", Font.BOLD, 12));

        // Status column renderer
        failedComponentsTable.getColumnModel().getColumn(3).setCellRenderer(new DefaultTableCellRenderer() {
            @Override
            public java.awt.Component getTableCellRendererComponent(JTable table, Object value,
                    boolean isSelected, boolean hasFocus, int row, int column) {
                super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
                String status = value != null ? value.toString() : "";
                if (status.contains("PASSED")) {
                    setForeground(new Color(22, 163, 74));
                } else if (status.contains("EXCEEDED")) {
                    setForeground(new Color(220, 38, 38));
                } else {
                    setForeground(new Color(234, 179, 8));
                }
                setFont(new Font("Segoe UI", Font.BOLD, 11));
                return this;
            }
        });

        JScrollPane scrollPane = new JScrollPane(failedComponentsTable);
        panel.add(scrollPane, BorderLayout.CENTER);

        return panel;
    }

    private JPanel createStatusPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setPreferredSize(new Dimension(280, 0));
        panel.setBackground(Color.WHITE);
        panel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(226, 232, 240)),
                BorderFactory.createEmptyBorder(10, 10, 10, 10)));

        JLabel title = new JLabel("📋 Recovery Status Log");
        title.setFont(new Font("Segoe UI", Font.BOLD, 14));
        title.setBorder(BorderFactory.createEmptyBorder(0, 0, 10, 0));
        panel.add(title, BorderLayout.NORTH);

        statusArea = new JTextArea();
        statusArea.setEditable(false);
        statusArea.setFont(new Font("Consolas", Font.PLAIN, 11));
        statusArea.setLineWrap(true);
        statusArea.setWrapStyleWord(true);

        JScrollPane scrollPane = new JScrollPane(statusArea);
        panel.add(scrollPane, BorderLayout.CENTER);

        return panel;
    }

    private JPanel createActionPanel() {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 10));
        panel.setOpaque(false);

        JButton startRecoveryBtn = createStyledButton("🔄 Start Recovery", new Color(79, 70, 229));
        startRecoveryBtn.addActionListener(e -> startRecoveryUI());

        JButton completeRecoveryBtn = createStyledButton("✓ Complete Recovery", new Color(22, 163, 74));
        completeRecoveryBtn.addActionListener(e -> completeRecoveryUI());

        JButton addMilestoneBtn = createStyledButton("📌 Add Milestone", new Color(59, 130, 246));
        addMilestoneBtn.addActionListener(e -> addMilestoneUI());

        JButton addRecommendationBtn = createStyledButton("💡 Add Recommendation", new Color(168, 85, 247));
        addRecommendationBtn.addActionListener(e -> addRecommendationUI());

        JButton viewDetailsBtn = createStyledButton("📊 View Details", new Color(107, 114, 128));
        viewDetailsBtn.addActionListener(e -> viewStudentUI());

        JButton saveBtn = createStyledButton("💾 Save All", new Color(234, 179, 8));
        saveBtn.addActionListener(e -> {
            saveAllData();
            logStatus("All recovery data saved to files.");
        });

        // Notify Student button (teal/cyan color)
        JButton notifyStudentBtn = createStyledButton("Notify Student", new Color(20, 184, 166)); // Teal
        notifyStudentBtn.addActionListener(e -> notifyStudentUI());

        panel.add(startRecoveryBtn);
        panel.add(completeRecoveryBtn);
        panel.add(addMilestoneBtn);
        panel.add(addRecommendationBtn);
        panel.add(viewDetailsBtn);
        panel.add(saveBtn);
        panel.add(notifyStudentBtn);

        return panel;
    }

    private JButton createStyledButton(String text, Color bgColor) {
        JButton btn = new JButton(text);
        btn.setBackground(bgColor);
        btn.setForeground(Color.WHITE);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 12));
        btn.setFocusPainted(false);
        btn.setBorderPainted(false);
        btn.setPreferredSize(new Dimension(160, 35));
        return btn;
    }

    private void loadStudents() {
        studentCombo.removeAllItems();
        studentCombo.addItem("-- Select Student --");

        for (Student s : studentService.getAll()) {
            int failedCount = s.getFailedComponents().size();
            String display = s.getId() + " - " + s.getName();
            if (failedCount > 0) {
                display += " (" + failedCount + " failed)";
            }
            studentCombo.addItem(display);
        }
    }

    private void loadStudentData() {
        tableModel.setRowCount(0);

        String selected = (String) studentCombo.getSelectedItem();
        if (selected == null || selected.startsWith("--")) {
            return;
        }

        String studentId = selected.split(" - ")[0];
        Student student = studentService.getStudent(studentId);

        if (student == null)
            return;

        List<Component> failed = student.getFailedComponents();

        for (Component comp : failed) {
            int attempts = countAttempts(student, comp);
            String status = recoveryService.getRecoveryStatusMessage(student, comp);
            RecoveryStrategy strategy = recoveryService.getStrategy(attempts + 1);

            Object[] row = {
                    comp.getName(),
                    String.format("%.1f%%", comp.getScore()),
                    attempts + " of 3",
                    status,
                    attempts < 3 ? strategy.getMaxAchievableScore() + "%" : "N/A",
                    attempts < 3 ? "Start Attempt " + (attempts + 1) : "Max Reached"
            };
            tableModel.addRow(row);
        }

        if (failed.isEmpty()) {
            logStatus("Student " + student.getName() + " has no failed components.");
        } else {
            logStatus("Loaded " + failed.size() + " failed components for " + student.getName());
        }
    }

    private int countAttempts(Student student, Component comp) {
        int count = 0;
        for (RecoveryRecord r : student.getRecoveryRecords()) {
            if (r.getComponentId().equals(comp.getId())) {
                count++;
            }
        }
        return count;
    }

    private void updateAttemptInfo() {
        StringBuilder sb = new StringBuilder("<html><b>Recovery Attempts:</b><br>");
        sb.append("• 1st: Resubmit/Resit (100% max)<br>");
        sb.append("• 2nd: Resubmit/Resit (80% max)<br>");
        sb.append("• 3rd: Redo ALL (60% max)</html>");
        attemptInfoLabel.setText(sb.toString());
    }

    private void startRecoveryUI() {
        int selectedRow = failedComponentsTable.getSelectedRow();
        if (selectedRow < 0) {
            showWarning("Please select a failed component to start recovery.");
            return;
        }

        String selected = (String) studentCombo.getSelectedItem();
        if (selected == null || selected.startsWith("--")) {
            showWarning("Please select a student first.");
            return;
        }

        String studentId = selected.split(" - ")[0];
        Student student = studentService.getStudent(studentId);
        if (student == null)
            return;

        List<Component> failed = student.getFailedComponents();
        if (selectedRow >= failed.size())
            return;

        Component comp = failed.get(selectedRow);

        try {
            RecoveryRecord record = recoveryService.startRecovery(student, comp);

            logStatus("=== RECOVERY STARTED ===");
            logStatus("Component: " + comp.getName());
            logStatus("Attempt: " + record.getAttemptNumber());
            logStatus("Type: " + record.getRecoveryType());
            logStatus("Max Score: " + record.getMaxScore() + "%");
            logStatus("========================");

            loadStudentData(); // Refresh table

            JOptionPane.showMessageDialog(this,
                    "Recovery started!\n\n" +
                            "Attempt: " + record.getAttemptNumber() + " of 3\n" +
                            "Type: " + record.getAttemptDescription() + "\n" +
                            "Maximum achievable score: " + record.getMaxScore() + "%",
                    "Recovery Started",
                    JOptionPane.INFORMATION_MESSAGE);

        } catch (RecoveryException e) {
            showError("Recovery Error: " + e.getMessage());
            logStatus("ERROR: " + e.getMessage());
        }
    }

    private void completeRecoveryUI() {
        String selected = (String) studentCombo.getSelectedItem();
        if (selected == null || selected.startsWith("--")) {
            showWarning("Please select a student first.");
            return;
        }

        String studentId = selected.split(" - ")[0];
        Student student = studentService.getStudent(studentId);
        if (student == null)
            return;

        // Find in-progress recovery
        RecoveryRecord inProgress = null;
        for (RecoveryRecord r : student.getRecoveryRecords()) {
            if ("in_progress".equals(r.getStatus())) {
                inProgress = r;
                break;
            }
        }

        if (inProgress == null) {
            showWarning("No recovery in progress for this student.");
            return;
        }

        String scoreStr = JOptionPane.showInputDialog(this,
                "Enter new score for " + inProgress.getComponentId() +
                        "\n(Max: " + inProgress.getMaxScore() + "%)",
                "Complete Recovery",
                JOptionPane.QUESTION_MESSAGE);

        if (scoreStr == null)
            return;

        try {
            double newScore = Double.parseDouble(scoreStr);
            recoveryService.completeRecovery(inProgress, newScore, student);

            logStatus("=== RECOVERY COMPLETED ===");
            logStatus("New Score: " + inProgress.getNewScore() + "%");
            logStatus("Result: " + (inProgress.getNewScore() >= 50 ? "PASSED" : "STILL FAILED"));
            logStatus("==========================");

            loadStudentData();

            JOptionPane.showMessageDialog(this,
                    "Recovery completed!\n\n" +
                            "Score: " + inProgress.getNewScore() + "%\n" +
                            "Result: " + (inProgress.getNewScore() >= 50 ? "PASSED ✓" : "STILL FAILED ✗"),
                    "Recovery Complete",
                    inProgress.getNewScore() >= 50 ? JOptionPane.INFORMATION_MESSAGE : JOptionPane.WARNING_MESSAGE);

        } catch (NumberFormatException e) {
            showError("Invalid score. Please enter a number.");
        } catch (RecoveryException e) {
            showError("Error: " + e.getMessage());
        }
    }

    private void addMilestoneUI() {
        String selected = (String) studentCombo.getSelectedItem();
        if (selected == null || selected.startsWith("--")) {
            showWarning("Please select a student first.");
            return;
        }

        String studentId = selected.split(" - ")[0];
        Student student = studentService.getStudent(studentId);
        if (student == null)
            return;

        String desc = JOptionPane.showInputDialog(this, "Enter milestone description:");
        if (desc == null || desc.trim().isEmpty())
            return;

        String targetDate = JOptionPane.showInputDialog(this, "Enter target date (e.g., Week 5):");
        if (targetDate == null)
            targetDate = "TBD";

        Milestone m = new Milestone("MS-" + System.currentTimeMillis(), "Course", desc, targetDate);
        recoveryService.addMilestone(student, m);

        logStatus("Milestone added: " + desc);
        showSuccess("Milestone added successfully!");
    }

    private void addRecommendationUI() {
        String selected = (String) studentCombo.getSelectedItem();
        if (selected == null || selected.startsWith("--")) {
            showWarning("Please select a student first.");
            return;
        }

        String studentId = selected.split(" - ")[0];
        Student student = studentService.getStudent(studentId);
        if (student == null)
            return;

        String text = JOptionPane.showInputDialog(this, "Enter recommendation:");
        if (text == null || text.trim().isEmpty())
            return;

        Recommendation r = new Recommendation("REC-" + System.currentTimeMillis(), "Lecturer", studentId, "Course",
                text);
        recommendationService.addRecommendation(student, r);

        logStatus("Recommendation added: " + text);
        showSuccess("Recommendation added successfully!");
    }

    private void viewStudentUI() {
        String selected = (String) studentCombo.getSelectedItem();
        if (selected == null || selected.startsWith("--")) {
            showWarning("Please select a student first.");
            return;
        }

        String studentId = selected.split(" - ")[0];
        Student student = studentService.getStudent(studentId);
        if (student == null)
            return;

        StringBuilder sb = new StringBuilder();
        sb.append("=== STUDENT DETAILS ===\n");
        sb.append("ID: ").append(student.getId()).append("\n");
        sb.append("Name: ").append(student.getName()).append("\n");
        sb.append("Course: ").append(student.getMajor()).append("\n\n");

        sb.append("=== COMPONENTS ===\n");
        for (Component c : student.getComponents()) {
            sb.append(c.getName()).append(": ").append(String.format("%.1f%%", c.getScore()));
            sb.append(" [").append(c.isPassed() ? "PASS" : "FAIL").append("]\n");
        }

        sb.append("\n=== RECOVERY RECORDS ===\n");
        for (RecoveryRecord r : student.getRecoveryRecords()) {
            sb.append(r.toString()).append("\n");
        }

        sb.append("\n=== MILESTONES ===\n");
        for (Milestone m : student.getMilestones()) {
            sb.append(m.getDescription()).append(" [").append(m.isCompleted() ? "✓" : "○").append("]\n");
        }

        sb.append("\n=== RECOMMENDATIONS ===\n");
        for (Recommendation r : student.getRecommendations()) {
            sb.append("• ").append(r.getText()).append("\n");
        }

        JTextArea textArea = new JTextArea(sb.toString());
        textArea.setEditable(false);
        textArea.setFont(new Font("Consolas", Font.PLAIN, 12));

        JScrollPane scrollPane = new JScrollPane(textArea);
        scrollPane.setPreferredSize(new Dimension(500, 400));

        JOptionPane.showMessageDialog(this, scrollPane, "Student Details - " + student.getName(),
                JOptionPane.PLAIN_MESSAGE);
    }

    private void saveAllData() {
        // Create student map for persistence
        Map<String, Student> studentMap = new HashMap<>();
        for (Student s : studentService.getAll()) {
            studentMap.put(s.getId(), s);
        }
        RecoveryDataHandler.saveAllRecoveryData(studentMap.values());
        logStatus("All data saved successfully.");
    }

    private void logStatus(String message) {
        statusArea.append(java.time.LocalTime.now().toString().substring(0, 8) + " " + message + "\n");
        statusArea.setCaretPosition(statusArea.getDocument().getLength());
    }

    private void showWarning(String message) {
        JOptionPane.showMessageDialog(this, message, "Warning", JOptionPane.WARNING_MESSAGE);
    }

    private void showError(String message) {
        JOptionPane.showMessageDialog(this, message, "Error", JOptionPane.ERROR_MESSAGE);
    }

    private void showSuccess(String message) {
        JOptionPane.showMessageDialog(this, message, "Success", JOptionPane.INFORMATION_MESSAGE);
    }

    // ==================== NOTIFY STUDENT FEATURE ====================

    /**
     * Notify Student: Send recovery plan email with auto-generated tasks.
     * Does NOT add milestones to the UI or database.
     * Only sends the plan via email.
     */
    private void notifyStudentUI() {
        // Validate student selection
        String selected = (String) studentCombo.getSelectedItem();
        if (selected == null || selected.startsWith("--")) {
            showWarning("Please select a student first.");
            return;
        }

        // Validate component selection
        int selectedRow = failedComponentsTable.getSelectedRow();
        if (selectedRow < 0) {
            showWarning("Please select a failed component to notify about.");
            return;
        }

        String studentId = selected.split(" - ")[0];
        Student student = studentService.getStudent(studentId);
        if (student == null)
            return;

        // Get the selected component name from the table
        String componentName = (String) tableModel.getValueAt(selectedRow, 0);

        // Show simple email input dialog
        JPanel dialogPanel = new JPanel(new GridLayout(3, 1, 10, 10));
        dialogPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        
        dialogPanel.add(new JLabel("Send Eligibility Notification"));
        dialogPanel.add(new JLabel("Enter student's email address:"));
        
        JTextField emailField = new JTextField(student.getEmail() != null ? student.getEmail() : "");
        dialogPanel.add(emailField);

        int result = JOptionPane.showConfirmDialog(
                this,
                dialogPanel,
                "Notify Student",
                JOptionPane.OK_CANCEL_OPTION,
                JOptionPane.PLAIN_MESSAGE);

        if (result != JOptionPane.OK_OPTION)
            return;

        // Validate email
        String email = emailField.getText().trim();
        if (email.isEmpty() || !email.contains("@")) {
            showError("Invalid email address.");
            return;
        }

        // Send recovery plan email (auto-generated plan embedded in email)
        try {
            emailService.sendRecoveryPlanEmail(student.getName(), email, componentName);
            
            logStatus("Sent recovery plan to " + student.getName() + " for " + componentName);
            showSuccess("Recovery plan email sent to: " + email);

        } catch (Exception ex) {
            showError("Failed to send notification: " + ex.getMessage());
            logStatus("ERROR: Failed to send notification - " + ex.getMessage());
        }
    }
}
