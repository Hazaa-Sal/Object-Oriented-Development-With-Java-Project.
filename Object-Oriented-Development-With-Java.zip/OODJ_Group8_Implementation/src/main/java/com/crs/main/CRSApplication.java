package com.crs.main;

import com.crs.model.*;
import com.crs.service.*;
import com.crs.util.TxtLoader;

import java.util.List;
import java.util.Scanner;
import java.util.Collections;

public class CRSApplication {
    private static final Scanner scanner = new Scanner(System.in);
    private static final StudentService studentService = new StudentService();
    private static final FileService fileService = new FileService(studentService);
    private static final ReportService reportService = new ReportService();
    private static final RecommendationService recommendationService = new RecommendationService();
    private static final RecoveryService recoveryService = new RecoveryService();

    public static void main(String[] args) {
        System.out.println("CRSApplication starting...");

        // Using files in project root folder
        String studentsTxt = "student_information (1).txt";
        String gradesTxt = "course_assessment_with_grades.txt";

        fileService.loadStudentsTxt(studentsTxt);
        fileService.loadGradesTxt(gradesTxt);

        menuLoop();
    }

    private static void menuLoop() {
        while (true) {
            System.out.println("\n--- MENU ---");
            System.out.println("1) List students");
            System.out.println("2) View student details");
            System.out.println("3) List failed components for a student");
            System.out.println("4) Add recommendation");
            System.out.println("5) Add milestone");
            System.out.println("6) Start recovery attempt");
            System.out.println("7) Update recovery record");
            System.out.println("8) Generate text academic report (single student)");
            System.out.println("9) Save TXT report");
            System.out.println("10) Modify Recommendation");
            System.out.println("11) Remove Recommendation");
            System.out.println("12) Modify Milestone");
            System.out.println("13) Remove Milestone");
            System.out.println("0) Exit");
            System.out.print("Choice: ");
            String ch = scanner.nextLine().trim();
            switch (ch) {
                case "1":
                    listStudents();
                    break;
                case "2":
                    viewStudentDetails();
                    break;
                case "3":
                    listFailed();
                    break;
                case "4":
                    addRecommendation();
                    break;
                case "5":
                    addMilestone();
                    break;
                case "6":
                    startRecovery();
                    break;
                case "7":
                    updateRecovery();
                    break;
                case "8":
                    generateSingleStudentReport();
                    break;
                case "9":
                    saveTxtReport();
                    break;
                case "10":
                    modifyRecommendation();
                    break;
                case "11":
                    removeRecommendation();
                    break;
                case "12":
                    modifyMilestone();
                    break;
                case "13":
                    removeMilestone();
                    break;
                case "0":
                    System.out.println("Goodbye");
                    return;
                default:
                    System.out.println("Invalid choice");
            }
        }
    }

    private static void listStudents() {
        if (studentService.isEmpty()) {
            System.out.println("NO STUDENTS LOADED.");
            return;
        }

        System.out.println("------------------------------------------------------------");
        System.out.printf("%-8s %-22s %-18s %s\n", "ID", "Name", "Course", "Year");
        System.out.println("------------------------------------------------------------");

        for (Student s : studentService.getAll()) {
            String id = s.getId();
            String name = s.getName();
            String course = (s.getMajor() == null || s.getMajor().isEmpty()) ? "N/A" : s.getMajor();
            String year = (s.getYear() == null || s.getYear().isEmpty()) ? "N/A" : s.getYear();
            System.out.printf("%-8s %-22s %-18s %s\n", id, name, course, year);
        }
        System.out.println("------------------------------------------------------------");
    }

    private static Student chooseStudent() {
        System.out.print("Enter student ID: ");
        String id = scanner.nextLine().trim();
        Student s = studentService.getStudent(id);
        if (s == null)
            System.out.println("Student not found: " + id);
        return s;
    }

    private static void viewStudentDetails() {
        Student s = chooseStudent();
        if (s == null)
            return;
        System.out.println("------------------------------------------------------------");
        System.out.println("Student: " + s.getId() + " - " + s.getName());
        System.out.println("Course: " + (s.getMajor() == null ? "N/A" : s.getMajor()) + "    Year: "
                + (s.getYear() == null ? "N/A" : s.getYear()));
        System.out.println("------------------------------------------------------------");
        System.out.println("Components:");
        System.out.printf("%-6s %-36s %-8s %-8s\n", "CID", "Component Name", "Score", "Pass");
        for (Component c : s.getComponents()) {
            System.out.printf("%-6s %-36s %-8.2f %-8s\n", c.getId(), c.getName(), c.getScore(),
                    (c.isPassed() ? "PASS" : "FAIL"));
        }
        System.out.println("------------------------------------------------------------");
        System.out.println("Recommendations:");
        s.getRecommendations().forEach(r -> System.out.println("  " + r));
        System.out.println("Milestones:");
        s.getMilestones().forEach(m -> System.out.println("  " + m));
        System.out.println("Recovery Records:");
        s.getRecoveryRecords().forEach(rr -> System.out.println("  " + rr));
        System.out.println("------------------------------------------------------------");
    }

    private static void listFailed() {
        Student s = chooseStudent();
        if (s == null)
            return;
        List<Component> failed = s.getFailedComponents();
        if (failed.isEmpty())
            System.out.println("No failed components.");
        else {
            System.out.println("Failed components for " + s.getName() + ":");
            failed.forEach(c -> System.out.println("  " + c));
        }
    }

    private static void addRecommendation() {
        Student s = chooseStudent();
        if (s == null)
            return;
        System.out.print("Lecturer: ");
        String lecturer = scanner.nextLine().trim();
        System.out.print("Course ID: ");
        String courseId = scanner.nextLine().trim();
        System.out.print("Text: ");
        String text = scanner.nextLine().trim();
        Recommendation r = new Recommendation("REC-" + System.currentTimeMillis(), lecturer, s.getId(), courseId, text);
        s.addRecommendation(r);
        System.out.println("Added: " + r);
    }

    private static void addMilestone() {
        Student s = chooseStudent();
        if (s == null)
            return;
        System.out.print("Course ID: ");
        String courseId = scanner.nextLine().trim();
        System.out.print("Week (e.g. Week 4): ");
        String wk = scanner.nextLine().trim();
        System.out.print("Description: ");
        String desc = scanner.nextLine().trim();
        Milestone m = new Milestone("MS-" + System.currentTimeMillis(), courseId, desc, wk);
        s.addMilestone(m);
        System.out.println("Added: " + m);
    }

    private static void startRecovery() {
        Student s = chooseStudent();
        if (s == null)
            return;
        var failed = s.getFailedComponents();
        if (failed.isEmpty()) {
            System.out.println("No failed components");
            return;
        }
        System.out.println("Choose component id:");
        failed.forEach(c -> System.out.println("  " + c.getId() + " -> " + c.getName()));
        System.out.print("Component id: ");
        String compId = scanner.nextLine().trim();
        Component comp = s.getComponents().stream().filter(c -> c.getId().equals(compId)).findFirst().orElse(null);
        if (comp == null) {
            System.out.println("Not found");
            return;
        }
        RecoveryRecord rr = new RecoveryRecord("RR-" + System.currentTimeMillis(), s.getId(), comp.getId(),
                comp.getScore());
        rr.setStatus("in progress");
        s.addRecoveryRecord(rr);
        System.out.println("Started recovery: " + rr);
    }

    private static void updateRecovery() {
        Student s = chooseStudent();
        if (s == null)
            return;
        var recs = s.getRecoveryRecords();
        if (recs.isEmpty()) {
            System.out.println("No recovery records");
            return;
        }
        recs.forEach(r -> System.out.println("  " + r.getId() + " -> " + r));
        System.out.print("Recovery id: ");
        String rid = scanner.nextLine().trim();
        RecoveryRecord rr = recs.stream().filter(r -> r.getId().equals(rid)).findFirst().orElse(null);
        if (rr == null) {
            System.out.println("Not found");
            return;
        }
        System.out.print("New score (blank to skip): ");
        String ns = scanner.nextLine().trim();
        if (!ns.isEmpty()) {
            try {
                double val = Double.parseDouble(ns);
                rr.setNewScore(val);
                // update component
                var comp = s.getComponents().stream().filter(c -> c.getId().equals(rr.getComponentId())).findFirst()
                        .orElse(null);
                if (comp != null)
                    comp.setScore(val);
            } catch (NumberFormatException e) {
                System.out.println("Invalid number");
            }
        }
        System.out.print("Status (not started/in progress/completed) blank to skip: ");
        String st = scanner.nextLine().trim();
        if (!st.isEmpty())
            rr.setStatus(st);
        System.out.println("Updated: " + rr);
    }

    private static void generateSingleStudentReport() {
        System.out.print("Enter student ID for report: ");
        String id = scanner.nextLine().trim();
        Student s = studentService.getStudent(id);
        if (s == null) {
            System.out.println("Student not found: " + id);
            return;
        }
        String rep = reportService.generateTextReport(Collections.singletonList(s));
        System.out.println("\n=== ACADEMIC REPORT FOR " + s.getName() + " ===\n");
        System.out.println(rep);
    }

    private static void saveTxtReport() {
        System.out.print("Enter output TXT path (example C:/temp/report.txt): ");
        String p = scanner.nextLine().trim();
        if (p.isEmpty()) {
            System.out.println("Cancelled.");
            return;
        }
        reportService.saveReportTxt(studentService.getAll(), p);
        System.out.println("Saved to: " + p);
    }

    private static void modifyRecommendation() {
        Student s = chooseStudent();
        if (s == null)
            return;
        List<Recommendation> recs = s.getRecommendations();
        if (recs.isEmpty()) {
            System.out.println("No recommendations found.");
            return;
        }
        recs.forEach(r -> System.out.println("  " + r.getId() + " -> " + r.getText()));
        System.out.print("Enter Recommendation ID to modify: ");
        String id = scanner.nextLine().trim();
        System.out.print("New Text (blank to keep): ");
        String text = scanner.nextLine().trim();
        if (text.isEmpty())
            text = null;
        System.out.print("New Lecturer (blank to keep): ");
        String lecturer = scanner.nextLine().trim();
        if (lecturer.isEmpty())
            lecturer = null;

        if (recommendationService.modifyRecommendation(s, id, text, lecturer)) {
            System.out.println("Recommendation modified.");
        } else {
            System.out.println("Recommendation not found.");
        }
    }

    private static void removeRecommendation() {
        Student s = chooseStudent();
        if (s == null)
            return;
        List<Recommendation> recs = s.getRecommendations();
        if (recs.isEmpty()) {
            System.out.println("No recommendations found.");
            return;
        }
        recs.forEach(r -> System.out.println("  " + r.getId() + " -> " + r.getText()));
        System.out.print("Enter Recommendation ID to remove: ");
        String id = scanner.nextLine().trim();

        if (recommendationService.removeRecommendation(s, id)) {
            System.out.println("Recommendation removed.");
        } else {
            System.out.println("Recommendation not found.");
        }
    }

    private static void modifyMilestone() {
        Student s = chooseStudent();
        if (s == null)
            return;
        List<Milestone> milestones = s.getMilestones();
        if (milestones.isEmpty()) {
            System.out.println("No milestones found.");
            return;
        }
        milestones.forEach(m -> System.out.println("  " + m.getId() + " -> " + m.getDescription()));
        System.out.print("Enter Milestone ID to modify: ");
        String id = scanner.nextLine().trim();
        System.out.print("New Description (blank to keep): ");
        String desc = scanner.nextLine().trim();
        if (desc.isEmpty())
            desc = null;
        System.out.print("Completed? (true/false/blank): ");
        String compStr = scanner.nextLine().trim();
        Boolean completed = null;
        if (!compStr.isEmpty())
            completed = Boolean.parseBoolean(compStr);

        if (recoveryService.modifyMilestone(s, id, desc, completed)) {
            System.out.println("Milestone modified.");
        } else {
            System.out.println("Milestone not found.");
        }
    }

    private static void removeMilestone() {
        Student s = chooseStudent();
        if (s == null)
            return;
        List<Milestone> milestones = s.getMilestones();
        if (milestones.isEmpty()) {
            System.out.println("No milestones found.");
            return;
        }
        milestones.forEach(m -> System.out.println("  " + m.getId() + " -> " + m.getDescription()));
        System.out.print("Enter Milestone ID to remove: ");
        String id = scanner.nextLine().trim();

        if (recoveryService.removeMilestone(s, id)) {
            System.out.println("Milestone removed.");
        } else {
            System.out.println("Milestone not found.");
        }
    }
}
