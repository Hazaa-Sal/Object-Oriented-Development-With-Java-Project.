package com.crs.model;

public class AcademicOfficer extends Person {
    private String officeId;
    public AcademicOfficer(String id, String name, String officeId) {
        super(id, name);
        this.officeId = officeId;
    }
    public String getOfficeId(){ return officeId; }
}
