package com.crs.model;

public class Component {
    private String id;
    private String name;
    private double score; // now on 0-100 percentage scale
    private double passingMark; // passing threshold (default 50%)
    private String lecturer;

    // Primary constructor: score and passingMark on 0-100 scale
    public Component(String id, String name, double score, double passingMark, String lecturer) {
        this.id = id;
        this.name = name;
        this.score = score;
        this.passingMark = passingMark;
        this.lecturer = lecturer == null ? "" : lecturer;
    }

    // Compatibility constructors (keeps previous overloads working)
    public Component(String id, String name, double score, double passingMark) {
        this(id, name, score, passingMark, "");
    }

    // Default uses pass threshold 50 (50% to pass)
    public Component() {
        this("", "", 0.0, 50.0, "");
    }

    // --- getters / setters ---
    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public double getScore() {
        return score;
    } // 0-100 percentage

    public double getPassingMark() {
        return passingMark;
    } // threshold (default 50%)

    public boolean isPassed() {
        return score >= passingMark;
    }

    public String getLecturer() {
        return lecturer;
    }

    public void setScore(double s) {
        this.score = s;
    }

    public void setPassingMark(double p) {
        this.passingMark = p;
    }

    public void setLecturer(String l) {
        this.lecturer = l;
    }

    public void setId(String id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }

    // compatibility: older code might call these
    public String getComponentId() {
        return id;
    }

    public double getPassMark() {
        return passingMark;
    }

    @Override
    public String toString() {
        String lect = (lecturer == null || lecturer.isEmpty()) ? "" : " (" + lecturer + ")";
        return id + " " + name + lect + " score=" + String.format("%.2f", score) + " pass="
                + String.format("%.2f", passingMark) + " => " + (isPassed() ? "PASS" : "FAIL");
    }
}
