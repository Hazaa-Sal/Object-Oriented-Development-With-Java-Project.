package com.crs.model;

public class ComponentRecord {
    private String id;
    private Component component;
    private double score;
    private String remarks;

    public ComponentRecord(String id, Component component, double score) {
        this.id = id;
        this.component = component;
        this.score = score;
        this.remarks = "";
    }

    public String getId() { return id; }
    public Component getComponent() { return component; }
    public String getComponentId() { return component == null ? "" : component.getId(); }
    public double getPassMark() { return component == null ? 40.0 : component.getPassingMark(); }
    public double getScore() { return score; }
    public String getRemarks() { return remarks; }
    public void setScore(double s){ this.score = s; }
    public void setRemarks(String r){ this.remarks = r; }
}
