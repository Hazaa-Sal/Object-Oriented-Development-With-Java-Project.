package com.crs.model;

public class Course {
    private String id;
    private String name;
    private String semester;
    private double passMark;
    private int credits;
    private String instructor;

    public Course() { this("", "", "", 40.0); }

    public Course(String id, String name, String semester, double passMark) {
        this.id = id; this.name = name; this.semester = semester; this.passMark = passMark; this.credits = 0; this.instructor = "";
    }

    // constructor with credits
    public Course(String id, String name, int credits) {
        this.id = id; this.name = name; this.semester = ""; this.passMark = 40.0; this.credits = credits; this.instructor = "";
    }

    public String getId(){return id;}
    public String getName(){return name;}
    public String getCourseName(){return name;}
    public String getCourseId(){return id;}
    public String getSemester(){return semester;}
    public double getPassMark(){return passMark;}
    public int getCredits(){return credits;}
    public String getInstructor(){return instructor;}

    public void setInstructor(String i){ this.instructor = i; }
    public void setPassMark(double p){ this.passMark = p; }

    @Override
    public String toString(){ return id + " " + name + " (" + credits + "cr)"; }
}
