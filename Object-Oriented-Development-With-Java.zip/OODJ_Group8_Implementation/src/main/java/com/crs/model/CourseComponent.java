package com.crs.model;

public class CourseComponent {
    private String id;
    private String name;
    private double passMark;

    public CourseComponent(String id, String name, double passMark) {
        this.id = id; this.name = name; this.passMark = passMark;
    }

    public String getId(){ return id; }
    public String getName(){ return name; }
    public double getPassMark(){ return passMark; }
}
