package com.crs.model;

/**
 * GradeRecord: getGrade() returns String (compat), getGradeValue() returns double
 */
public class GradeRecord {
    private String componentId;
    private Course course;
    private double grade;
    private String semester;
    private boolean passed;

    public GradeRecord(String componentId, double grade, String semester) {
        this.componentId = componentId; this.course = null; this.grade = grade; this.semester = semester;
        this.passed = grade >= 40.0;
    }

    public GradeRecord(Course course, double grade) {
        this.course = course;
        this.componentId = (course==null?"":course.getId());
        this.semester = (course==null?"":course.getSemester());
        this.grade = grade;
        double pass = (course==null ? 40.0 : course.getPassMark());
        this.passed = grade >= pass;
    }

    public String getGrade() { return Double.toString(grade); }
    public double getGradeValue(){ return grade; }
    public Course getCourse(){ return course; }
    public boolean isPassed(){ return passed; }
    public String getComponentId(){ return componentId; }
    public String getSemester(){ return semester; }
}
