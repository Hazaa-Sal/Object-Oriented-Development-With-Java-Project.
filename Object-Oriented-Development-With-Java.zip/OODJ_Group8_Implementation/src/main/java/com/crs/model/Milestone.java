package com.crs.model;

public class Milestone {
    private String id;
    private String courseId;
    private String description;
    private String studyWeek;
    private boolean completed = false;

    public Milestone(String id, String courseId, String description, String studyWeek) {
        this.id = id;
        this.courseId = courseId;
        this.description = description;
        this.studyWeek = studyWeek;
    }

    public String getId() {
        return id;
    }

    public String getCourseId() {
        return courseId;
    }

    public String getDescription() {
        return description;
    }

    public String getStudyWeek() {
        return studyWeek;
    }

    public boolean isCompleted() {
        return completed;
    }

    public void setCompleted(boolean c) {
        this.completed = c;
    }

    public void setDescription(String d) {
        this.description = d;
    }

    public void setStudyWeek(String w) {
        this.studyWeek = w;
    }

    @Override
    public String toString() {
        return id + " " + courseId + " " + studyWeek + " : " + description + " [" + (completed ? "DONE" : "PENDING")
                + "]";
    }
}
