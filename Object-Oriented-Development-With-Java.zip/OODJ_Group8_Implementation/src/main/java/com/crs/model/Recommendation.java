package com.crs.model;

import java.time.LocalDate;

public class Recommendation {
    private String id;
    private String lecturer;
    private String studentId;
    private String courseId;
    private String text;
    private LocalDate date;
    private boolean implemented = false;

    public Recommendation(String id, String lecturer, String studentId, String courseId, String text) {
        this.id = id; this.lecturer = lecturer; this.studentId = studentId; this.courseId = courseId; this.text = text; this.date = LocalDate.now();
    }

    public String getId(){return id;}
    public String getLecturer(){return lecturer;}
    public String getStudentId(){return studentId;}
    public String getCourseId(){return courseId;}
    public String getText(){return text;}
    public LocalDate getDate(){return date;}
    public boolean isImplemented(){ return implemented; }

    public void setImplemented(boolean b) { this.implemented = b; }
    public void setText(String t) { this.text = t; }
    public void setLecturer(String l) { this.lecturer = l; }

    @Override
    public String toString(){ return id + " " + courseId + " : " + text + " (" + lecturer + ") implemented=" + implemented; }
}
