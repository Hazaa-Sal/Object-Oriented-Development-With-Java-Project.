package com.crs.model;

import java.util.ArrayList;
import java.util.List;

public class RecoveryPlan {
    private String id;
    private String studentId;
    private List<ComponentRecord> componentRecords = new ArrayList<>();

    public RecoveryPlan(String id, String studentId) {
        this.id = id;
        this.studentId = studentId;
    }

    public String getId() { return id; }
    public String getStudentId() { return studentId; }

    public void addComponentRecord(ComponentRecord cr) { componentRecords.add(cr); }
    public List<ComponentRecord> getComponentRecords() { return componentRecords; }

    @Override
    public String toString() {
        return "RecoveryPlan " + id + " for " + studentId + " items=" + componentRecords.size();
    }
}
