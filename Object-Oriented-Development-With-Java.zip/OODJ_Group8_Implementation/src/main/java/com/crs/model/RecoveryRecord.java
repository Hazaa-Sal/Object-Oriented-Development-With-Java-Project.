package com.crs.model;

import java.time.LocalDate;
import java.io.Serializable;

/**
 * RecoveryRecord - Tracks recovery attempts for failed components
 * 
 * Updated to include:
 * - Attempt number (1st, 2nd, 3rd)
 * - Recovery type (RESUBMIT_RESIT, REDO_ALL)
 * - Maximum achievable score
 * - Serializable for binary file persistence
 */
public class RecoveryRecord implements Serializable {
    private static final long serialVersionUID = 1L;

    private String id;
    private String studentId;
    private String componentId;
    private double oldScore;
    private double newScore;
    private String status;
    private LocalDate updatedAt;

    // NEW FIELDS for attempt tracking
    private int attemptNumber; // 1, 2, or 3
    private String recoveryType; // RESUBMIT_RESIT, RESUBMIT_RESIT_CAPPED, REDO_ALL
    private double maxScore; // Maximum achievable score for this attempt
    private LocalDate startedAt; // When recovery was started
    private LocalDate completedAt; // When recovery was completed

    public RecoveryRecord(String id, String studentId, String componentId, double oldScore) {
        this.id = id;
        this.studentId = studentId;
        this.componentId = componentId;
        this.oldScore = oldScore;
        this.newScore = oldScore;
        this.status = "not_started";
        this.updatedAt = LocalDate.now();
        this.attemptNumber = 1; // Default to 1st attempt
        this.recoveryType = "RESUBMIT_RESIT";
        this.maxScore = 100.0;
        this.startedAt = LocalDate.now();
    }

    // Original getters
    public String getId() {
        return id;
    }

    public String getStudentId() {
        return studentId;
    }

    public String getComponentId() {
        return componentId;
    }

    public double getOldScore() {
        return oldScore;
    }

    public double getNewScore() {
        return newScore;
    }

    public String getStatus() {
        return status;
    }

    public LocalDate getUpdatedAt() {
        return updatedAt;
    }

    // NEW getters for attempt tracking
    public int getAttemptNumber() {
        return attemptNumber;
    }

    public String getRecoveryType() {
        return recoveryType;
    }

    public double getMaxScore() {
        return maxScore;
    }

    public LocalDate getStartedAt() {
        return startedAt;
    }

    public LocalDate getCompletedAt() {
        return completedAt;
    }

    // Original setters
    public void setNewScore(double ns) {
        // Enforce max score cap based on attempt
        this.newScore = Math.min(ns, maxScore);
        this.updatedAt = LocalDate.now();
    }

    public void setStatus(String s) {
        this.status = s;
        this.updatedAt = LocalDate.now();
        if ("completed".equalsIgnoreCase(s)) {
            this.completedAt = LocalDate.now();
        }
    }

    // NEW setters for attempt tracking
    public void setAttemptNumber(int attemptNumber) {
        if (attemptNumber >= 1 && attemptNumber <= 3) {
            this.attemptNumber = attemptNumber;
        }
    }

    public void setRecoveryType(String recoveryType) {
        this.recoveryType = recoveryType;
    }

    public void setMaxScore(double maxScore) {
        this.maxScore = maxScore;
    }

    /**
     * Check if this is the final attempt (3rd)
     */
    public boolean isFinalAttempt() {
        return attemptNumber >= 3;
    }

    /**
     * Check if recovery is complete and passed
     */
    public boolean isRecoverySuccessful() {
        return "completed".equalsIgnoreCase(status) && newScore >= 50.0;
    }

    /**
     * Get attempt description
     */
    public String getAttemptDescription() {
        switch (attemptNumber) {
            case 1:
                return "1st Attempt - Resubmit/Resit";
            case 2:
                return "2nd Attempt - Resubmit/Resit (Capped)";
            case 3:
                return "3rd Attempt - Redo All (Final)";
            default:
                return "Unknown Attempt";
        }
    }

    /**
     * Convert to file format for persistence
     */
    public String toFileFormat() {
        return String.join(",",
                id,
                studentId,
                componentId,
                String.valueOf(oldScore),
                String.valueOf(newScore),
                status,
                String.valueOf(attemptNumber),
                recoveryType,
                String.valueOf(maxScore),
                startedAt != null ? startedAt.toString() : "",
                completedAt != null ? completedAt.toString() : "",
                updatedAt.toString());
    }

    /**
     * Parse from file format
     */
    public static RecoveryRecord fromFileFormat(String line) {
        String[] parts = line.split(",");
        if (parts.length < 6)
            return null;

        RecoveryRecord r = new RecoveryRecord(parts[0], parts[1], parts[2], Double.parseDouble(parts[3]));
        r.newScore = Double.parseDouble(parts[4]);
        r.status = parts[5];

        if (parts.length > 6)
            r.attemptNumber = Integer.parseInt(parts[6]);
        if (parts.length > 7)
            r.recoveryType = parts[7];
        if (parts.length > 8)
            r.maxScore = Double.parseDouble(parts[8]);
        if (parts.length > 9 && !parts[9].isEmpty())
            r.startedAt = LocalDate.parse(parts[9]);
        if (parts.length > 10 && !parts[10].isEmpty())
            r.completedAt = LocalDate.parse(parts[10]);
        if (parts.length > 11)
            r.updatedAt = LocalDate.parse(parts[11]);

        return r;
    }

    @Override
    public String toString() {
        return String.format("[Attempt %d] %s comp=%s %.2f->%.2f (max:%.2f) status=%s type=%s updated=%s",
                attemptNumber, id, componentId, oldScore, newScore, maxScore, status, recoveryType, updatedAt);
    }
}
