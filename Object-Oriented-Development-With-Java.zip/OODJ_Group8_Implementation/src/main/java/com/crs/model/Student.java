package com.crs.model;

import java.util.ArrayList;
import java.util.List;

public class Student {
    private String id;
    private String name;
    private String year;
    private String semester;
    private String email;
    private String major = "";
    private List<GradeRecord> academicHistory = new ArrayList<>();

    private List<Component> components = new ArrayList<>();
    private List<Recommendation> recommendations = new ArrayList<>();
    private List<Milestone> milestones = new ArrayList<>();
    private List<RecoveryRecord> recoveryRecords = new ArrayList<>();

    public Student(String id, String name, String year, String semester, String email) {
        this.id = id;
        this.name = name;
        this.year = year;
        this.semester = semester;
        this.email = email;
    }

    // compatibility constructor used by some file loaders
    public Student(String id, String name, String email) {
        this(id, name, "", "", email);
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getYear() {
        return year;
    }

    public String getSemester() {
        return semester;
    }

    public String getEmail() {
        return email;
    }

    public String getMajor() {
        return major;
    }

    public List<GradeRecord> getAcademicHistory() {
        return academicHistory;
    }

    public void setMajor(String major) {
        this.major = major;
    } // <--- important setter

    public void addGradeRecord(GradeRecord gr) {
        academicHistory.add(gr);
    }

    public List<Component> getComponents() {
        return components;
    }

    public void addComponent(Component c) {
        components.add(c);
    }

    public List<Component> getFailedComponents() {
        List<Component> out = new ArrayList<>();
        for (Component c : components)
            if (!c.isPassed())
                out.add(c);
        return out;
    }

    public void addRecommendation(Recommendation r) {
        recommendations.add(r);
    }

    public List<Recommendation> getRecommendations() {
        return recommendations;
    }

    public void addMilestone(Milestone m) {
        milestones.add(m);
    }

    public List<Milestone> getMilestones() {
        return milestones;
    }

    public void addRecoveryRecord(RecoveryRecord r) {
        recoveryRecords.add(r);
    }

    public List<RecoveryRecord> getRecoveryRecords() {
        return recoveryRecords;
    }

    // Helper methods for Recommendations
    public Recommendation getRecommendation(String id) {
        for (Recommendation r : recommendations) {
            if (r.getId().equals(id))
                return r;
        }
        return null;
    }

    public boolean removeRecommendation(String id) {
        return recommendations.removeIf(r -> r.getId().equals(id));
    }

    // Helper methods for Milestones
    public Milestone getMilestone(String id) {
        for (Milestone m : milestones) {
            if (m.getId().equals(id))
                return m;
        }
        return null;
    }

    public boolean removeMilestone(String id) {
        return milestones.removeIf(m -> m.getId().equals(id));
    }

    @Override
    public String toString() {
        return id + " " + name + " (" + email + ")";
    }
}
