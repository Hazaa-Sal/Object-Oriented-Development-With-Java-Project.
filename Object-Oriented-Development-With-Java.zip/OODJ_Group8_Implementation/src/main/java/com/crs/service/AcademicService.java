package com.crs.service;

import com.crs.model.*;

import java.util.*;

public class AcademicService {
    public String summarize(Student s) {
        StringBuilder sb = new StringBuilder();
        sb.append("Academic summary for ").append(s.getName()).append("\n");
        for (GradeRecord r : s.getAcademicHistory()) {
            Course c = r.getCourse();
            sb.append(" Course: ").append(c==null? "N/A": c.getCourseId()+" "+c.getCourseName())
              .append(" Grade: ").append(r.getGrade())
              .append(" Passed: ").append(r.isPassed()).append("\n");
        }
        return sb.toString();
    }
}
