package com.crs.service;

import com.crs.model.*;
import com.crs.util.TxtLoader;

public class FileService {
    private final StudentService studentService;

    public FileService(StudentService ss) {
        this.studentService = ss;
    }

    public void loadStudentsTxt(String path) {
        TxtLoader.loadStudents(path, studentService);
    }

    public void loadGradesTxt(String path) {
        TxtLoader.loadGradesToStudents(path, studentService);
    }

    // helper that demonstrates constructing Course objects from TXT fields
    public Course makeCourseFrom(String id, String name, int credits) {
        Course c = new Course(id, name, credits);
        return c;
    }
}
