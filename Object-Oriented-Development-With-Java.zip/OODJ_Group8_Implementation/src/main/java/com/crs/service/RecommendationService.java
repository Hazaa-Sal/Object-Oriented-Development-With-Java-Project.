package com.crs.service;

import com.crs.model.Recommendation;
import com.crs.model.Student;

import java.util.*;

public class RecommendationService {
    public void addRecommendation(Student s, Recommendation r) {
        s.addRecommendation(r);
    }

    public List<Recommendation> listFor(Student s) {
        return s.getRecommendations();
    }

    public boolean modifyRecommendation(Student s, String recId, String newText, String newLecturer) {
        Recommendation r = s.getRecommendation(recId);
        if (r != null) {
            if (newText != null)
                r.setText(newText);
            if (newLecturer != null)
                r.setLecturer(newLecturer);
            return true;
        }
        return false;
    }

    public boolean removeRecommendation(Student s, String recId) {
        return s.removeRecommendation(recId);
    }
}
