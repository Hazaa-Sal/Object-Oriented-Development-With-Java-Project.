package com.crs.service;

import com.crs.model.*;
import com.crs.strategy.*;
import com.crs.exception.RecoveryException;

// Permission imports for backend enforcement
import crs.CurrentSession;
import crs.User;
import crs.PermissionService;
import crs.UnauthorizedActionException;

import java.util.*;

/**
 * Enhanced Recovery Service with Strategy Pattern
 * 
 * Implements full 1st/2nd/3rd attempt logic per assignment requirements:
 * - 1st Attempt: Resubmit/resit failed component only
 * - 2nd Attempt: Resubmit/resit again (score capped at 80%)
 * - 3rd Attempt: Redo ALL components (score capped at 60%)
 * 
 * PERMISSION: Only ACADEMIC_OFFICER can start/complete recoveries
 * COURSE_ADMIN is explicitly BLOCKED
 */
public class RecoveryService {

    // Strategy instances for polymorphic behavior
    private final RecoveryStrategy firstAttemptStrategy = new FirstAttemptStrategy();
    private final RecoveryStrategy secondAttemptStrategy = new SecondAttemptStrategy();
    private final RecoveryStrategy thirdAttemptStrategy = new ThirdAttemptStrategy();

    /**
     * Get the appropriate strategy based on current attempt number
     */
    public RecoveryStrategy getStrategy(int attemptNumber) {
        switch (attemptNumber) {
            case 1:
                return firstAttemptStrategy;
            case 2:
                return secondAttemptStrategy;
            case 3:
                return thirdAttemptStrategy;
            default:
                return firstAttemptStrategy;
        }
    }

    /**
     * Determine the next attempt number for a component
     */
    public int getNextAttemptNumber(Student student, Component component) {
        int currentAttempts = 0;
        for (RecoveryRecord r : student.getRecoveryRecords()) {
            if (r.getComponentId().equals(component.getId())) {
                currentAttempts++;
            }
        }
        return currentAttempts + 1;
    }

    /**
     * Start recovery using the appropriate strategy
     * Uses polymorphism to handle different attempt behaviors
     * 
     * PERMISSION CHECK: Course Admin is blocked from this operation
     */
    public RecoveryRecord startRecovery(Student s, Component comp) throws RecoveryException {
        // ========================================
        // BACKEND PERMISSION GUARD
        // ========================================
        User currentUser = CurrentSession.getUser();
        if (currentUser != null && currentUser.getRole() == User.Role.COURSE_ADMIN) {
            System.out.println("[SECURITY] Course Admin blocked from startRecovery()");
            throw new UnauthorizedActionException(currentUser, "Start Recovery");
        }
        // ========================================

        int attemptNumber = getNextAttemptNumber(s, comp);

        if (attemptNumber > 3) {
            throw new RecoveryException("Maximum recovery attempts (3) exceeded for component: " + comp.getName(),
                    attemptNumber);
        }

        // Create recovery record
        RecoveryRecord rr = new RecoveryRecord(
                "RR-" + System.currentTimeMillis(),
                s.getId(),
                comp.getId(),
                comp.getScore());

        // Get appropriate strategy using polymorphism
        RecoveryStrategy strategy = getStrategy(attemptNumber);

        // Execute strategy (polymorphic call)
        strategy.executeRecovery(s, comp, rr);

        // Add to student's records
        s.addRecoveryRecord(rr);

        System.out.println("=== RECOVERY STARTED ===");
        System.out.println("Student: " + s.getName());
        System.out.println("Component: " + comp.getName());
        System.out.println("Attempt: " + attemptNumber + " of 3");
        System.out.println("Strategy: " + strategy.getDescription());
        System.out.println("Max Score: " + strategy.getMaxAchievableScore() + "%");
        System.out.println("========================");

        return rr;
    }

    /**
     * Complete a recovery attempt with new score
     */
    public void completeRecovery(RecoveryRecord rr, double newScore, Student s) throws RecoveryException {
        // Get strategy for score cap validation
        RecoveryStrategy strategy = getStrategy(rr.getAttemptNumber());

        // Apply score cap based on attempt
        double cappedScore = Math.min(newScore, strategy.getMaxAchievableScore());

        rr.setNewScore(cappedScore);
        rr.setStatus("completed");

        // Update student's component score
        for (Component c : s.getComponents()) {
            if (c.getId().equals(rr.getComponentId())) {
                c.setScore(cappedScore);
                break;
            }
        }

        System.out.println("=== RECOVERY COMPLETED ===");
        System.out.println("Attempt " + rr.getAttemptNumber() + " Result:");
        System.out.println("Old Score: " + rr.getOldScore() + "%");
        System.out.println("New Score: " + cappedScore + "% (cap: " + strategy.getMaxAchievableScore() + "%)");
        System.out.println("Status: " + (cappedScore >= 50.0 ? "PASSED" : "FAILED"));
        System.out.println("==========================");
    }

    /**
     * Check if student can start another recovery attempt
     */
    public boolean canStartRecovery(Student s, Component comp) {
        if (comp.isPassed())
            return false;

        int attempts = 0;
        for (RecoveryRecord r : s.getRecoveryRecords()) {
            if (r.getComponentId().equals(comp.getId())) {
                attempts++;
            }
        }
        return attempts < 3;
    }

    /**
     * Get recovery status message for a component
     */
    public String getRecoveryStatusMessage(Student s, Component comp) {
        int attempts = 0;
        RecoveryRecord lastRecord = null;

        for (RecoveryRecord r : s.getRecoveryRecords()) {
            if (r.getComponentId().equals(comp.getId())) {
                attempts++;
                lastRecord = r;
            }
        }

        if (comp.isPassed()) {
            return "✓ PASSED - No recovery needed";
        }

        if (attempts == 0) {
            return "✗ FAILED - Eligible for 1st attempt recovery";
        } else if (attempts == 1) {
            return "✗ STILL FAILED - Eligible for 2nd attempt (max 80%)";
        } else if (attempts == 2) {
            return "✗ STILL FAILED - Eligible for FINAL 3rd attempt (redo all, max 60%)";
        } else {
            return "✗ MAXIMUM ATTEMPTS EXCEEDED - No more recoveries allowed";
        }
    }

    // ==================== MILESTONE MANAGEMENT ====================

    public void addMilestone(Student s, Milestone m) {
        s.addMilestone(m);
        System.out.println("[MILESTONE] Added: " + m.getDescription() + " for student " + s.getId());
    }

    public boolean modifyMilestone(Student s, String mId, String description, Boolean completed) {
        Milestone m = s.getMilestone(mId);
        if (m != null) {
            if (description != null)
                m.setDescription(description);
            if (completed != null)
                m.setCompleted(completed);
            System.out.println("[MILESTONE] Modified: " + mId);
            return true;
        }
        return false;
    }

    public boolean removeMilestone(Student s, String mId) {
        boolean removed = s.removeMilestone(mId);
        if (removed) {
            System.out.println("[MILESTONE] Removed: " + mId);
        }
        return removed;
    }

    public String getRecoveryStatus(RecoveryRecord rr) {
        return rr.getStatus();
    }

    /**
     * Get all strategies for display purposes
     */
    public List<RecoveryStrategy> getAllStrategies() {
        return Arrays.asList(firstAttemptStrategy, secondAttemptStrategy, thirdAttemptStrategy);
    }

    // Milestone methods removed - recovery plan is now sent via email only,
    // not added to the UI or database.
}
