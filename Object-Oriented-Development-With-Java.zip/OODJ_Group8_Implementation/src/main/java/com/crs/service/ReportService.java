package com.crs.service;

import com.crs.model.*;

import java.util.*;
import java.io.*;

public class ReportService {

    public String generateTextReport(Collection<Student> students) {
        StringBuilder sb = new StringBuilder();
        for (Student s : students) {
            sb.append("------------------------------------------------------------\n");
            sb.append(String.format("Student: %s - %s\n", s.getId(), s.getName()));
            sb.append(String.format("Course : %s    Year: %s\n", safe(s.getMajor()), safe(s.getYear())));
            sb.append("Components:\n");
            sb.append(String.format("%-8s %-12s %-30s %-8s %-8s\n", "CID", "Lecturer", "Component Name", "Score",
                    "Pass"));
            if (s.getComponents().isEmpty())
                sb.append("   (none)\n");
            else {
                for (Component c : s.getComponents()) {
                    sb.append(String.format("%-8s %-12s %-30s %-8.2f %-8s\n",
                            c.getId(),
                            safe(c.getLecturer()),
                            safe(c.getName()),
                            c.getScore(),
                            (c.isPassed() ? "PASS" : "FAIL")));
                }
            }
            sb.append("Recommendations:\n");
            for (Recommendation r : s.getRecommendations())
                sb.append("  " + r + "\n");
            sb.append("Milestones:\n");
            for (Milestone m : s.getMilestones())
                sb.append("  " + m + "\n");
            sb.append("Recovery Records:\n");
            for (RecoveryRecord rr : s.getRecoveryRecords())
                sb.append("  " + rr + "\n");
            sb.append("\n");
        }
        return sb.toString();
    }

    public void saveReportTxt(Collection<Student> students, String outPath) {
        try (PrintWriter pw = new PrintWriter(new FileWriter(outPath))) {
            pw.println(
                    "studentId,studentName,course,year,componentId,lecturer,componentName,score,passing,componentStatus");
            for (Student s : students) {
                if (s.getComponents().isEmpty()) {
                    pw.printf("%s,%s,%s,%s,,,,,,\n", safe(s.getId()), safe(s.getName()), safe(s.getMajor()),
                            safe(s.getYear()));
                } else {
                    for (Component c : s.getComponents()) {
                        pw.printf("%s,%s,%s,%s,%s,%s,%s,%.2f,%.2f,%s\n",
                                safe(s.getId()), safe(s.getName()), safe(s.getMajor()), safe(s.getYear()),
                                safe(c.getId()), safe(c.getLecturer()), safe(c.getName()), c.getScore(),
                                c.getPassingMark(), (c.isPassed() ? "PASS" : "FAIL"));
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("Error saving report: " + e.getMessage());
        }
    }

    private String safe(String s) {
        return s == null ? "" : s.replace(",", " ");
    }
}
