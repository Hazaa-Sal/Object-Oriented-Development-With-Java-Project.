package com.crs.service;

import com.crs.model.Student;
import java.util.*;

public class StudentService {
    private final Map<String, Student> students = new LinkedHashMap<>();
    public void addStudent(Student s){ students.put(s.getId(), s); }
    public Student getStudent(String id){ return students.get(id); }
    public Collection<Student> getAll(){ return students.values(); }
    public boolean isEmpty(){ return students.isEmpty(); }
}
