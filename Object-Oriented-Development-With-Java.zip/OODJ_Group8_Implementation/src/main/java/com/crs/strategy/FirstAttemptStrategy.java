/*
 * First Attempt Strategy - Resubmit/Resit failed component only
 */
package com.crs.strategy;

import com.crs.model.Student;
import com.crs.model.Component;
import com.crs.model.RecoveryRecord;
import com.crs.exception.RecoveryException;

/**
 * First Attempt Recovery Strategy
 * 
 * Per Assignment Requirements:
 * - Student can resubmit assignment OR resit exam for the FAILED component only
 * - Full marks achievable (100%)
 * - Only the specific failed component is affected
 */
public class FirstAttemptStrategy implements RecoveryStrategy {

    @Override
    public int getAttemptNumber() {
        return 1;
    }

    @Override
    public String getDescription() {
        return "1st Attempt: Resubmit/resit the failed component only. Full marks achievable.";
    }

    @Override
    public void executeRecovery(Student student, Component failedComponent, RecoveryRecord record)
            throws RecoveryException {

        if (!isEligible(student, failedComponent)) {
            throw new RecoveryException("Student not eligible for 1st attempt recovery", 1);
        }

        // Set up recovery for the specific failed component
        record.setAttemptNumber(1);
        record.setStatus("in_progress");
        record.setRecoveryType("RESUBMIT_RESIT");
        record.setMaxScore(100.0); // Full marks possible on 1st attempt

        System.out.println("[1st Attempt] Recovery started for component: " + failedComponent.getName());
        System.out.println("[1st Attempt] Student must resubmit/resit: " + failedComponent.getId());
    }

    @Override
    public boolean isEligible(Student student, Component component) {
        // Eligible if component is failed and no previous recovery attempts
        if (component.isPassed()) {
            return false;
        }

        // Check if there are existing recovery records for this component
        for (RecoveryRecord r : student.getRecoveryRecords()) {
            if (r.getComponentId().equals(component.getId())) {
                return false; // Already has a recovery attempt
            }
        }
        return true;
    }

    @Override
    public double getMaxAchievableScore() {
        return 100.0; // Full marks on first attempt
    }
}
