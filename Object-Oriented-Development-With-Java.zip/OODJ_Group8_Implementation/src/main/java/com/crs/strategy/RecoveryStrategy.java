/*
 * Recovery Strategy Interface - Strategy Pattern
 * Demonstrates abstraction and polymorphism for OOP requirements
 */
package com.crs.strategy;

import com.crs.model.Student;
import com.crs.model.Component;
import com.crs.model.RecoveryRecord;
import com.crs.exception.RecoveryException;

/**
 * Interface for recovery attempt strategies
 * Implements Strategy Pattern for different attempt behaviors
 * 
 * Per Assignment Requirements:
 * - 1st Attempt: Resubmit/resit failed component only
 * - 2nd Attempt: Resubmit/resit failed components again
 * - 3rd Attempt: Redo ALL components
 */
public interface RecoveryStrategy {

    /**
     * Get the attempt number this strategy handles
     */
    int getAttemptNumber();

    /**
     * Get description of what this attempt allows
     */
    String getDescription();

    /**
     * Execute the recovery strategy for a student's failed component
     * 
     * @param student         The student undergoing recovery
     * @param failedComponent The component that was failed
     * @param record          The recovery record tracking progress
     * @throws RecoveryException if recovery cannot proceed
     */
    void executeRecovery(Student student, Component failedComponent, RecoveryRecord record)
            throws RecoveryException;

    /**
     * Check if student is eligible for this recovery attempt
     */
    boolean isEligible(Student student, Component component);

    /**
     * Get the maximum score achievable in this attempt (may be capped)
     */
    double getMaxAchievableScore();
}
