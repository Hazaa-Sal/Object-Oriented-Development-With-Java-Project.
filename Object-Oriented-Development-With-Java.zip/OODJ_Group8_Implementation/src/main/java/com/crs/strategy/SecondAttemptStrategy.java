/*
 * Second Attempt Strategy - Resubmit/Resit failed components again
 */
package com.crs.strategy;

import com.crs.model.Student;
import com.crs.model.Component;
import com.crs.model.RecoveryRecord;
import com.crs.exception.RecoveryException;

/**
 * Second Attempt Recovery Strategy
 * 
 * Per Assignment Requirements:
 * - Student can resubmit/resit failed components AGAIN
 * - Maximum score may be capped (e.g., 80%)
 * - Still only affects the failed component
 */
public class SecondAttemptStrategy implements RecoveryStrategy {

    private static final double MAX_SCORE_CAP = 80.0; // Capped at 80% for 2nd attempt

    @Override
    public int getAttemptNumber() {
        return 2;
    }

    @Override
    public String getDescription() {
        return "2nd Attempt: Resubmit/resit failed components again. Maximum score capped at 80%.";
    }

    @Override
    public void executeRecovery(Student student, Component failedComponent, RecoveryRecord record)
            throws RecoveryException {

        if (!isEligible(student, failedComponent)) {
            throw new RecoveryException("Student not eligible for 2nd attempt recovery", 2);
        }

        // Set up 2nd attempt recovery
        record.setAttemptNumber(2);
        record.setStatus("in_progress");
        record.setRecoveryType("RESUBMIT_RESIT_CAPPED");
        record.setMaxScore(MAX_SCORE_CAP);

        System.out.println("[2nd Attempt] Recovery started for component: " + failedComponent.getName());
        System.out.println("[2nd Attempt] Maximum achievable score: " + MAX_SCORE_CAP + "%");
    }

    @Override
    public boolean isEligible(Student student, Component component) {
        // Eligible if component is still failed AND has exactly 1 previous attempt
        if (component.isPassed()) {
            return false;
        }

        int attemptCount = 0;
        for (RecoveryRecord r : student.getRecoveryRecords()) {
            if (r.getComponentId().equals(component.getId())) {
                attemptCount++;
            }
        }
        return attemptCount == 1; // Must have exactly 1 previous attempt
    }

    @Override
    public double getMaxAchievableScore() {
        return MAX_SCORE_CAP;
    }
}
