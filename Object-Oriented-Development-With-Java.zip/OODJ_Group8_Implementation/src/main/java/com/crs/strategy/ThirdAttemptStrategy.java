/*
 * Third Attempt Strategy - Redo ALL components
 */
package com.crs.strategy;

import com.crs.model.Student;
import com.crs.model.Component;
import com.crs.model.RecoveryRecord;
import com.crs.exception.RecoveryException;
import java.util.List;

/**
 * Third Attempt Recovery Strategy
 * 
 * Per Assignment Requirements:
 * - Student must REDO ALL components (entire course)
 * - This is the final attempt
 * - Maximum score capped at 60%
 */
public class ThirdAttemptStrategy implements RecoveryStrategy {

    private static final double MAX_SCORE_CAP = 60.0; // Heavily capped for 3rd attempt

    @Override
    public int getAttemptNumber() {
        return 3;
    }

    @Override
    public String getDescription() {
        return "3rd Attempt (FINAL): Redo ALL components. Maximum score capped at 60%.";
    }

    @Override
    public void executeRecovery(Student student, Component failedComponent, RecoveryRecord record)
            throws RecoveryException {

        if (!isEligible(student, failedComponent)) {
            throw new RecoveryException("Student not eligible for 3rd attempt. Maximum attempts exceeded.", 3);
        }

        // Set up 3rd attempt recovery - REDO ALL COMPONENTS
        record.setAttemptNumber(3);
        record.setStatus("in_progress");
        record.setRecoveryType("REDO_ALL");
        record.setMaxScore(MAX_SCORE_CAP);

        // CRITICAL: Reset ALL components for this student (per assignment requirement)
        System.out.println("[3rd Attempt] FINAL ATTEMPT - Resetting ALL components for student: " + student.getId());

        List<Component> allComponents = student.getComponents();
        for (Component comp : allComponents) {
            System.out.println("[3rd Attempt] Component reset: " + comp.getName() +
                    " (was " + comp.getScore() + "%, now pending redo)");
            // Mark for redo by setting a flag or creating recovery records
            comp.setScore(0.0); // Reset to 0 pending redo
        }

        System.out.println("[3rd Attempt] Student must redo ALL " + allComponents.size() + " components");
        System.out.println("[3rd Attempt] Maximum achievable score per component: " + MAX_SCORE_CAP + "%");
    }

    @Override
    public boolean isEligible(Student student, Component component) {
        // Eligible if component is still failed AND has exactly 2 previous attempts
        if (component.isPassed()) {
            return false;
        }

        int attemptCount = 0;
        for (RecoveryRecord r : student.getRecoveryRecords()) {
            if (r.getComponentId().equals(component.getId())) {
                attemptCount++;
            }
        }
        return attemptCount == 2; // Must have exactly 2 previous attempts
    }

    @Override
    public double getMaxAchievableScore() {
        return MAX_SCORE_CAP;
    }
}
