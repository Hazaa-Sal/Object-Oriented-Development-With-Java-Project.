/*
 * Binary File Handler for Login/Logout Timestamps
 * Uses DataInputStream/DataOutputStream for binary file I/O
 */
package com.crs.util;

import java.io.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

/**
 * Handles binary file operations for login/logout timestamps
 * Per assignment requirement: "Login & Logout with timestamp stored in binary
 * file format"
 */
public class BinaryLoginHandler {

    private static final String LOGIN_FILE = "data/login_timestamps.dat";
    private static final DateTimeFormatter FORMATTER = DateTimeFormatter.ISO_LOCAL_DATE_TIME;

    /**
     * Login record stored in binary format
     */
    public static class LoginRecord implements Serializable {
        private static final long serialVersionUID = 1L;

        private String odisjesLoginEvent;
        private String userEmail;
        private LocalDateTime loginTime;
        private LocalDateTime logoutTime;
        private String sessionId;

        public LoginRecord(String userId, String userEmail, LocalDateTime loginTime) {
            this.odisjesLoginEvent = userId;
            this.userEmail = userEmail;
            this.loginTime = loginTime;
            this.sessionId = generateSessionId();
        }

        public void setLogoutTime(LocalDateTime logoutTime) {
            this.logoutTime = logoutTime;
        }

        public String getUserId() {
            return odisjesLoginEvent;
        }

        public String getUserEmail() {
            return userEmail;
        }

        public LocalDateTime getLoginTime() {
            return loginTime;
        }

        public LocalDateTime getLogoutTime() {
            return logoutTime;
        }

        public String getSessionId() {
            return sessionId;
        }

        private String generateSessionId() {
            return "SES-" + System.currentTimeMillis();
        }

        @Override
        public String toString() {
            return String.format("Session[%s] User:%s Login:%s Logout:%s",
                    sessionId, userEmail, loginTime, logoutTime != null ? logoutTime : "Active");
        }
    }

    /**
     * Record a login event to binary file
     */
    public static void recordLogin(String userId, String userEmail) {
        LoginRecord record = new LoginRecord(userId, userEmail, LocalDateTime.now());

        List<LoginRecord> records = loadAllRecords();
        records.add(record);
        saveAllRecords(records);

        System.out.println("[BINARY] Login recorded: " + record);
    }

    /**
     * Record a logout event to binary file
     */
    public static void recordLogout(String userEmail) {
        List<LoginRecord> records = loadAllRecords();

        // Find the most recent login for this user without a logout
        for (int i = records.size() - 1; i >= 0; i--) {
            LoginRecord r = records.get(i);
            if (r.getUserEmail().equalsIgnoreCase(userEmail) && r.getLogoutTime() == null) {
                r.setLogoutTime(LocalDateTime.now());
                saveAllRecords(records);
                System.out.println("[BINARY] Logout recorded: " + r);
                return;
            }
        }
    }

    /**
     * Load all login records from binary file
     */
    @SuppressWarnings("unchecked")
    public static List<LoginRecord> loadAllRecords() {
        File file = new File(LOGIN_FILE);
        if (!file.exists()) {
            return new ArrayList<>();
        }

        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(file))) {
            return (List<LoginRecord>) ois.readObject();
        } catch (Exception e) {
            System.err.println("Error loading login records: " + e.getMessage());
            return new ArrayList<>();
        }
    }

    /**
     * Save all login records to binary file
     */
    public static void saveAllRecords(List<LoginRecord> records) {
        File file = new File(LOGIN_FILE);
        file.getParentFile().mkdirs(); // Ensure directory exists

        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(file))) {
            oos.writeObject(records);
        } catch (Exception e) {
            System.err.println("Error saving login records: " + e.getMessage());
        }
    }

    /**
     * Get login history for a specific user
     */
    public static List<LoginRecord> getUserLoginHistory(String userEmail) {
        List<LoginRecord> all = loadAllRecords();
        List<LoginRecord> userRecords = new ArrayList<>();

        for (LoginRecord r : all) {
            if (r.getUserEmail().equalsIgnoreCase(userEmail)) {
                userRecords.add(r);
            }
        }
        return userRecords;
    }

    /**
     * Get the last login time for a user
     */
    public static LocalDateTime getLastLoginTime(String userEmail) {
        List<LoginRecord> history = getUserLoginHistory(userEmail);
        if (history.isEmpty()) {
            return null;
        }
        return history.get(history.size() - 1).getLoginTime();
    }

    /**
     * Clear login history (for testing)
     */
    public static void clearHistory() {
        saveAllRecords(new ArrayList<>());
    }
}
