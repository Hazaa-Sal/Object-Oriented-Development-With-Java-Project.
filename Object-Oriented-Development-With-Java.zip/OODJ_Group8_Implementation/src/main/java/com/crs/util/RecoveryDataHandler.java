/*
 * Recovery Data Persistence Handler
 * Handles file I/O for recovery records, milestones, and recommendations
 */
package com.crs.util;

import com.crs.model.*;
import java.io.*;
import java.util.*;

/**
 * Handles persistence of recovery-related data to files
 * Per assignment requirement: "Storing & retrieving data from file"
 */
public class RecoveryDataHandler {

    private static final String RECOVERY_RECORDS_FILE = "data/recovery_records.txt";
    private static final String MILESTONES_FILE = "data/milestones.txt";
    private static final String RECOMMENDATIONS_FILE = "data/recommendations.txt";

    // ==================== RECOVERY RECORDS ====================

    /**
     * Save all recovery records to file
     */
    public static void saveRecoveryRecords(Collection<Student> students) {
        File file = new File(RECOVERY_RECORDS_FILE);
        file.getParentFile().mkdirs();

        try (PrintWriter pw = new PrintWriter(new FileWriter(file))) {
            pw.println(
                    "id,studentId,componentId,oldScore,newScore,status,attemptNumber,recoveryType,maxScore,startedAt,completedAt,updatedAt");

            for (Student s : students) {
                for (RecoveryRecord r : s.getRecoveryRecords()) {
                    pw.println(r.toFileFormat());
                }
            }
            System.out.println("[FILE] Recovery records saved to: " + file.getAbsolutePath());
        } catch (Exception e) {
            System.err.println("Error saving recovery records: " + e.getMessage());
        }
    }

    /**
     * Load recovery records from file and attach to students
     */
    public static void loadRecoveryRecords(Map<String, Student> studentMap) {
        File file = new File(RECOVERY_RECORDS_FILE);
        if (!file.exists()) {
            System.out.println("[FILE] No recovery records file found.");
            return;
        }

        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String line;
            boolean firstLine = true;
            int loaded = 0;

            while ((line = br.readLine()) != null) {
                if (firstLine) {
                    firstLine = false;
                    continue;
                } // Skip header
                if (line.trim().isEmpty())
                    continue;

                RecoveryRecord r = RecoveryRecord.fromFileFormat(line);
                if (r != null) {
                    Student s = studentMap.get(r.getStudentId());
                    if (s != null) {
                        s.addRecoveryRecord(r);
                        loaded++;
                    }
                }
            }
            System.out.println("[FILE] Loaded " + loaded + " recovery records.");
        } catch (Exception e) {
            System.err.println("Error loading recovery records: " + e.getMessage());
        }
    }

    // ==================== MILESTONES ====================

    /**
     * Save all milestones to file
     */
    public static void saveMilestones(Collection<Student> students) {
        File file = new File(MILESTONES_FILE);
        file.getParentFile().mkdirs();

        try (PrintWriter pw = new PrintWriter(new FileWriter(file))) {
            pw.println("studentId,milestoneId,courseId,description,targetDate,completed");

            for (Student s : students) {
                for (Milestone m : s.getMilestones()) {
                    pw.printf("%s,%s,%s,%s,%s,%s%n",
                            s.getId(),
                            m.getId(),
                            safeCsv(m.getCourseId()),
                            safeCsv(m.getDescription()),
                            safeCsv(m.getStudyWeek()),
                            m.isCompleted() ? "1" : "0");
                }
            }
            System.out.println("[FILE] Milestones saved to: " + file.getAbsolutePath());
        } catch (Exception e) {
            System.err.println("Error saving milestones: " + e.getMessage());
        }
    }

    /**
     * Load milestones from file and attach to students
     */
    public static void loadMilestones(Map<String, Student> studentMap) {
        File file = new File(MILESTONES_FILE);
        if (!file.exists())
            return;

        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String line;
            boolean firstLine = true;
            int loaded = 0;

            while ((line = br.readLine()) != null) {
                if (firstLine) {
                    firstLine = false;
                    continue;
                }
                if (line.trim().isEmpty())
                    continue;

                String[] parts = line.split(",");
                if (parts.length < 6)
                    continue;

                String studentId = parts[0];
                Student s = studentMap.get(studentId);
                if (s == null)
                    continue;

                Milestone m = new Milestone(parts[1], parts[2], parts[3], parts[4]);
                m.setCompleted("1".equals(parts[5]));
                s.addMilestone(m);
                loaded++;
            }
            System.out.println("[FILE] Loaded " + loaded + " milestones.");
        } catch (Exception e) {
            System.err.println("Error loading milestones: " + e.getMessage());
        }
    }

    // ==================== RECOMMENDATIONS ====================

    /**
     * Save all recommendations to file
     */
    public static void saveRecommendations(Collection<Student> students) {
        File file = new File(RECOMMENDATIONS_FILE);
        file.getParentFile().mkdirs();

        try (PrintWriter pw = new PrintWriter(new FileWriter(file))) {
            pw.println("studentId,recommendationId,lecturerId,courseId,text");

            for (Student s : students) {
                for (Recommendation r : s.getRecommendations()) {
                    pw.printf("%s,%s,%s,%s,%s%n",
                            s.getId(),
                            r.getId(),
                            safeCsv(r.getLecturer()),
                            safeCsv(r.getCourseId()),
                            safeCsv(r.getText()));
                }
            }
            System.out.println("[FILE] Recommendations saved to: " + file.getAbsolutePath());
        } catch (Exception e) {
            System.err.println("Error saving recommendations: " + e.getMessage());
        }
    }

    /**
     * Load recommendations from file and attach to students
     */
    public static void loadRecommendations(Map<String, Student> studentMap) {
        File file = new File(RECOMMENDATIONS_FILE);
        if (!file.exists())
            return;

        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String line;
            boolean firstLine = true;
            int loaded = 0;

            while ((line = br.readLine()) != null) {
                if (firstLine) {
                    firstLine = false;
                    continue;
                }
                if (line.trim().isEmpty())
                    continue;

                String[] parts = line.split(",", 5);
                if (parts.length < 5)
                    continue;

                String studentId = parts[0];
                Student s = studentMap.get(studentId);
                if (s == null)
                    continue;

                Recommendation r = new Recommendation(parts[1], parts[2], studentId, parts[3], parts[4]);
                s.addRecommendation(r);
                loaded++;
            }
            System.out.println("[FILE] Loaded " + loaded + " recommendations.");
        } catch (Exception e) {
            System.err.println("Error loading recommendations: " + e.getMessage());
        }
    }

    // ==================== HELPER METHODS ====================

    /**
     * Save all recovery data (records, milestones, recommendations)
     */
    public static void saveAllRecoveryData(Collection<Student> students) {
        saveRecoveryRecords(students);
        saveMilestones(students);
        saveRecommendations(students);
    }

    /**
     * Load all recovery data (records, milestones, recommendations)
     */
    public static void loadAllRecoveryData(Map<String, Student> studentMap) {
        loadRecoveryRecords(studentMap);
        loadMilestones(studentMap);
        loadRecommendations(studentMap);
    }

    /**
     * Make string safe for CSV (escape commas)
     */
    private static String safeCsv(String s) {
        if (s == null)
            return "";
        return s.replace(",", ";");
    }
}
