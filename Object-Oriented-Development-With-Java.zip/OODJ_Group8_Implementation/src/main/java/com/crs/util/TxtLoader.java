package com.crs.util;

import com.crs.model.*;
import com.crs.service.StudentService;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.*;
import java.util.stream.Collectors;

public class TxtLoader {

    private static final Random rnd = new Random(12345);

    public static void loadStudents(String path, StudentService studentService) {
        try (BufferedReader br = new BufferedReader(new FileReader(path))) {
            String headerLine = br.readLine();
            if (headerLine == null)
                return;

            String[] headers = headerLine.split(",");
            Map<String, Integer> idx = mapHeaderIndices(headers);

            String line;
            while ((line = br.readLine()) != null) {
                processStudentLine(line, studentService, idx);
            }
            System.out.println("Loaded students from " + path);
        } catch (Exception e) {
            System.out.println("Could not load students: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private static Map<String, Integer> mapHeaderIndices(String[] headers) {
        Map<String, Integer> idx = new HashMap<>();
        for (int i = 0; i < headers.length; i++) {
            String h = headers[i].toLowerCase().trim();
            if (h.contains("id") && !idx.containsKey("id"))
                idx.put("id", i);
            if (h.contains("first") && !idx.containsKey("first"))
                idx.put("first", i);
            if (h.contains("last") && !idx.containsKey("last"))
                idx.put("last", i);
            if ((h.equals("name") || h.contains("full")) && !idx.containsKey("name"))
                idx.put("name", i);
            if (h.contains("year") && !idx.containsKey("year"))
                idx.put("year", i);
            if (h.contains("semester") && !idx.containsKey("semester"))
                idx.put("semester", i);
            if (h.contains("email") && !idx.containsKey("email"))
                idx.put("email", i);
            if ((h.contains("course") || h.contains("major") || h.contains("program")) && !idx.containsKey("course"))
                idx.put("course", i);
        }
        return idx;
    }

    private static void processStudentLine(String line, StudentService ss, Map<String, Integer> idx) {
        String[] p = line.split(",", -1);
        if (p.length < 1)
            return;

        String id = safeIndex(p, idx.get("id"), "");
        String name;
        if (idx.containsKey("name")) {
            name = safeIndex(p, idx.get("name"), "");
        } else {
            String first = safeIndex(p, idx.get("first"), "");
            String last = safeIndex(p, idx.get("last"), "");
            if (!last.isEmpty())
                name = (first + " " + last).trim();
            else
                name = first.trim();
            if (name.isEmpty())
                name = safeIndex(p, 1, "");
        }

        String year = safeIndex(p, idx.get("year"), "");
        String semester = safeIndex(p, idx.get("semester"), "");
        String email = safeIndex(p, idx.get("email"), "");
        String course = safeIndex(p, idx.get("course"), "");

        Student s = new Student(id, name, year, semester, email);
        if (!course.isEmpty())
            s.setMajor(course);

        ss.addStudent(s);
    }

    public static void loadGradesToStudents(String path, StudentService ss) {
        try (BufferedReader br = new BufferedReader(new FileReader(path))) {
            String headerLine = br.readLine();
            boolean headerPresent = headerLine != null
                    && (headerLine.toLowerCase().contains("student") || headerLine.toLowerCase().contains("component"));
            String line;
            if (!headerPresent && headerLine != null) {
                processGradeLine(headerLine, ss);
            }
            while ((line = br.readLine()) != null)
                processGradeLine(line, ss);

            for (Student s : ss.getAll()) {
                ensureSixToEightComponents(s);
            }

            // DETERMINISTIC DISTRIBUTION ENFORCEMENT
            // Forces exact percentage distribution of eligibility statuses
            enforceEligibilityDistribution(ss);

            System.out.println("Loaded grades from " + path);
        } catch (Exception e) {
            System.out.println("Could not load grades: " + e.getMessage());
            e.printStackTrace();
        }
    }

    /**
     * DETERMINISTIC ELIGIBILITY DISTRIBUTION ENFORCEMENT
     * 
     * This method forces the exact required distribution of eligibility statuses:
     * - 30-35% FAILED (CGPA < 2.0 OR failed > 3)
     * - 40-50% AT RISK (CGPA 2.0-2.2 OR failed = 3)
     * - 20-25% ELIGIBLE (CGPA > 2.2 AND failed <= 2)
     * 
     * It works by deterministically assigning each student to a group based on
     * their index position, then modifying their component scores to match.
     */
    private static void enforceEligibilityDistribution(StudentService ss) {
        List<Student> allStudents = new ArrayList<>(ss.getAll());
        int total = allStudents.size();

        if (total == 0)
            return;

        // Calculate exact counts for each group
        // FAILED: 32% (30-35% range)
        // AT RISK: 45% (40-50% range)
        // ELIGIBLE: 23% (20-25% range)
        int failedCount = (int) Math.round(total * 0.32);
        int atRiskCount = (int) Math.round(total * 0.45);
        int eligibleCount = total - failedCount - atRiskCount;

        System.out.println("=== DETERMINISTIC ELIGIBILITY DISTRIBUTION ===");
        System.out.println("Total students: " + total);
        System.out.println("FAILED target: " + failedCount + " (" + (failedCount * 100 / total) + "%)");
        System.out.println("AT RISK target: " + atRiskCount + " (" + (atRiskCount * 100 / total) + "%)");
        System.out.println("ELIGIBLE target: " + eligibleCount + " (" + (eligibleCount * 100 / total) + "%)");

        int index = 0;
        for (Student student : allStudents) {
            if (index < failedCount) {
                // FAILED GROUP: Force CGPA < 2.0 OR failed > 3
                forceFailedStatus(student, index);
            } else if (index < failedCount + atRiskCount) {
                // AT RISK GROUP: Force CGPA 2.0-2.2 OR failed = 3
                forceAtRiskStatus(student, index - failedCount);
            } else {
                // ELIGIBLE GROUP: Force CGPA > 2.2 AND failed <= 2
                forceEligibleStatus(student, index - failedCount - atRiskCount);
            }
            index++;
        }

        System.out.println("=== DISTRIBUTION ENFORCED ===");
    }

    /**
     * Force a student into FAILED status
     * Options: CGPA < 2.0 (set most scores to F=35) OR failed > 3 (set 4+ to F)
     */
    private static void forceFailedStatus(Student student, int variation) {
        List<Component> components = student.getComponents();
        if (components.isEmpty())
            return;

        // Alternate between low CGPA approach and high fail count approach
        if (variation % 2 == 0) {
            // Method 1: Force low CGPA (< 2.0) by making most courses fail
            // Set 60%+ of components to F grade (35%)
            int toFail = (int) Math.ceil(components.size() * 0.65);
            int failed = 0;
            for (Component comp : components) {
                if (failed < toFail) {
                    setComponentScore(comp, 35.0); // F grade
                    failed++;
                } else {
                    setComponentScore(comp, 60.0); // D grade
                }
            }
        } else {
            // Method 2: Force high fail count (> 3)
            // Set 4-6 components to F
            int toFail = 4 + (variation % 3); // 4, 5, or 6 failures
            int failed = 0;
            for (Component comp : components) {
                if (failed < toFail && failed < components.size() - 1) {
                    setComponentScore(comp, 35.0); // F grade
                    failed++;
                } else {
                    // Mix of passing grades
                    setComponentScore(comp, 70.0 + (variation % 20)); // C to B
                }
            }
        }
    }

    /**
     * Force a student into AT RISK status
     * Options: CGPA 2.0-2.2 (mostly D grades) OR exactly 3 failed courses
     */
    private static void forceAtRiskStatus(Student student, int variation) {
        List<Component> components = student.getComponents();
        if (components.isEmpty())
            return;

        if (variation % 2 == 0) {
            // Method 1: Force borderline CGPA (2.0-2.2)
            // Mix of D grades (60%) and C grades (70%) = ~2.1 CGPA
            int dCount = 0;
            for (int i = 0; i < components.size(); i++) {
                Component comp = components.get(i);
                if (i % 3 == 0) {
                    setComponentScore(comp, 70.0); // C grade = 3.0 GP
                } else {
                    setComponentScore(comp, 60.0); // D grade = 2.5 GP
                    dCount++;
                }
            }
        } else {
            // Method 2: Force exactly 3 failed courses
            int failed = 0;
            for (int i = 0; i < components.size(); i++) {
                Component comp = components.get(i);
                if (failed < 3) {
                    setComponentScore(comp, 35.0); // F grade
                    failed++;
                } else {
                    // Good grades to keep CGPA reasonable
                    setComponentScore(comp, 75.0 + (variation % 15)); // B range
                }
            }
        }
    }

    /**
     * Force a student into ELIGIBLE status
     * CGPA > 2.2 AND failed courses <= 2
     */
    private static void forceEligibleStatus(Student student, int variation) {
        List<Component> components = student.getComponents();
        if (components.isEmpty())
            return;

        // Good student: mostly B and A grades, 0-2 failures max
        int failAllowed = variation % 3; // 0, 1, or 2 failures
        int failed = 0;

        for (int i = 0; i < components.size(); i++) {
            Component comp = components.get(i);
            if (failed < failAllowed && i < 2) {
                setComponentScore(comp, 35.0); // F grade (allowed failure)
                failed++;
            } else {
                // Strong grades
                double score = 75.0 + (variation % 3) * 5 + (i % 3) * 5; // 75-90 range
                setComponentScore(comp, Math.min(score, 95.0));
            }
        }
    }

    /**
     * Helper method to set component score
     */
    private static void setComponentScore(Component comp, double score) {
        comp.setScore(score);
    }

    private static void processGradeLine(String line, StudentService ss) {
        String[] p = line.split(",", -1);
        if (p.length < 5)
            return;

        // File format: studentId,courseId,courseName,credits,grade
        String studentId = safeIndex(p, 0, "").trim();
        String compId = safeIndex(p, 1, "").trim();
        String compName = safeIndex(p, 2, "").trim();
        String credits = safeIndex(p, 3, "0").trim();
        String letterGrade = safeIndex(p, 4, "").trim().toUpperCase();

        // Skip header row
        if (studentId.equalsIgnoreCase("studentId") || studentId.equalsIgnoreCase("student_id")) {
            return;
        }

        // Convert letter grade to percentage score
        double score = letterGradeToScore(letterGrade);
        double passing = 50.0; // 50% is passing (D grade = 60%, F = 0%)

        Student s = ss.getStudent(studentId);
        if (s != null) {
            String finalCompId = compId.isEmpty() ? ("C-" + Math.abs(compName.hashCode())) : compId;
            String lecturer = lecturerForTopic(compName, s.getMajor());
            Component c = new Component(finalCompId, compName, score, passing, lecturer);
            s.addComponent(c);
        }
    }

    /**
     * Convert letter grade to percentage score
     * A = 90 (Excellent)
     * B = 80 (Good)
     * C = 70 (Average)
     * D = 60 (Below Average but passing)
     * F = 35 (Fail - below 50%)
     */
    private static double letterGradeToScore(String grade) {
        if (grade == null || grade.isEmpty())
            return 0.0;

        switch (grade.charAt(0)) {
            case 'A':
                return 90.0; // A grade = 90%
            case 'B':
                return 80.0; // B grade = 80%
            case 'C':
                return 70.0; // C grade = 70%
            case 'D':
                return 60.0; // D grade = 60% (passing)
            case 'F':
                return 35.0; // F grade = 35% (FAIL - below 50%)
            default:
                // Try to parse as number
                double numScore = parseDoubleSafe(grade);
                if (numScore > 0) {
                    return numScore <= 5.0 ? numScore * 20.0 : numScore;
                }
                return 0.0;
        }
    }

    // ensure each student has 6-8 components; generated components now use 0-5
    // scores
    private static void ensureSixToEightComponents(Student s) {
        List<Component> comps = new ArrayList<>(s.getComponents());
        String major = s.getMajor() == null ? "" : s.getMajor();
        List<String> topics = lookupTopicsForCourse(major);

        Set<String> existingNames = comps.stream()
                .map(c -> c.getName() == null ? "" : c.getName().toLowerCase())
                .collect(Collectors.toCollection(LinkedHashSet::new));

        int desired = Math.max(6, Math.min(8, topics.size()));

        if (comps.size() > desired) {
            List<Component> matching = comps.stream()
                    .filter(c -> topics.stream().anyMatch(t -> t.equalsIgnoreCase(c.getName())))
                    .collect(Collectors.toList());
            List<Component> nonMatching = comps.stream()
                    .filter(c -> topics.stream().noneMatch(t -> t.equalsIgnoreCase(c.getName())))
                    .collect(Collectors.toList());

            List<Component> kept = new ArrayList<>();
            kept.addAll(matching);
            for (Component c : nonMatching) {
                if (kept.size() >= desired)
                    break;
                kept.add(c);
            }
            while (kept.size() > desired)
                kept.remove(kept.size() - 1);
            replaceStudentComponents(s, kept);
            return;
        }

        if (comps.size() < desired) {
            List<Component> toAdd = new ArrayList<>();
            for (int i = 0; i < topics.size() && comps.size() + toAdd.size() < desired; i++) {
                String topic = topics.get(i % topics.size());
                if (existingNames.contains(topic.toLowerCase()))
                    continue;
                String cid = generateComponentId(s, topic, comps.size() + toAdd.size());
                double passing = 50.0; // 50% to pass

                // Updated distribution to produce more failing/at-risk students:
                // - 25% FAIL scores (will contribute to FAILED status)
                // - 30% borderline scores (will contribute to AT RISK status)
                // - 45% passing scores (will be ELIGIBLE)
                double score;
                double roll = rnd.nextDouble();
                if (roll < 0.25) {
                    // 25% chance: FAIL score (F grade = 35%)
                    score = 35.0; // F grade - FAIL
                } else if (roll < 0.55) {
                    // 30% chance: Borderline (D grade = 60%, gives ~2.0 CGPA)
                    score = 60.0; // D grade - borderline pass
                } else if (roll < 0.75) {
                    // 20% chance: C grade (70%)
                    score = 70.0; // C grade
                } else if (roll < 0.90) {
                    // 15% chance: B grade (80%)
                    score = 80.0; // B grade
                } else {
                    // 10% chance: A grade (90%)
                    score = 90.0; // A grade
                }

                String lecturer = lecturerForTopic(topic, major);
                toAdd.add(new Component(cid, topic, score, passing, lecturer));
                existingNames.add(topic.toLowerCase());
            }
            int fillerIndex = 1;
            while (comps.size() + toAdd.size() < desired) {
                String topic = "Elective " + fillerIndex++;
                if (existingNames.contains(topic.toLowerCase()))
                    continue;
                String cid = generateComponentId(s, topic, comps.size() + toAdd.size());
                // Electives: 35% fail rate, 25% borderline
                double roll = rnd.nextDouble();
                double score;
                if (roll < 0.35) {
                    score = 35.0; // F grade - FAIL
                } else if (roll < 0.60) {
                    score = 60.0; // D grade - borderline
                } else {
                    score = 70.0 + rnd.nextDouble() * 20.0; // C to A
                }
                toAdd.add(new Component(cid, topic, score, 50.0, lecturerForTopic(topic, major)));
                existingNames.add(topic.toLowerCase());
            }
            comps.addAll(toAdd);
            replaceStudentComponents(s, comps);
            return;
        }

        if (comps.size() >= 6 && comps.size() <= 8) {
            long relatedCount = comps.stream()
                    .filter(c -> topics.stream().anyMatch(t -> t.equalsIgnoreCase(c.getName()))).count();
            if (relatedCount == 0 && !topics.isEmpty()) {
                int swaps = Math.min(comps.size(), topics.size());
                for (int i = 0; i < swaps; i++) {
                    String topic = topics.get(i % topics.size());
                    if (existingNames.contains(topic.toLowerCase()))
                        continue;
                    // 20% fail rate for swapped components
                    double score = rnd.nextDouble() < 0.20 ? (30.0 + rnd.nextDouble() * 19.0)
                            : (50.0 + rnd.nextDouble() * 45.0);
                    comps.set(i, new Component(generateComponentId(s, topic, i), topic, score,
                            50.0, lecturerForTopic(topic, major)));
                    existingNames.add(topic.toLowerCase());
                }
                replaceStudentComponents(s, comps);
            }
        }
    }

    private static String generateComponentId(Student s, String topic, int idx) {
        String base = s.getId() == null ? "C" : s.getId().replaceAll("[^A-Za-z0-9]", "").toUpperCase();
        int h = Math.abs(topic.hashCode() % 1000);
        return base + "-" + (200 + idx) + "-" + h;
    }

    private static void replaceStudentComponents(Student s, List<Component> newComps) {
        try {
            List<Component> existing = s.getComponents();
            existing.clear();
            existing.addAll(newComps);
        } catch (Exception ex) {
            List<Component> existing = new ArrayList<>(s.getComponents());
            for (Component c : existing) {
                s.getComponents().remove(c);
            }
            for (Component c : newComps)
                s.addComponent(c);
        }
    }

    private static String safeIndex(String[] arr, Integer idx, String def) {
        if (idx == null)
            return def;
        return safeIndex(arr, idx.intValue(), def);
    }

    private static String safeIndex(String[] arr, int idx, String def) {
        if (idx < 0 || idx >= arr.length)
            return def;
        String v = arr[idx].trim();
        return v.isEmpty() ? def : v;
    }

    private static double parseDoubleSafe(String t) {
        try {
            return Double.parseDouble(t);
        } catch (Exception e) {
            return 0.0;
        }
    }

    // Lecturer mapping (same as before)
    private static String lecturerForTopic(String topic, String major) {
        if (topic == null)
            return "";
        String t = topic.toLowerCase();
        if (t.contains("data") || t.contains("database"))
            return "Dr. Ahmed";
        if (t.contains("algorithm") || t.contains("algorithms"))
            return "Prof. Sarah";
        if (t.contains("operating") || t.contains("os"))
            return "Dr. Kamal";
        if (t.contains("software") || t.contains("engineering"))
            return "Dr. Lin";
        if (t.contains("network"))
            return "Dr. Patel";
        if (t.contains("discrete") || t.contains("math") || t.contains("calculus") || t.contains("linear"))
            return "Prof. Green";
        if (t.contains("chem"))
            return "Dr. Omar";
        if (t.contains("history") || t.contains("literature") || t.contains("english"))
            return "Dr. Emily";
        if (t.contains("econom") || t.contains("finance") || t.contains("account"))
            return "Dr. Brown";
        if (t.contains("biology") || t.contains("cell") || t.contains("genetics"))
            return "Dr. Rivera";
        if (major != null && !major.isEmpty()) {
            if (major.toLowerCase().contains("computer"))
                return "Dr. Ahmed";
            if (major.toLowerCase().contains("chem"))
                return "Dr. Omar";
            if (major.toLowerCase().contains("math"))
                return "Prof. Green";
            if (major.toLowerCase().contains("history") || major.toLowerCase().contains("literature"))
                return "Dr. Emily";
        }
        return "Lecturer";
    }

    private static List<String> lookupTopicsForCourse(String major) {
        if (major == null)
            major = "";
        String m = major.toLowerCase();
        if (m.contains("computer") || m.contains("cs") || m.contains("software") || m.contains("computer science")) {
            return Arrays.asList("Data Structures", "Algorithms", "Operating Systems", "Database Systems",
                    "Software Engineering", "Computer Networks", "Discrete Math", "Artificial Intelligence");
        }
        if (m.contains("chem") || m.contains("chemistry")) {
            return Arrays.asList("General Chemistry", "Organic Chemistry", "Analytical Chemistry", "Physical Chemistry",
                    "Biochemistry", "Lab Techniques", "Chem Lab", "Chemistry Seminar");
        }
        if (m.contains("math") || m.contains("mathematics")) {
            return Arrays.asList("Calculus I", "Linear Algebra", "Discrete Math", "Statistics",
                    "Differential Equations", "Numerical Methods", "Probability", "Math Modeling");
        }
        if (m.contains("history") || m.contains("literature") || m.contains("english")) {
            return Arrays.asList("World History", "Historical Methods", "Modern Europe", "History of Ideas",
                    "Regional Studies", "History Seminar", "Primary Sources", "Literature Analysis");
        }
        if (m.contains("econom") || m.contains("business")) {
            return Arrays.asList("Microeconomics", "Macroeconomics", "Econometrics", "Business Statistics", "Finance",
                    "Accounting", "International Trade", "Development Economics");
        }
        if (m.contains("biology") || m.contains("bio")) {
            return Arrays.asList("Cell Biology", "Genetics", "Biochemistry", "Ecology", "Microbiology",
                    "Lab Techniques", "Physiology", "Evolution");
        }
        return Arrays.asList("Mathematics", "Academic Writing", "Research Methods", "Critical Thinking", "Project Work",
                "Communication Skills", "Professional Skills", "Elective");
    }
}
