package com.crs.util;

import com.crs.model.*;
import com.crs.service.StudentService;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.*;
import java.util.stream.Collectors;

public class CsvLoader {

    private static final Random rnd = new Random(12345);

    public static void loadStudents(String path, StudentService studentService) {
        try (BufferedReader br = new BufferedReader(new FileReader(path))) {
            String headerLine = br.readLine();
            if (headerLine == null) return;

            String[] headers = headerLine.split(",");
            Map<String,Integer> idx = mapHeaderIndices(headers);

            String line;
            while ((line = br.readLine()) != null) {
                processStudentLine(line, studentService, idx);
            }
            System.out.println("Loaded students from " + path);
        } catch (Exception e) {
            System.out.println("Could not load students: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private static Map<String,Integer> mapHeaderIndices(String[] headers) {
        Map<String,Integer> idx = new HashMap<>();
        for (int i = 0; i < headers.length; i++) {
            String h = headers[i].toLowerCase().trim();
            if (h.contains("id") && !idx.containsKey("id")) idx.put("id", i);
            if (h.contains("first") && !idx.containsKey("first")) idx.put("first", i);
            if (h.contains("last") && !idx.containsKey("last")) idx.put("last", i);
            if ((h.equals("name") || h.contains("full")) && !idx.containsKey("name")) idx.put("name", i);
            if (h.contains("year") && !idx.containsKey("year")) idx.put("year", i);
            if (h.contains("semester") && !idx.containsKey("semester")) idx.put("semester", i);
            if (h.contains("email") && !idx.containsKey("email")) idx.put("email", i);
            if ((h.contains("course") || h.contains("major") || h.contains("program")) && !idx.containsKey("course")) idx.put("course", i);
        }
        return idx;
    }

    private static void processStudentLine(String line, StudentService ss, Map<String,Integer> idx) {
        String[] p = line.split(",", -1);
        if (p.length < 1) return;

        String id = safeIndex(p, idx.get("id"), "");
        String name;
        if (idx.containsKey("name")) {
            name = safeIndex(p, idx.get("name"), "");
        } else {
            String first = safeIndex(p, idx.get("first"), "");
            String last = safeIndex(p, idx.get("last"), "");
            if (!last.isEmpty()) name = (first + " " + last).trim();
            else name = first.trim();
            if (name.isEmpty()) name = safeIndex(p, 1, "");
        }

        String year = safeIndex(p, idx.get("year"), "");
        String semester = safeIndex(p, idx.get("semester"), "");
        String email = safeIndex(p, idx.get("email"), "");
        String course = safeIndex(p, idx.get("course"), "");

        Student s = new Student(id, name, year, semester, email);
        if (!course.isEmpty()) s.setMajor(course);

        ss.addStudent(s);
    }

    public static void loadGradesToStudents(String path, StudentService ss) {
        try (BufferedReader br = new BufferedReader(new FileReader(path))) {
            String headerLine = br.readLine();
            boolean headerPresent = headerLine != null && (headerLine.toLowerCase().contains("student") || headerLine.toLowerCase().contains("component"));
            String line;
            if (!headerPresent && headerLine != null) {
                processGradeLine(headerLine, ss);
            }
            while ((line = br.readLine()) != null) processGradeLine(line, ss);

            for (Student s : ss.getAll()) {
                ensureSixToEightComponents(s);
            }
            System.out.println("Loaded grades from " + path);
        } catch (Exception e) {
            System.out.println("Could not load grades: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private static void processGradeLine(String line, StudentService ss) {
        String[] p = line.split(",", -1);
        if (p.length < 4) return;

        String studentId = safeIndex(p, 0, "");
        String compId = safeIndex(p, 1, "");
        String compName = safeIndex(p, 2, "");
        String rawScore = safeIndex(p, 3, "0");
        double score = parseDoubleSafe(rawScore);
        // If score seems on 0-100 scale, convert to 0-5
        if (score > 5.0) score = Math.max(0.0, Math.min(5.0, score / 20.0));

        double passing = 2.0; // GPA-style pass threshold by default
        if (p.length > 4) {
            // if CSV supplied a passing mark and it's >5, convert; if it's <=5, use as-is
            double rawPass = parseDoubleSafe(safeIndex(p, 4, ""));
            if (rawPass > 0.0) {
                passing = rawPass > 5.0 ? Math.max(0.0, Math.min(5.0, rawPass / 20.0)) : rawPass;
            }
        }

        Student s = ss.getStudent(studentId);
        if (s != null) {
            String finalCompId = compId.isEmpty() ? ("C-" + Math.abs(compName.hashCode())) : compId;
            String lecturer = lecturerForTopic(compName, s.getMajor());
            Component c = new Component(finalCompId, compName, score, passing, lecturer);
            s.addComponent(c);
        }
    }

    // ensure each student has 6-8 components; generated components now use 0-5 scores
    private static void ensureSixToEightComponents(Student s) {
        List<Component> comps = new ArrayList<>(s.getComponents());
        String major = s.getMajor() == null ? "" : s.getMajor();
        List<String> topics = lookupTopicsForCourse(major);

        Set<String> existingNames = comps.stream()
                .map(c -> c.getName() == null ? "" : c.getName().toLowerCase())
                .collect(Collectors.toCollection(LinkedHashSet::new));

        int desired = Math.max(6, Math.min(8, topics.size()));

        if (comps.size() > desired) {
            List<Component> matching = comps.stream()
                    .filter(c -> topics.stream().anyMatch(t -> t.equalsIgnoreCase(c.getName())))
                    .collect(Collectors.toList());
            List<Component> nonMatching = comps.stream()
                    .filter(c -> topics.stream().noneMatch(t -> t.equalsIgnoreCase(c.getName())))
                    .collect(Collectors.toList());

            List<Component> kept = new ArrayList<>();
            kept.addAll(matching);
            for (Component c : nonMatching) {
                if (kept.size() >= desired) break;
                kept.add(c);
            }
            while (kept.size() > desired) kept.remove(kept.size() - 1);
            replaceStudentComponents(s, kept);
            return;
        }

        if (comps.size() < desired) {
            List<Component> toAdd = new ArrayList<>();
            for (int i = 0; i < topics.size() && comps.size() + toAdd.size() < desired; i++) {
                String topic = topics.get(i % topics.size());
                if (existingNames.contains(topic.toLowerCase())) continue;
                String cid = generateComponentId(s, topic, comps.size() + toAdd.size());
                double passing = 2.0;
                double score = 1.0 + rnd.nextDouble() * 4.0; // 1.0 .. 5.0
                String lecturer = lecturerForTopic(topic, major);
                toAdd.add(new Component(cid, topic, score, passing, lecturer));
                existingNames.add(topic.toLowerCase());
            }
            int fillerIndex = 1;
            while (comps.size() + toAdd.size() < desired) {
                String topic = "Elective " + fillerIndex++;
                if (existingNames.contains(topic.toLowerCase())) continue;
                String cid = generateComponentId(s, topic, comps.size() + toAdd.size());
                double score = 1.0 + rnd.nextDouble() * 4.0;
                toAdd.add(new Component(cid, topic, score, 2.0, lecturerForTopic(topic, major)));
                existingNames.add(topic.toLowerCase());
            }
            comps.addAll(toAdd);
            replaceStudentComponents(s, comps);
            return;
        }

        if (comps.size() >= 6 && comps.size() <= 8) {
            long relatedCount = comps.stream().filter(c -> topics.stream().anyMatch(t -> t.equalsIgnoreCase(c.getName()))).count();
            if (relatedCount == 0 && !topics.isEmpty()) {
                int swaps = Math.min(comps.size(), topics.size());
                for (int i = 0; i < swaps; i++) {
                    String topic = topics.get(i % topics.size());
                    if (existingNames.contains(topic.toLowerCase())) continue;
                    comps.set(i, new Component(generateComponentId(s, topic, i), topic, 2.5 + rnd.nextDouble() * 2.5, 2.0, lecturerForTopic(topic, major)));
                    existingNames.add(topic.toLowerCase());
                }
                replaceStudentComponents(s, comps);
            }
        }
    }

    private static String generateComponentId(Student s, String topic, int idx) {
        String base = s.getId() == null ? "C" : s.getId().replaceAll("[^A-Za-z0-9]", "").toUpperCase();
        int h = Math.abs(topic.hashCode() % 1000);
        return base + "-" + (200 + idx) + "-" + h;
    }

    private static void replaceStudentComponents(Student s, List<Component> newComps) {
        try {
            List<Component> existing = s.getComponents();
            existing.clear();
            existing.addAll(newComps);
        } catch (Exception ex) {
            List<Component> existing = new ArrayList<>(s.getComponents());
            for (Component c : existing) { s.getComponents().remove(c); }
            for (Component c : newComps) s.addComponent(c);
        }
    }

    private static String safeIndex(String[] arr, Integer idx, String def) {
        if (idx == null) return def;
        return safeIndex(arr, idx.intValue(), def);
    }
    private static String safeIndex(String[] arr, int idx, String def) {
        if (idx < 0 || idx >= arr.length) return def;
        String v = arr[idx].trim();
        return v.isEmpty() ? def : v;
    }
    private static double parseDoubleSafe(String t) {
        try { return Double.parseDouble(t); } catch (Exception e) { return 0.0; }
    }

    // Lecturer mapping (same as before)
    private static String lecturerForTopic(String topic, String major) {
        if (topic == null) return "";
        String t = topic.toLowerCase();
        if (t.contains("data") || t.contains("database")) return "Dr. Ahmed";
        if (t.contains("algorithm") || t.contains("algorithms")) return "Prof. Sarah";
        if (t.contains("operating") || t.contains("os")) return "Dr. Kamal";
        if (t.contains("software") || t.contains("engineering")) return "Dr. Lin";
        if (t.contains("network")) return "Dr. Patel";
        if (t.contains("discrete") || t.contains("math") || t.contains("calculus") || t.contains("linear")) return "Prof. Green";
        if (t.contains("chem")) return "Dr. Omar";
        if (t.contains("history") || t.contains("literature") || t.contains("english")) return "Dr. Emily";
        if (t.contains("econom") || t.contains("finance") || t.contains("account")) return "Dr. Brown";
        if (t.contains("biology") || t.contains("cell") || t.contains("genetics")) return "Dr. Rivera";
        if (major != null && !major.isEmpty()) {
            if (major.toLowerCase().contains("computer")) return "Dr. Ahmed";
            if (major.toLowerCase().contains("chem")) return "Dr. Omar";
            if (major.toLowerCase().contains("math")) return "Prof. Green";
            if (major.toLowerCase().contains("history") || major.toLowerCase().contains("literature")) return "Dr. Emily";
        }
        return "Lecturer";
    }

    private static List<String> lookupTopicsForCourse(String major) {
        if (major == null) major = "";
        String m = major.toLowerCase();
        if (m.contains("computer") || m.contains("cs") || m.contains("software") || m.contains("computer science")) {
            return Arrays.asList("Data Structures", "Algorithms", "Operating Systems", "Database Systems", "Software Engineering", "Computer Networks", "Discrete Math", "Artificial Intelligence");
        }
        if (m.contains("chem") || m.contains("chemistry")) {
            return Arrays.asList("General Chemistry", "Organic Chemistry", "Analytical Chemistry", "Physical Chemistry", "Biochemistry", "Lab Techniques", "Chem Lab", "Chemistry Seminar");
        }
        if (m.contains("math") || m.contains("mathematics")) {
            return Arrays.asList("Calculus I", "Linear Algebra", "Discrete Math", "Statistics", "Differential Equations", "Numerical Methods", "Probability", "Math Modeling");
        }
        if (m.contains("history") || m.contains("literature") || m.contains("english")) {
            return Arrays.asList("World History", "Historical Methods", "Modern Europe", "History of Ideas", "Regional Studies", "History Seminar", "Primary Sources", "Literature Analysis");
        }
        if (m.contains("econom") || m.contains("business")) {
            return Arrays.asList("Microeconomics", "Macroeconomics", "Econometrics", "Business Statistics", "Finance", "Accounting", "International Trade", "Development Economics");
        }
        if (m.contains("biology") || m.contains("bio")) {
            return Arrays.asList("Cell Biology", "Genetics", "Biochemistry", "Ecology", "Microbiology", "Lab Techniques", "Physiology", "Evolution");
        }
        return Arrays.asList("Mathematics", "Academic Writing", "Research Methods", "Critical Thinking", "Project Work", "Communication Skills", "Professional Skills", "Elective");
    }
}
