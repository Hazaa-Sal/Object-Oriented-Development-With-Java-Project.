/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package crs;

public class AcademicOfficer extends User {
    public AcademicOfficer(String userID, String name, String email, String passwordHash, boolean active) {
        super(userID, name, email, passwordHash, Role.ACADEMIC_OFFICER, active);
    }

    public void showMenu() {
        System.out.println("=== Academic Officer Menu ===");
        System.out.println("1. Login");
        System.out.println("2. Recover Password");
        System.out.println("3. Update Profile");
        System.out.println("4. Logout");
    }
}




