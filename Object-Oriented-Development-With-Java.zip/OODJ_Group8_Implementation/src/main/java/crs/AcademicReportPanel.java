/*
 * AcademicReportPanel - Modernized with UIStyle
 * Academic Performance Report Panel
 */
package crs;

import com.crs.model.Student;
import com.crs.model.Component;
import com.crs.service.StudentService;
import com.crs.service.ReportService;
import javax.swing.*;
import javax.swing.table.*;
import java.awt.*;
import java.util.List;

public class AcademicReportPanel extends JPanel {
    private StudentService studentService;
    private ReportService reportService;
    private EmailService emailService;
    private Runnable onBack;

    private JComboBox<String> studentCombo;
    private JTable reportTable;
    private DefaultTableModel tableModel;
    private JLabel cgpaLabel;
    private JLabel statusLabel;
    private JTextArea summaryArea;

    public AcademicReportPanel(StudentService studentService,
            ReportService reportService,
            EmailService emailService,
            Runnable onBack) {
        this.studentService = studentService;
        this.reportService = reportService;
        this.emailService = emailService;
        this.onBack = onBack;

        setLayout(new BorderLayout());
        setBackground(UIStyle.BACKGROUND);

        initializeComponents();
        loadStudents();
    }

    private void initializeComponents() {
        // Header
        add(createHeaderPanel(), BorderLayout.NORTH);

        // Main content
        add(createContentPanel(), BorderLayout.CENTER);

        // Action buttons
        add(createActionPanel(), BorderLayout.SOUTH);
    }

    private JPanel createHeaderPanel() {
        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBackground(UIStyle.CARD_BG);
        headerPanel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(0, 0, 2, 0, UIStyle.BORDER_LIGHT),
                BorderFactory.createEmptyBorder(20, 30, 20, 30)));

        JLabel titleLabel = UIStyle.createTitleLabel("Academic Performance Report");

        JButton backBtn = UIStyle.createSecondaryButton("Back");
        backBtn.setPreferredSize(new Dimension(100, 40));
        backBtn.addActionListener(e -> onBack.run());

        headerPanel.add(titleLabel, BorderLayout.WEST);
        headerPanel.add(backBtn, BorderLayout.EAST);

        return headerPanel;
    }

    private JPanel createContentPanel() {
        JPanel contentPanel = new JPanel(new BorderLayout(0, 20));
        contentPanel.setBackground(UIStyle.BACKGROUND);
        contentPanel.setBorder(BorderFactory.createEmptyBorder(20, 30, 20, 30));

        // Student Selection
        JPanel selectionPanel = createSelectionPanel();
        contentPanel.add(selectionPanel, BorderLayout.NORTH);

        // Report Table
        JPanel tablePanel = createTablePanel();
        contentPanel.add(tablePanel, BorderLayout.CENTER);

        // Summary Panel
        JPanel summaryPanel = createSummaryPanel();
        contentPanel.add(summaryPanel, BorderLayout.EAST);

        return contentPanel;
    }

    private JPanel createSelectionPanel() {
        JPanel panel = UIStyle.createCard();
        panel.setLayout(new FlowLayout(FlowLayout.LEFT, 15, 15));

        JLabel label = new JLabel("Select Student:");
        label.setFont(UIStyle.FONT_BODY_BOLD);
        label.setForeground(UIStyle.TEXT_PRIMARY);

        studentCombo = new JComboBox<>();
        studentCombo.setFont(UIStyle.FONT_BODY);
        studentCombo.setPreferredSize(new Dimension(350, 35));
        studentCombo.addActionListener(e -> loadStudentReport());

        JButton refreshBtn = UIStyle.createAccentButton("Refresh");
        refreshBtn.setPreferredSize(new Dimension(120, 35));
        refreshBtn.addActionListener(e -> {
            loadStudents();
            loadStudentReport();
        });

        panel.add(label);
        panel.add(studentCombo);
        panel.add(refreshBtn);

        return panel;
    }

    private JPanel createTablePanel() {
        JPanel panel = UIStyle.createCard();
        panel.setLayout(new BorderLayout());

        JLabel tableTitle = UIStyle.createSubtitleLabel("Course Performance");
        tableTitle.setBorder(BorderFactory.createEmptyBorder(0, 0, 10, 0));
        panel.add(tableTitle, BorderLayout.NORTH);

        String[] columns = { "Component ID", "Component Name", "Lecturer", "Score", "Passing Mark", "Status" };
        tableModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        reportTable = new JTable(tableModel);

        // Apply UIStyle table styling
        UIStyle.styleTable(reportTable);

        // Status column renderer
        reportTable.getColumnModel().getColumn(5).setCellRenderer(new DefaultTableCellRenderer() {
            @Override
            public java.awt.Component getTableCellRendererComponent(JTable table, Object value,
                    boolean isSelected, boolean hasFocus, int row, int column) {
                java.awt.Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row,
                        column);

                if (value != null) {
                    String status = value.toString();
                    if ("PASS".equals(status)) {
                        setForeground(UIStyle.SUCCESS);
                        setText("[+] PASS");
                    } else {
                        setForeground(UIStyle.DANGER);
                        setText("[-] FAIL");
                    }
                    setFont(UIStyle.FONT_BODY_BOLD);
                }

                if (!isSelected) {
                    setBackground(row % 2 == 0 ? UIStyle.CARD_BG : UIStyle.TABLE_ROW_ALT);
                }

                return c;
            }
        });

        JScrollPane scrollPane = new JScrollPane(reportTable);
        scrollPane.setBorder(BorderFactory.createLineBorder(UIStyle.BORDER_LIGHT));

        panel.add(scrollPane, BorderLayout.CENTER);

        return panel;
    }

    private JPanel createSummaryPanel() {
        JPanel panel = UIStyle.createCard();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setPreferredSize(new Dimension(250, 0));

        JLabel summaryTitle = UIStyle.createSubtitleLabel("Summary");
        summaryTitle.setAlignmentX(java.awt.Component.LEFT_ALIGNMENT);
        panel.add(summaryTitle);
        panel.add(Box.createRigidArea(new Dimension(0, 15)));

        // CGPA Display
        JPanel cgpaPanel = new JPanel();
        cgpaPanel.setLayout(new BoxLayout(cgpaPanel, BoxLayout.Y_AXIS));
        cgpaPanel.setBackground(UIStyle.CARD_BG);
        cgpaPanel.setAlignmentX(java.awt.Component.LEFT_ALIGNMENT);

        JLabel cgpaLabelText = UIStyle.createLabel("Average GPA");
        cgpaLabelText.setForeground(UIStyle.TEXT_SECONDARY);

        cgpaLabel = new JLabel("--");
        cgpaLabel.setFont(new Font(UIStyle.FONT_FAMILY, Font.BOLD, 36));
        cgpaLabel.setForeground(UIStyle.PRIMARY);

        cgpaPanel.add(cgpaLabelText);
        cgpaPanel.add(cgpaLabel);

        panel.add(cgpaPanel);
        panel.add(Box.createRigidArea(new Dimension(0, 20)));

        // Status Display
        statusLabel = new JLabel("Status: --");
        statusLabel.setFont(UIStyle.FONT_BODY_BOLD);
        statusLabel.setForeground(UIStyle.TEXT_PRIMARY);
        statusLabel.setAlignmentX(java.awt.Component.LEFT_ALIGNMENT);
        panel.add(statusLabel);
        panel.add(Box.createRigidArea(new Dimension(0, 15)));

        // Summary Text
        summaryArea = new JTextArea(10, 20);
        summaryArea.setFont(UIStyle.FONT_SMALL);
        summaryArea.setLineWrap(true);
        summaryArea.setWrapStyleWord(true);
        summaryArea.setEditable(false);
        summaryArea.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(UIStyle.BORDER_LIGHT),
                BorderFactory.createEmptyBorder(10, 10, 10, 10)));

        JScrollPane scrollPane = new JScrollPane(summaryArea);
        scrollPane.setBorder(BorderFactory.createLineBorder(UIStyle.BORDER_LIGHT));
        scrollPane.setAlignmentX(java.awt.Component.LEFT_ALIGNMENT);

        panel.add(scrollPane);

        return panel;
    }

    private JPanel createActionPanel() {
        JPanel actionPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 20));
        actionPanel.setBackground(UIStyle.BACKGROUND);

        JButton emailBtn = UIStyle.createSuccessButton("Email Report");
        emailBtn.setPreferredSize(new Dimension(160, 45));
        emailBtn.addActionListener(e -> emailReport());

        JButton printBtn = UIStyle.createAccentButton("Print Report");
        printBtn.setPreferredSize(new Dimension(160, 45));
        printBtn.addActionListener(e -> printReport());

        actionPanel.add(emailBtn);
        actionPanel.add(printBtn);

        return actionPanel;
    }

    private void loadStudents() {
        studentCombo.removeAllItems();
        studentCombo.addItem("-- Select Student --");

        for (Student student : studentService.getAll()) {
            String display = student.getId() + " - " + student.getName();
            studentCombo.addItem(display);
        }
    }

    private void loadStudentReport() {
        String selected = (String) studentCombo.getSelectedItem();
        if (selected == null || selected.startsWith("--")) {
            clearReport();
            return;
        }

        String studentId = selected.split(" - ")[0];
        Student student = studentService.getStudent(studentId);

        if (student == null) {
            clearReport();
            return;
        }

        // Clear table
        tableModel.setRowCount(0);

        // Load components
        List<Component> components = student.getComponents();
        int passedCount = 0;
        int failedCount = 0;
        double totalGradePoints = 0; // Sum of grade points (4.0 scale)

        for (Component comp : components) {
            // Convert percentage score to grade point for CGPA calculation
            double gradePoint = scoreToGradePoint(comp.getScore());

            Object[] row = {
                    comp.getId(),
                    comp.getName(),
                    comp.getLecturer(),
                    String.format("%.2f", comp.getScore()),
                    String.format("%.2f", comp.getPassingMark()),
                    comp.isPassed() ? "PASS" : "FAIL"
            };
            tableModel.addRow(row);

            if (comp.isPassed()) {
                passedCount++;
            } else {
                failedCount++;
            }
            totalGradePoints += gradePoint; // Sum grade points, NOT raw scores
        }

        // Calculate CGPA on 4.0 scale (Total Grade Points / Total Courses)
        double cgpa = components.isEmpty() ? 0 : totalGradePoints / components.size();
        cgpaLabel.setText(String.format("%.2f", cgpa)); // Shows 3.25, 2.87, etc.

        // Update status (now using CGPA on 4.0 scale)
        if (cgpa >= 2.0 && failedCount <= 3) {
            statusLabel.setText("[+] Eligible");
            statusLabel.setForeground(UIStyle.SUCCESS);
        } else {
            statusLabel.setText("[-] At Risk");
            statusLabel.setForeground(UIStyle.DANGER);
        }

        // Update summary
        StringBuilder summary = new StringBuilder();
        summary.append("Student: ").append(student.getName()).append("\n");
        summary.append("ID: ").append(student.getId()).append("\n");
        summary.append("Course: ").append(student.getMajor()).append("\n");
        summary.append("Year: ").append(student.getYear()).append("\n\n");
        summary.append("Total Components: ").append(components.size()).append("\n");
        summary.append("Passed: ").append(passedCount).append("\n");
        summary.append("Failed: ").append(failedCount).append("\n\n");
        summary.append("Cumulative GPA: ").append(String.format("%.2f", cgpa)).append(" (4.0 scale)\n");

        summaryArea.setText(summary.toString());
    }

    private void clearReport() {
        tableModel.setRowCount(0);
        cgpaLabel.setText("--");
        statusLabel.setText("Status: --");
        statusLabel.setForeground(UIStyle.TEXT_PRIMARY);
        summaryArea.setText("");
    }

    private void emailReport() {
        String selected = (String) studentCombo.getSelectedItem();
        if (selected == null || selected.startsWith("--")) {
            UIStyle.showWarning(this, "No Selection", "Please select a student first.");
            return;
        }

        String studentId = selected.split(" - ")[0];
        Student student = studentService.getStudent(studentId);

        if (student == null) {
            UIStyle.showError(this, "Error", "Student not found!");
            return;
        }

        // Prompt for real email
        String email = JOptionPane.showInputDialog(this,
                "Enter recipient email address:",
                "Send Academic Report (PDF)",
                JOptionPane.PLAIN_MESSAGE);

        if (email == null || email.trim().isEmpty()) {
            return;
        }

        try {
            // Generate PDF and send as attachment using iText
            emailService.sendAcademicReportWithPdf(student, email.trim());

            UIStyle.showSuccess(this, "Success",
                    "Academic report PDF sent successfully to: " + email +
                            "\n\nThe report includes:\n- Student details\n- Course performance table\n- CGPA calculation\n- Eligibility status");

        } catch (Exception ex) {
            UIStyle.showError(this, "Error", "Failed to send email: " + ex.getMessage());
            ex.printStackTrace();
        }
    }

    private void printReport() {
        String selected = (String) studentCombo.getSelectedItem();
        if (selected == null || selected.startsWith("--")) {
            UIStyle.showWarning(this, "No Selection", "Please select a student first.");
            return;
        }

        String studentId = selected.split(" - ")[0];
        Student student = studentService.getStudent(studentId);

        if (student == null) {
            UIStyle.showError(this, "Error", "Student not found!");
            return;
        }

        String report = reportService.generateTextReport(List.of(student));

        JTextArea textArea = new JTextArea(report);
        textArea.setEditable(false);
        textArea.setFont(new Font("Courier New", Font.PLAIN, 12));

        JScrollPane scrollPane = new JScrollPane(textArea);
        scrollPane.setPreferredSize(new Dimension(600, 400));

        JOptionPane.showMessageDialog(this, scrollPane,
                "Academic Report - " + student.getName(),
                JOptionPane.PLAIN_MESSAGE);
    }

    /**
     * Converts a percentage score (0-100) to grade points on a 4.0 scale.
     * 
     * Grade Scale:
     * - A (90-100): 4.0
     * - B+ (80-89): 3.5
     * - B (70-79): 3.0
     * - C+ (60-69): 2.5
     * - C (50-59): 2.0 (Passing threshold)
     * - D (40-49): 1.5
     * - F (0-39): 0.0
     */
    private double scoreToGradePoint(double percentageScore) {
        if (percentageScore >= 90)
            return 4.0;
        if (percentageScore >= 80)
            return 3.5;
        if (percentageScore >= 70)
            return 3.0;
        if (percentageScore >= 60)
            return 2.5;
        if (percentageScore >= 50)
            return 2.0;
        if (percentageScore >= 40)
            return 1.5;
        return 0.0;
    }
}