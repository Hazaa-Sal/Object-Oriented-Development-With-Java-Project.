/*
 * AccessDeniedPanel - Clean error display for unauthorized access
 * Shows when user tries to access a module they don't have permission for
 */
package crs;

import crs.PermissionService.Module;
import javax.swing.*;
import java.awt.*;

/**
 * Panel displayed when a user attempts to access a module
 * they don't have permission for.
 */
public class AccessDeniedPanel extends JPanel {

    private final Module deniedModule;
    private final User user;
    private final Runnable onBack;

    public AccessDeniedPanel(Module deniedModule, User user, Runnable onBack) {
        this.deniedModule = deniedModule;
        this.user = user;
        this.onBack = onBack;

        setLayout(new GridBagLayout());
        setBackground(UIStyle.BACKGROUND);

        initializeUI();
    }

    private void initializeUI() {
        JPanel card = new JPanel();
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        card.setBackground(UIStyle.CARD_BG);
        card.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(UIStyle.DANGER, 2),
                BorderFactory.createEmptyBorder(40, 60, 40, 60)));

        // Error icon (using text for simplicity)
        JPanel iconPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(UIStyle.DANGER);
                g2.fillOval(0, 0, 60, 60);
                g2.setColor(Color.WHITE);
                g2.setFont(new Font(UIStyle.FONT_FAMILY, Font.BOLD, 36));
                g2.drawString("X", 20, 43);
                g2.dispose();
            }
        };
        iconPanel.setOpaque(false);
        iconPanel.setPreferredSize(new Dimension(60, 60));
        iconPanel.setMaximumSize(new Dimension(60, 60));
        iconPanel.setAlignmentX(Component.CENTER_ALIGNMENT);

        // Title
        JLabel titleLabel = new JLabel("Access Denied");
        titleLabel.setFont(UIStyle.FONT_TITLE);
        titleLabel.setForeground(UIStyle.DANGER);
        titleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        // Message
        String moduleName = deniedModule != null ? deniedModule.getDisplayName() : "Unknown Module";
        JLabel messageLabel = new JLabel("<html><center>You do not have permission to access:<br><b>" +
                moduleName + "</b></center></html>");
        messageLabel.setFont(UIStyle.FONT_BODY);
        messageLabel.setForeground(UIStyle.TEXT_SECONDARY);
        messageLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        // Role info
        String roleName = user != null ? PermissionService.getRoleDisplayName(user.getRole()) : "Unknown";
        JLabel roleLabel = new JLabel("Your role: " + roleName);
        roleLabel.setFont(UIStyle.FONT_SMALL);
        roleLabel.setForeground(UIStyle.TEXT_MUTED);
        roleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        // Help text
        JLabel helpLabel = new JLabel("Please contact your administrator if you need access.");
        helpLabel.setFont(UIStyle.FONT_SMALL);
        helpLabel.setForeground(UIStyle.TEXT_MUTED);
        helpLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        // Back button
        JButton backButton = UIStyle.createPrimaryButton("Return to Dashboard");
        backButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        backButton.addActionListener(e -> {
            if (onBack != null) {
                onBack.run();
            }
        });

        // Assemble
        card.add(iconPanel);
        card.add(Box.createRigidArea(new Dimension(0, 20)));
        card.add(titleLabel);
        card.add(Box.createRigidArea(new Dimension(0, 16)));
        card.add(messageLabel);
        card.add(Box.createRigidArea(new Dimension(0, 12)));
        card.add(roleLabel);
        card.add(Box.createRigidArea(new Dimension(0, 8)));
        card.add(helpLabel);
        card.add(Box.createRigidArea(new Dimension(0, 24)));
        card.add(backButton);

        add(card);
    }
}
