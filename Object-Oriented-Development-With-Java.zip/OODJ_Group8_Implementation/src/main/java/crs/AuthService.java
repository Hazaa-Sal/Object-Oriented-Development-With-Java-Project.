/*
 * Enhanced Authentication Service
 * Uses binary file for login timestamps and custom exceptions
 */
package crs;

import com.crs.util.BinaryLoginHandler;
import com.crs.exception.AuthenticationException;

/**
 * Authentication Service with:
 * - Binary file login/logout timestamps
 * - Custom exceptions
 * - Role-based access control
 */
public class AuthService {
    private final UserService userService;

    public AuthService(UserService userService) {
        this.userService = userService;
    }

    /**
     * Authenticate user with email and password
     * Records login to binary file
     * 
     * @throws AuthenticationException with specific error message
     */
    public User authenticate(String email, String password) throws AuthenticationException {
        if (email == null || email.trim().isEmpty()) {
            throw new AuthenticationException("Email is required");
        }
        if (password == null || password.isEmpty()) {
            throw new AuthenticationException("Password is required");
        }

        User user = userService.getUserByEmail(email);

        if (user == null) {
            throw new AuthenticationException("User not found with email: " + email);
        }

        if (!user.isActive()) {
            throw new AuthenticationException("Account is deactivated. Please contact administrator.");
        }

        if (!user.checkPassword(password)) {
            throw new AuthenticationException("Invalid password");
        }

        // Successful authentication
        user.login();

        // Record login to BINARY file (per assignment requirement)
        BinaryLoginHandler.recordLogin(user.getUserID(), user.getEmail());

        System.out.println("[AUTH] User authenticated: " + user.getName() + " (" + user.getRole() + ")");

        return user;
    }

    /**
     * Logout user
     * Records logout to binary file
     */
    public void logout(User user) {
        if (user != null) {
            user.logout();

            // Record logout to BINARY file (per assignment requirement)
            BinaryLoginHandler.recordLogout(user.getEmail());

            System.out.println("[AUTH] User logged out: " + user.getName());
        }
    }

    /**
     * Register a new user
     * 
     * @throws AuthenticationException if registration fails
     */
    public boolean register(String userId, String name, String email, String password, String roleStr)
            throws AuthenticationException {
        try {
            // Validate inputs
            if (userId == null || userId.trim().isEmpty()) {
                throw new AuthenticationException("User ID is required");
            }
            if (name == null || name.trim().isEmpty()) {
                throw new AuthenticationException("Name is required");
            }
            if (email == null || email.trim().isEmpty()) {
                throw new AuthenticationException("Email is required");
            }
            if (password == null || password.length() < 4) {
                throw new AuthenticationException("Password must be at least 4 characters");
            }

            // Check if email already exists
            if (userService.getUserByEmail(email) != null) {
                throw new AuthenticationException("Email already registered: " + email);
            }

            User.Role role = User.Role.valueOf(roleStr);
            User newUser = new User(userId, name, email, "", role, true);
            newUser.resetPassword(password);
            userService.addUser(newUser, password);

            System.out.println("[AUTH] New user registered: " + name + " (" + role + ")");
            return true;

        } catch (IllegalArgumentException e) {
            throw new AuthenticationException("Invalid role: " + roleStr);
        } catch (java.io.IOException e) {
            throw new AuthenticationException("Failed to save user: " + e.getMessage());
        }
    }

    /**
     * Reset user password
     * 
     * @throws AuthenticationException if user not found
     */
    public void resetPassword(String email, String newPassword) throws AuthenticationException {
        User user = userService.getUserByEmail(email);

        if (user == null) {
            throw new AuthenticationException("User not found with email: " + email);
        }

        if (newPassword == null || newPassword.length() < 4) {
            throw new AuthenticationException("New password must be at least 4 characters");
        }

        try {
            userService.resetPassword(email, newPassword);
            System.out.println("[AUTH] Password reset for: " + user.getName());
        } catch (java.io.IOException e) {
            throw new AuthenticationException("Failed to save password: " + e.getMessage());
        }
    }

    /**
     * Check if user has required role
     */
    public boolean hasRole(User user, User.Role requiredRole) {
        return user != null && user.getRole() == requiredRole;
    }

    /**
     * Verify user is admin
     */
    public boolean isAdmin(User user) {
        return hasRole(user, User.Role.COURSE_ADMIN);
    }

    /**
     * Get login history (from binary file)
     */
    public java.util.List<BinaryLoginHandler.LoginRecord> getLoginHistory(String email) {
        return BinaryLoginHandler.getUserLoginHistory(email);
    }
}
