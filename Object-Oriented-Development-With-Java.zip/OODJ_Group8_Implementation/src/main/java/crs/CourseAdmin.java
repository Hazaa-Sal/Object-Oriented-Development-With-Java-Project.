/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author aklan
 */
package crs;

public class CourseAdmin extends User {

    public CourseAdmin(String userID, String name, String email, String passwordHash, boolean active) {
        super(userID, name, email, passwordHash, Role.COURSE_ADMIN, active);
    }

    
    public void showMenu() {
        System.out.println("=== Course Admin Menu ===");
        System.out.println("1. Add User");
        System.out.println("2. Update User");
        System.out.println("3. Deactivate User");
        System.out.println("4. Logout");
    }
}
