/*
 * CurrentSession - Session Management for CRS
 * Tracks the currently logged-in user
 */
package crs;

/**
 * Singleton session manager that holds the current logged-in user.
 * All permission checks and role-based logic should reference this.
 */
public class CurrentSession {

    private static User currentUser = null;

    /**
     * Set the currently logged-in user
     */
    public static synchronized void setUser(User user) {
        currentUser = user;

        // Runtime verification - print allowed modules to console
        if (user != null) {
            System.out.println("\n=== SESSION STARTED ===");
            System.out.println("User: " + user.getName());
            System.out.println("Role: " + user.getRole());
            System.out.println("Allowed Modules:");
            for (PermissionService.Module module : PermissionService.getAllowedModules(user)) {
                System.out.println("  [+] " + module.getDisplayName());
            }
            System.out.println("========================\n");
        }
    }

    /**
     * Get the currently logged-in user
     */
    public static synchronized User getUser() {
        return currentUser;
    }

    /**
     * Check if a user is currently logged in
     */
    public static synchronized boolean isLoggedIn() {
        return currentUser != null;
    }

    /**
     * Clear the current session (logout)
     */
    public static synchronized void clear() {
        if (currentUser != null) {
            System.out.println("[SESSION] User logged out: " + currentUser.getName());
        }
        currentUser = null;
    }

    /**
     * Get current user's role, or null if not logged in
     */
    public static synchronized User.Role getCurrentRole() {
        return currentUser != null ? currentUser.getRole() : null;
    }

    // Private constructor - utility class
    private CurrentSession() {
    }
}
