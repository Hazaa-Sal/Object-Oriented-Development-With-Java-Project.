/*
 * EligibilityCheckerPanel - Modernized with UIStyle
 * Student Eligibility Checker Panel
 */
package crs;

import com.crs.model.Student;
import com.crs.model.Component;
import com.crs.service.StudentService;
import javax.swing.*;
import javax.swing.table.*;
import java.awt.*;
import java.util.List;

public class EligibilityCheckerPanel extends JPanel {
    private StudentService studentService;
    private EmailService emailService;
    private Runnable onBack;

    private JTable studentTable;
    private DefaultTableModel tableModel;
    private JLabel totalLabel;
    private JLabel eligibleLabel;
    private JLabel atRiskLabel;
    private JLabel failedLabel;

    public EligibilityCheckerPanel(StudentService studentService,
            EmailService emailService,
            Runnable onBack) {
        this.studentService = studentService;
        this.emailService = emailService;
        this.onBack = onBack;

        setLayout(new BorderLayout());
        setBackground(UIStyle.BACKGROUND);

        initializeComponents();
        loadAllStudents();
    }

    private void initializeComponents() {
        // Header
        add(createHeaderPanel(), BorderLayout.NORTH);

        // Main content
        add(createContentPanel(), BorderLayout.CENTER);

        // Action buttons
        add(createActionPanel(), BorderLayout.SOUTH);
    }

    private JPanel createHeaderPanel() {
        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBackground(UIStyle.CARD_BG);
        headerPanel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(0, 0, 2, 0, UIStyle.BORDER_LIGHT),
                BorderFactory.createEmptyBorder(20, 30, 20, 30)));

        // Left: Title and stats
        JPanel leftPanel = new JPanel();
        leftPanel.setLayout(new BoxLayout(leftPanel, BoxLayout.Y_AXIS));
        leftPanel.setBackground(UIStyle.CARD_BG);

        JLabel titleLabel = UIStyle.createTitleLabel("Eligibility Checker");
        titleLabel.setAlignmentX(java.awt.Component.LEFT_ALIGNMENT);

        JPanel statsPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 20, 5));
        statsPanel.setBackground(UIStyle.CARD_BG);

        totalLabel = UIStyle.createLabel("Total: 0");
        totalLabel.setForeground(UIStyle.TEXT_SECONDARY);

        eligibleLabel = new JLabel("Eligible: 0");
        eligibleLabel.setFont(UIStyle.FONT_BODY_BOLD);
        eligibleLabel.setForeground(UIStyle.SUCCESS);

        atRiskLabel = new JLabel("At Risk: 0");
        atRiskLabel.setFont(UIStyle.FONT_BODY_BOLD);
        atRiskLabel.setForeground(UIStyle.WARNING);

        failedLabel = new JLabel("Failed: 0");
        failedLabel.setFont(UIStyle.FONT_BODY_BOLD);
        failedLabel.setForeground(UIStyle.DANGER);

        statsPanel.add(totalLabel);
        statsPanel.add(new JLabel("|"));
        statsPanel.add(eligibleLabel);
        statsPanel.add(new JLabel("|"));
        statsPanel.add(atRiskLabel);
        statsPanel.add(new JLabel("|"));
        statsPanel.add(failedLabel);

        leftPanel.add(titleLabel);
        leftPanel.add(statsPanel);

        // Right: Back button
        JButton backBtn = UIStyle.createSecondaryButton("Back");
        backBtn.setPreferredSize(new Dimension(100, 40));
        backBtn.addActionListener(e -> onBack.run());

        headerPanel.add(leftPanel, BorderLayout.WEST);
        headerPanel.add(backBtn, BorderLayout.EAST);

        return headerPanel;
    }

    private JPanel createContentPanel() {
        JPanel contentPanel = new JPanel(new BorderLayout());
        contentPanel.setBackground(UIStyle.BACKGROUND);
        contentPanel.setBorder(BorderFactory.createEmptyBorder(20, 30, 20, 30));

        // Info panel
        JPanel infoPanel = createInfoPanel();
        contentPanel.add(infoPanel, BorderLayout.NORTH);

        // Table panel
        JPanel tablePanel = createTablePanel();
        contentPanel.add(tablePanel, BorderLayout.CENTER);

        return contentPanel;
    }

    private JPanel createInfoPanel() {
        JPanel panel = UIStyle.createCard();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBorder(BorderFactory.createCompoundBorder(
                panel.getBorder(),
                BorderFactory.createEmptyBorder(10, 10, 10, 10)));

        JLabel title = UIStyle.createSubtitleLabel("Assignment Eligibility Rules");
        title.setAlignmentX(java.awt.Component.LEFT_ALIGNMENT);

        JLabel rule1 = new JLabel("- Minimum CGPA Required: 2.0");
        rule1.setFont(UIStyle.FONT_BODY_BOLD);
        rule1.setForeground(UIStyle.TEXT_PRIMARY);
        rule1.setAlignmentX(java.awt.Component.LEFT_ALIGNMENT);

        JLabel rule2 = new JLabel("- Maximum Failed Courses Allowed: 3");
        rule2.setFont(UIStyle.FONT_BODY_BOLD);
        rule2.setForeground(UIStyle.TEXT_PRIMARY);
        rule2.setAlignmentX(java.awt.Component.LEFT_ALIGNMENT);

        JLabel colorTitle = new JLabel("Color Coding:");
        colorTitle.setFont(UIStyle.FONT_BODY_BOLD);
        colorTitle.setForeground(UIStyle.TEXT_PRIMARY);
        colorTitle.setAlignmentX(java.awt.Component.LEFT_ALIGNMENT);

        JLabel greenRule = new JLabel("  Green = Safe | Orange = Near Limit | Red = Failed");
        greenRule.setFont(UIStyle.FONT_SMALL);
        greenRule.setForeground(UIStyle.TEXT_SECONDARY);
        greenRule.setAlignmentX(java.awt.Component.LEFT_ALIGNMENT);

        panel.add(title);
        panel.add(Box.createRigidArea(new Dimension(0, 8)));
        panel.add(rule1);
        panel.add(Box.createRigidArea(new Dimension(0, 3)));
        panel.add(rule2);
        panel.add(Box.createRigidArea(new Dimension(0, 8)));
        panel.add(colorTitle);
        panel.add(greenRule);

        return panel;
    }

    private JPanel createTablePanel() {
        JPanel panel = UIStyle.createCard();
        panel.setLayout(new BorderLayout());

        String[] columns = { "Student ID", "Name", "Course", "Year", "CGPA", "Failed", "Status", "Issues" };
        tableModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        studentTable = new JTable(tableModel);

        // Apply UIStyle table styling
        UIStyle.styleTable(studentTable);

        // Column widths
        studentTable.getColumnModel().getColumn(0).setPreferredWidth(80);
        studentTable.getColumnModel().getColumn(1).setPreferredWidth(150);
        studentTable.getColumnModel().getColumn(2).setPreferredWidth(150);
        studentTable.getColumnModel().getColumn(3).setPreferredWidth(60);
        studentTable.getColumnModel().getColumn(4).setPreferredWidth(70);
        studentTable.getColumnModel().getColumn(5).setPreferredWidth(60);
        studentTable.getColumnModel().getColumn(6).setPreferredWidth(90);
        studentTable.getColumnModel().getColumn(7).setPreferredWidth(200);

        // === CGPA Column Renderer (Assignment Rule: Minimum CGPA = 2.0) ===
        studentTable.getColumnModel().getColumn(4).setCellRenderer(new DefaultTableCellRenderer() {
            @Override
            public java.awt.Component getTableCellRendererComponent(JTable table, Object value,
                    boolean isSelected, boolean hasFocus, int row, int column) {
                super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);

                if (value != null) {
                    double cgpa = (value instanceof Double) ? (Double) value : Double.parseDouble(value.toString());
                    setText(String.format("%.2f", cgpa));
                    setFont(UIStyle.FONT_BODY_BOLD);
                    setHorizontalAlignment(SwingConstants.CENTER);

                    if (cgpa < 2.0) {
                        setForeground(UIStyle.DANGER);
                    } else if (cgpa <= 2.20) {
                        setForeground(UIStyle.WARNING);
                    } else {
                        setForeground(UIStyle.SUCCESS);
                    }
                }

                if (!isSelected) {
                    setBackground(row % 2 == 0 ? UIStyle.CARD_BG : UIStyle.TABLE_ROW_ALT);
                }

                return this;
            }
        });

        // === Failed Courses Column Renderer (Assignment Rule: Max = 3) ===
        studentTable.getColumnModel().getColumn(5).setCellRenderer(new DefaultTableCellRenderer() {
            @Override
            public java.awt.Component getTableCellRendererComponent(JTable table, Object value,
                    boolean isSelected, boolean hasFocus, int row, int column) {
                super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);

                if (value != null) {
                    int failedCourses = (value instanceof Integer) ? (Integer) value
                            : Integer.parseInt(value.toString());
                    setText(String.valueOf(failedCourses));
                    setFont(UIStyle.FONT_BODY_BOLD);
                    setHorizontalAlignment(SwingConstants.CENTER);

                    if (failedCourses > 3) {
                        setForeground(UIStyle.DANGER);
                    } else if (failedCourses == 3) {
                        setForeground(UIStyle.WARNING);
                    } else {
                        setForeground(UIStyle.SUCCESS);
                    }
                }

                if (!isSelected) {
                    setBackground(row % 2 == 0 ? UIStyle.CARD_BG : UIStyle.TABLE_ROW_ALT);
                }

                return this;
            }
        });

        // === Status Column Renderer ===
        studentTable.getColumnModel().getColumn(6).setCellRenderer(new DefaultTableCellRenderer() {
            @Override
            public java.awt.Component getTableCellRendererComponent(JTable table, Object value,
                    boolean isSelected, boolean hasFocus, int row, int column) {
                super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);

                if (value != null) {
                    String status = value.toString();
                    setFont(UIStyle.FONT_BODY_BOLD);
                    setHorizontalAlignment(SwingConstants.CENTER);

                    if ("Eligible".equals(status)) {
                        setForeground(UIStyle.SUCCESS);
                        setText("[+] Eligible");
                    } else if ("At Risk".equals(status)) {
                        setForeground(UIStyle.WARNING);
                        setText("[!] At Risk");
                    } else if ("Failed".equals(status)) {
                        setForeground(UIStyle.DANGER);
                        setText("[-] Failed");
                    }
                }

                if (!isSelected) {
                    setBackground(row % 2 == 0 ? UIStyle.CARD_BG : UIStyle.TABLE_ROW_ALT);
                }

                return this;
            }
        });

        JScrollPane scrollPane = new JScrollPane(studentTable);
        scrollPane.setBorder(BorderFactory.createLineBorder(UIStyle.BORDER_LIGHT));

        panel.add(scrollPane, BorderLayout.CENTER);

        return panel;
    }

    private JPanel createActionPanel() {
        JPanel actionPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 20));
        actionPanel.setBackground(UIStyle.BACKGROUND);

        JButton checkBtn = UIStyle.createPrimaryButton("Check Selected");
        checkBtn.setPreferredSize(new Dimension(160, 45));
        checkBtn.addActionListener(e -> checkSelectedStudent());

        JButton notifyBtn = UIStyle.createAccentButton("Notify Student");
        notifyBtn.setPreferredSize(new Dimension(160, 45));
        notifyBtn.addActionListener(e -> notifyStudent());

        JButton refreshBtn = UIStyle.createSecondaryButton("Refresh All");
        refreshBtn.setPreferredSize(new Dimension(140, 45));
        refreshBtn.addActionListener(e -> loadAllStudents());

        actionPanel.add(checkBtn);
        actionPanel.add(notifyBtn);
        actionPanel.add(refreshBtn);

        return actionPanel;
    }

    private void loadAllStudents() {
        tableModel.setRowCount(0);

        int totalCount = 0;
        int eligibleCount = 0;
        int atRiskCount = 0;
        int failedCount = 0;

        for (Student student : studentService.getAll()) {
            totalCount++;

            List<Component> components = student.getComponents();

            double totalGradePoints = 0;
            int studentFailedCourses = 0;

            for (Component comp : components) {
                double gradePoint = scoreToGradePoint(comp.getScore());
                totalGradePoints += gradePoint;

                if (!comp.isPassed()) {
                    studentFailedCourses++;
                }
            }

            double cgpa = components.isEmpty() ? 0 : totalGradePoints / components.size();

            boolean cgpaPass = cgpa >= 2.0;
            boolean failedPass = studentFailedCourses <= 3;
            boolean cgpaNearLimit = cgpa >= 2.0 && cgpa <= 2.20;
            boolean failedNearLimit = studentFailedCourses == 3;

            String status;
            if (!cgpaPass || !failedPass) {
                status = "Failed";
                failedCount++;
            } else if (cgpaNearLimit || failedNearLimit) {
                status = "At Risk";
                atRiskCount++;
            } else {
                status = "Eligible";
                eligibleCount++;
            }

            StringBuilder issues = new StringBuilder();
            if (cgpa < 2.0) {
                issues.append("CGPA below 2.0 (").append(String.format("%.2f", cgpa)).append("); ");
            } else if (cgpaNearLimit) {
                issues.append("CGPA near limit (").append(String.format("%.2f", cgpa)).append("); ");
            }
            if (studentFailedCourses > 3) {
                issues.append("Failed > 3 courses (").append(studentFailedCourses).append("); ");
            } else if (studentFailedCourses == 3) {
                issues.append("Failed at limit (3); ");
            }
            if (issues.length() == 0) {
                issues.append("None");
            }

            Object[] row = {
                    student.getId(),
                    student.getName(),
                    student.getMajor() != null ? student.getMajor() : "N/A",
                    student.getYear() != null ? student.getYear() : "N/A",
                    cgpa,
                    studentFailedCourses,
                    status,
                    issues.toString()
            };

            tableModel.addRow(row);
        }

        totalLabel.setText("Total: " + totalCount);
        eligibleLabel.setText("Eligible: " + eligibleCount);
        atRiskLabel.setText("At Risk: " + atRiskCount);
        failedLabel.setText("Failed: " + failedCount);
    }

    private void checkSelectedStudent() {
        int selectedRow = studentTable.getSelectedRow();
        if (selectedRow == -1) {
            UIStyle.showWarning(this, "No Selection", "Please select a student to check.");
            return;
        }

        String studentId = tableModel.getValueAt(selectedRow, 0).toString();
        String name = tableModel.getValueAt(selectedRow, 1).toString();
        String cgpa = tableModel.getValueAt(selectedRow, 4).toString();
        String failed = tableModel.getValueAt(selectedRow, 5).toString();
        String status = tableModel.getValueAt(selectedRow, 6).toString();
        String issues = tableModel.getValueAt(selectedRow, 7).toString();

        StringBuilder message = new StringBuilder();
        message.append("Student: ").append(name).append("\n");
        message.append("ID: ").append(studentId).append("\n\n");
        message.append("CGPA: ").append(cgpa).append("\n");
        message.append("Failed Courses: ").append(failed).append("\n\n");
        message.append("Status: ").append(status).append("\n");
        message.append("Issues: ").append(issues);

        if (status.contains("Eligible")) {
            UIStyle.showSuccess(this, "Student is Eligible", message.toString());
        } else {
            UIStyle.showWarning(this, "Student At Risk", message.toString());
        }
    }

    private void notifyStudent() {
        int selectedRow = studentTable.getSelectedRow();
        if (selectedRow == -1) {
            UIStyle.showWarning(this, "No Selection", "Please select a student to notify.");
            return;
        }

        String studentId = tableModel.getValueAt(selectedRow, 0).toString();
        Student student = studentService.getStudent(studentId);

        if (student == null) {
            UIStyle.showError(this, "Error", "Student not found!");
            return;
        }

        String cgpa = tableModel.getValueAt(selectedRow, 4).toString();
        String failed = tableModel.getValueAt(selectedRow, 5).toString();
        String status = tableModel.getValueAt(selectedRow, 6).toString();
        String issues = tableModel.getValueAt(selectedRow, 7).toString();

        String email = JOptionPane.showInputDialog(this,
                "Enter student's email address:",
                "Send Eligibility Notification",
                JOptionPane.PLAIN_MESSAGE);

        if (email == null || email.trim().isEmpty()) {
            return;
        }

        String subject = status.contains("Eligible")
                ? "Eligibility Confirmation - " + student.getName()
                : "Academic Standing Notice - " + student.getName();

        StringBuilder body = new StringBuilder();
        body.append("Dear ").append(student.getName()).append(",\n\n");
        body.append("This is to inform you about your current academic standing:\n\n");
        body.append("Cumulative GPA: ").append(cgpa).append("\n");
        body.append("Failed Courses: ").append(failed).append("\n");
        body.append("Status: ").append(status).append("\n\n");

        if (status.contains("Eligible")) {
            body.append("Congratulations! You meet the eligibility criteria for progression to the next level.\n\n");
            body.append("Keep up the good work!\n\n");
        } else {
            body.append("Issues Identified: ").append(issues).append("\n\n");
            body.append("Please schedule a meeting with your academic advisor to discuss your recovery options.\n\n");
        }

        body.append("Best regards,\n");
        body.append("CRS Team");

        try {
            emailService.sendEmail(email.trim(), subject, body.toString());
            UIStyle.showSuccess(this, "Success", "Eligibility notification sent to: " + email);
        } catch (Exception ex) {
            UIStyle.showError(this, "Error", "Failed to send email: " + ex.getMessage());
        }
    }

    /**
     * Converts a percentage score (0-100) to grade points (0-4.0 scale)
     */
    private double scoreToGradePoint(double percentageScore) {
        if (percentageScore >= 90)
            return 4.0;
        if (percentageScore >= 80)
            return 3.5;
        if (percentageScore >= 70)
            return 3.0;
        if (percentageScore >= 60)
            return 2.5;
        if (percentageScore >= 50)
            return 2.0;
        if (percentageScore >= 40)
            return 1.5;
        return 0.0;
    }
}