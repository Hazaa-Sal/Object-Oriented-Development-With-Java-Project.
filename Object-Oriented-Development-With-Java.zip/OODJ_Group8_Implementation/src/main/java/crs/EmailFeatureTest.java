/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package crs;

public class EmailFeatureTest {

    public static void main(String[] args) {
        // Replace with your credentials
        String systemEmail = "aklanazeer486@gmail.com";
        String appPassword = "caxtioqmlgdnzrtj";

        EmailService emailService = new EmailService(systemEmail, appPassword);

        // Simulate a user (adjust parameters according to your User constructor)
        User testUser = new User(
                "U100",                    // userID
                "Test User",               // name
                "aklan2552@gmail.com", // email
                "hashedpassword",          // passwordHash (can be dummy)
                User.Role.STUDENT,         // role
                true                       // active
        );

        try {
            // 1. Test welcome email
            emailService.sendWelcomeEmail(testUser);

            // 2. Test password reset email
            emailService.sendPasswordResetEmail(testUser);

            // 3. Test account update email
            emailService.sendAccountUpdateEmail(testUser);

            // 4. Test recovery plan
            emailService.sendRecoveryPlanEmail("aklan2552@gmail.com");

            // 5. Test academic report
            emailService.sendAcademicReportEmail("aklan2552@gmail.com");

            System.out.println("All test emails sent successfully!");

        } catch (Exception e) {
            System.err.println("Email test failed!");
            e.printStackTrace();
        }
    }
}
