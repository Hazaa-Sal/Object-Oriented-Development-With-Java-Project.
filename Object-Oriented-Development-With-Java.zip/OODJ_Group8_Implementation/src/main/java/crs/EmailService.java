/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package crs;

import com.crs.model.Student;
import jakarta.mail.*;
import jakarta.mail.internet.*;
import jakarta.activation.*;
import java.io.File;
import java.util.Properties;

public class EmailService {

    private final String fromEmail;
    private final String password;

    public EmailService(String fromEmail, String password) {
        this.fromEmail = fromEmail;
        this.password = password;
    }

    public void sendEmail(String toEmail, String subject, String body) throws MessagingException {

        Properties props = new Properties();
        props.put("mail.smtp.host", "smtp.gmail.com");
        props.put("mail.smtp.port", "587");
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.starttls.enable", "true");

        Session session = Session.getInstance(props, new Authenticator() {
            @Override
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(fromEmail, password);
            }
        });

        Message message = new MimeMessage(session);
        message.setFrom(new InternetAddress(fromEmail));
        message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(toEmail));
        message.setSubject(subject);
        message.setText(body);

        Transport.send(message);
    }

    /**
     * Send an email with a PDF attachment
     * 
     * @param toEmail        recipient email address
     * @param subject        email subject
     * @param body           email body text
     * @param attachmentPath path to the PDF file to attach
     * @throws MessagingException if email sending fails
     */
    public void sendEmailWithAttachment(String toEmail, String subject, String body, String attachmentPath)
            throws MessagingException {

        Properties props = new Properties();
        props.put("mail.smtp.host", "smtp.gmail.com");
        props.put("mail.smtp.port", "587");
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.starttls.enable", "true");

        Session session = Session.getInstance(props, new Authenticator() {
            @Override
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(fromEmail, password);
            }
        });

        Message message = new MimeMessage(session);
        message.setFrom(new InternetAddress(fromEmail));
        message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(toEmail));
        message.setSubject(subject);

        // Create multipart message
        MimeMultipart multipart = new MimeMultipart();

        // Part 1: Email body
        MimeBodyPart textPart = new MimeBodyPart();
        textPart.setText(body);
        multipart.addBodyPart(textPart);

        // Part 2: PDF attachment
        MimeBodyPart attachmentPart = new MimeBodyPart();
        File pdfFile = new File(attachmentPath);
        DataSource source = new FileDataSource(pdfFile);
        attachmentPart.setDataHandler(new DataHandler(source));
        attachmentPart.setFileName(pdfFile.getName());
        multipart.addBodyPart(attachmentPart);

        // Set the complete message
        message.setContent(multipart);

        Transport.send(message);
    }

    /**
     * Send an academic performance report as PDF attachment
     * Uses iText to generate the PDF report before sending
     * 
     * @param student the student to generate report for
     * @param toEmail recipient email address
     * @throws Exception if PDF generation or email sending fails
     */
    public void sendAcademicReportWithPdf(Student student, String toEmail) throws Exception {
        // Generate PDF report using iText
        String pdfPath = PdfReportGenerator.generateAcademicReport(student);

        try {
            // Send email with PDF attachment
            String subject = "📊 Academic Performance Report - " + student.getName();
            String body = "Dear " + student.getName() + ",\n\n" +
                    "Your Academic Performance Report is attached.\n\n" +
                    "Please review your grades and contact your academic advisor if you have any questions.\n\n" +
                    "Best regards,\n" +
                    "The CRS Team";

            sendEmailWithAttachment(toEmail, subject, body, pdfPath);

        } finally {
            // Clean up: delete temporary PDF file
            File pdfFile = new File(pdfPath);
            if (pdfFile.exists()) {
                pdfFile.delete();
            }
        }
    }

    // Called when a user is created
    public void sendWelcomeEmail(User user) {
        try {
            sendEmail(user.getEmail(),
                    "Welcome to CRS",
                    "Hello " + user.getName()
                            + ",\n\nYour CRS account has been created successfully.\n\nRegards,\nCRS Team");
        } catch (MessagingException e) {
            e.printStackTrace();
        }
    }

    // Called on password reset
    public void sendPasswordResetEmail(User user) {
        try {
            sendEmail(user.getEmail(),
                    "CRS Password Reset",
                    "Hello " + user.getName()
                            + ",\n\nYour password has been reset successfully.\n\nRegards,\nCRS Team");
        } catch (MessagingException e) {
            e.printStackTrace();
        }
    }

    // Called when user info is updated
    public void sendAccountUpdateEmail(User user) {
        try {
            sendEmail(user.getEmail(),
                    "Your CRS Account Has Been Updated",
                    "Hi " + user.getName() + ",\n\n" +
                            "We wanted to let you know that your CRS account details have been successfully updated.\n\n"
                            +
                            "If you did not make this change or have any questions, please contact our support team.\n\n"
                            +
                            "Best regards,\n" +
                            "The CRS Team");

        } catch (MessagingException e) {
            e.printStackTrace();
        }
    }

    // Student recovery plan email
    public void sendRecoveryPlanEmail(String studentEmail) {
        try {
            sendEmail(studentEmail,
                    "Your Recovery Plan Is Ready",
                    "Hello,\n\nYour course recovery plan has been created. Please check the CRS portal.\n\nRegards,\nCRS Team");
        } catch (MessagingException e) {
            e.printStackTrace();
        }
    }

    // Academic report email (plain text version - kept for backwards compatibility)
    public void sendAcademicReportEmail(String studentEmail) {
        try {
            sendEmail(studentEmail,
                    "Your Academic Report",
                    "Hello,\n\nYour academic performance report is ready. Please check the CRS portal.\n\nRegards,\nCRS Team");
        } catch (MessagingException e) {
            e.printStackTrace();
        }
    }

    // Login notification
    public void sendLoginNotification(User user) {
        try {
            sendEmail(user.getEmail(),
                    "CRS Login Notification",
                    "Hello " + user.getName() + ",\n\nYou just logged in at " + java.time.LocalDateTime.now()
                            + ".\n\nRegards,\nCRS Team");
        } catch (MessagingException e) {
            e.printStackTrace();
        }
    }

    /**
     * Send recovery plan email with PDF attachment.
     * Generates a professional PDF recovery plan and attaches it to the email.
     * 
     * @param studentName   Name of the student
     * @param studentEmail  Email address of the student
     * @param componentName Name of the failed component
     */
    public void sendRecoveryPlanEmail(
            String studentName,
            String studentEmail,
            String componentName) {

        String subject = "Recovery Plan for " + componentName;

        // Brief email body mentioning the PDF attachment
        StringBuilder body = new StringBuilder();
        body.append("Dear ").append(studentName).append(",\n\n");
        body.append("Here is your automatic recovery plan for the failed component.\n\n");
        body.append("Component: ").append(componentName).append("\n\n");
        body.append("Please review the attached PDF document for your detailed recovery plan.\n\n");
        body.append("Follow the recovery plan and complete the required steps before the deadline.\n");
        body.append("If you have questions, contact your Academic Officer.\n\n");
        body.append("Regards,\n");
        body.append("Course Recovery System (CRS)");

        try {
            // Generate PDF recovery plan
            String pdfPath = PdfReportGenerator.generateRecoveryPlanPdf(studentName, studentEmail, componentName);
            
            try {
                // Send email with PDF attachment
                sendEmailWithAttachment(studentEmail, subject, body.toString(), pdfPath);
                System.out.println("[EMAIL] Recovery plan PDF sent to " + studentEmail);
                
            } finally {
                // Clean up: delete temporary PDF file
                File pdfFile = new File(pdfPath);
                if (pdfFile.exists()) {
                    pdfFile.delete();
                    System.out.println("[CLEANUP] Temporary PDF deleted: " + pdfPath);
                }
            }
            
        } catch (Exception e) {
            System.err.println("[EMAIL ERROR] Failed to send recovery plan: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
