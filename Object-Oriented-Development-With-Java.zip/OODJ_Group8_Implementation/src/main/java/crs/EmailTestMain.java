/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package crs;

public class EmailTestMain {
    public static void main(String[] args) {
        try {
            EmailService emailService = new EmailService(
                "aklanazeer486@gmail.com",       // sender email
                "caxtioqmlgdnzrtj"           // Gmail App Password
            );

            emailService.sendEmail(
                "Youssefahghazy2006@gmail.com",  // who receives
                "Test Email",
                "Hey loser. This email confirms akla is awesome because she combined everything in JAVA MAVEN and it works. She is also currently working on GUI and dashboard. Make dua."
            );

            System.out.println("Email sent successfully!");

        } catch (Exception e) {
            System.out.println("Email failed!");
            e.printStackTrace();
        }
    }
}

