/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package crs;

import java.io.*;
import java.nio.file.*;
import java.util.*;

public class FileHandler {
    private final Path usersPath;
    
    public FileHandler(String usersFilePath) {
        this.usersPath = Paths.get(usersFilePath);
    }
    
    public Map<String, User> loadUsers() throws IOException {
        Map<String, User> map = new HashMap<>();
        
        if (!Files.exists(usersPath)) {
            Files.createFile(usersPath);
            return map;
        }
        
        try (BufferedReader br = Files.newBufferedReader(usersPath)) {
            String line;
            while ((line = br.readLine()) != null) {
                if (line.trim().isEmpty()) continue;
                
                String[] parts = line.split("\t");
                if (parts.length < 6) continue;
                
                String id = parts[0];
                String name = parts[1];
                String email = parts[2];
                User.Role role = User.Role.valueOf(parts[3]);
                boolean active = parts[4].equals("1");
                String hash = parts[5]; // THIS WAS THE BUG - we need to save the hash!
                
                User u;
                switch (role) {
                    case COURSE_ADMIN:
                        u = new CourseAdmin(id, name, email, hash, active);
                        break;
                    case ACADEMIC_OFFICER:
                        u = new AcademicOfficer(id, name, email, hash, active);
                        break;
                    default:
                        u = new User(id, name, email, hash, role, active);
                }
                
                map.put(email.toLowerCase(), u);
            }
        }
        
        return map;
    }
    
    public void saveUsers(Collection<User> users) throws IOException {
        try (BufferedWriter bw = Files.newBufferedWriter(usersPath, 
                StandardOpenOption.CREATE, 
                StandardOpenOption.TRUNCATE_EXISTING)) {
            
            for (User u : users) {
                // FIX: Save the actual password hash, not empty string!
                String line = String.join("\t",
                    u.getUserID(),
                    u.getName(),
                    u.getEmail(),
                    u.getRole().name(),
                    u.isActive() ? "1" : "0",
                    u.getPasswordHash()  // Save the actual hash!
                );
                bw.write(line);
                bw.newLine();
            }
        }
    }
}
