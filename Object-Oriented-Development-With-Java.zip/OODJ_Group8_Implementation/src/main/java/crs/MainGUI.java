/*
 * MainGUI - Course Recovery System Main Window
 * Complete Role-Based Access Control Implementation
 * Version 5.0 - Full RBAC with NavigationService
 * 
 * ROLE PERMISSIONS:
 * - COURSE_ADMIN: User Management, Academic Reports, Eligibility, Settings (NO Course Recovery!)
 * - ACADEMIC_OFFICER: Full access including Course Recovery
 *
 */
package crs;

import com.crs.gui.CourseRecoveryPanel;
import com.crs.service.*;
import crs.PermissionService.Module;
import javax.swing.*;
import java.awt.*;

/**
 * Main GUI for Course Recovery System
 * Enforces role-based access control on ALL navigation
 */
public class MainGUI extends JFrame {

    // Legacy Color Constants (for backward compatibility)
    public static final Color PRIMARY_COLOR = UIStyle.PRIMARY;
    public static final Color SECONDARY_COLOR = UIStyle.ACCENT;
    public static final Color ACCENT_COLOR = UIStyle.ACCENT_CYAN;
    public static final Color SUCCESS_COLOR = UIStyle.SUCCESS;
    public static final Color WARNING_COLOR = UIStyle.WARNING;
    public static final Color DANGER_COLOR = UIStyle.DANGER;
    public static final Color BACKGROUND_COLOR = UIStyle.BACKGROUND;
    public static final Color CARD_COLOR = UIStyle.CARD_BG;
    public static final Color TEXT_DARK = UIStyle.TEXT_PRIMARY;
    public static final Color TEXT_LIGHT = UIStyle.TEXT_SECONDARY;

    // Services
    private UserService userService;
    private StudentService studentService;
    private RecommendationService recommendationService;
    private RecoveryService recoveryService;
    private ReportService reportService;
    private EmailService emailService;

    // Current panel
    private JPanel currentPanel;

    // File paths
    private static final String USERS_FILE = "users.txt";
    private static final String STUDENTS_FILE = "student_information (1).txt";
    private static final String GRADES_FILE = "course_assessment_with_grades.txt";

    public MainGUI() {
        UIStyle.applyGlobalTheme();

        // Print permission summary to console for verification
        PermissionService.printPermissionSummary();

        initializeFrame();
        initializeServices();
        loadDataFiles();

        // Set up NavigationService
        NavigationService.setMainFrame(this);

        showLogin();
    }

    private void initializeFrame() {
        setTitle("Course Recovery System");
        setSize(1200, 800);
        setMinimumSize(new Dimension(1100, 700));
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        getContentPane().setBackground(UIStyle.BACKGROUND);
    }

    private void initializeServices() {
        try {
            FileHandler fileHandler = new FileHandler(USERS_FILE);
            userService = new UserService(fileHandler);
            studentService = new StudentService();
            recommendationService = new RecommendationService();
            recoveryService = new RecoveryService();
            reportService = new ReportService();
            emailService = new EmailService("aklanazeer486@gmail.com", "caxtioqmlgdnzrtj");

            System.out.println("[OK] All services initialized successfully");
        } catch (Exception e) {
            showError("Service Initialization Error", "Failed to initialize services: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private void loadDataFiles() {
        try {
            FileService fileService = new FileService(studentService);
            fileService.loadStudentsTxt(STUDENTS_FILE);
            fileService.loadGradesTxt(GRADES_FILE);

            int studentCount = studentService.getAll().size();
            System.out.println("[OK] Loaded " + studentCount + " students");
        } catch (Exception e) {
            showWarning("Data Load Warning",
                    "Could not load all data files. Some features may be limited.\n\n" + e.getMessage());
            e.printStackTrace();
        }
    }

    // ==================== NAVIGATION ====================

    private void showLogin() {
        CurrentSession.clear();
        switchPanel(new ModernLoginPanel(userService, this::onLoginSuccess));
    }

    private void onLoginSuccess(User user) {
        // Set current session
        CurrentSession.setUser(user);

        // Send login notification
        if (emailService != null) {
            try {
                emailService.sendLoginNotification(user);
            } catch (Exception e) {
                System.err.println("Failed to send login notification: " + e.getMessage());
            }
        }

        // Show welcome message with role info
        String roleInfo = PermissionService.getRoleDisplayName(user.getRole());
        showSuccess("Welcome!", "Welcome back, " + user.getName() + "!\n\nRole: " + roleInfo);

        // BUILD DASHBOARD FOR THIS ROLE
        showDashboard();
    }

    /**
     * Show the role-specific dashboard
     */
    private void showDashboard() {
        User user = CurrentSession.getUser();
        if (user == null) {
            showLogin();
            return;
        }

        switchPanel(new SidebarDashboardPanel(
                user,
                userService,
                emailService,
                studentService,
                this::navigateToCourseRecovery,
                this::navigateToReports,
                this::navigateToEligibility,
                this::navigateToUserManagement,
                this::handleLogout));
    }

    /**
     * Navigate to a specific module (called by NavigationService)
     */
    public void navigateToModule(Module module) {
        User user = CurrentSession.getUser();
        if (user == null) {
            showLogin();
            return;
        }

        // Check permission
        if (!PermissionService.hasAccess(user, module)) {
            showAccessDeniedPanel(module);
            return;
        }

        switch (module) {
            case DASHBOARD:
                showDashboard();
                break;
            case USER_MANAGEMENT:
                navigateToUserManagement();
                break;
            case COURSE_RECOVERY:
            case MY_RECOVERY_STATUS:
                navigateToCourseRecovery();
                break;
            case ACADEMIC_REPORTS:
            case MY_ACADEMIC_REPORT:
                navigateToReports();
                break;
            case ELIGIBILITY_CHECKER:
            case MY_ELIGIBILITY:
                navigateToEligibility();
                break;
            case SETTINGS:
                showSettings();
                break;
            default:
                showDashboard();
                break;
        }
    }

    /**
     * Navigate to User Management Panel
     * Allowed: COURSE_ADMIN, ACADEMIC_OFFICER
     */
    private void navigateToUserManagement() {
        if (!checkAndEnforcePermission(Module.USER_MANAGEMENT)) {
            return;
        }

        switchPanel(new UserManagementPanel(
                userService,
                emailService,
                this::showDashboard));
    }

    /**
     * Navigate to Course Recovery Panel
     * Allowed: ACADEMIC_OFFICER only (NOT COURSE_ADMIN!)
     */
    private void navigateToCourseRecovery() {
        User user = CurrentSession.getUser();

        // Determine which module to check based on role
        Module requiredModule = (user != null && user.getRole() == User.Role.STUDENT)
                ? Module.MY_RECOVERY_STATUS
                : Module.COURSE_RECOVERY;

        // CRITICAL: Course Admin cannot access Course Recovery
        if (user != null && user.getRole() == User.Role.COURSE_ADMIN) {
            System.out.println("[BLOCKED] Course Admin attempted to access Course Recovery");
            showAccessDeniedPanel(Module.COURSE_RECOVERY);
            return;
        }

        if (!checkAndEnforcePermission(requiredModule)) {
            return;
        }

        switchPanel(new CourseRecoveryPanel(
                studentService,
                recommendationService,
                recoveryService,
                reportService,
                emailService,
                this::showDashboard));
    }

    /**
     * Navigate to Academic Reports Panel
     * Allowed: COURSE_ADMIN, ACADEMIC_OFFICER, STUDENT (own report)
     */
    private void navigateToReports() {
        User user = CurrentSession.getUser();

        Module requiredModule = (user != null && user.getRole() == User.Role.STUDENT)
                ? Module.MY_ACADEMIC_REPORT
                : Module.ACADEMIC_REPORTS;

        if (!checkAndEnforcePermission(requiredModule)) {
            return;
        }

        switchPanel(new AcademicReportPanel(
                studentService,
                reportService,
                emailService,
                this::showDashboard));
    }

    /**
     * Navigate to Eligibility Panel
     * Allowed: COURSE_ADMIN, ACADEMIC_OFFICER, STUDENT (own eligibility)
     */
    private void navigateToEligibility() {
        User user = CurrentSession.getUser();

        Module requiredModule = (user != null && user.getRole() == User.Role.STUDENT)
                ? Module.MY_ELIGIBILITY
                : Module.ELIGIBILITY_CHECKER;

        if (!checkAndEnforcePermission(requiredModule)) {
            return;
        }

        switchPanel(new EligibilityCheckerPanel(
                studentService,
                emailService,
                this::showDashboard));
    }

    /**
     * Show Settings Panel
     */
    private void showSettings() {
        if (!checkAndEnforcePermission(Module.SETTINGS)) {
            return;
        }

        UIStyle.showInfo(this, "Settings",
                "System Settings\n\nSettings panel coming soon.");
    }

    /**
     * Check permission and show Access Denied panel if not allowed
     * 
     * @return true if permission granted, false if denied
     */
    private boolean checkAndEnforcePermission(Module module) {
        User user = CurrentSession.getUser();

        if (user == null) {
            showLogin();
            return false;
        }

        if (!PermissionService.hasAccess(user, module)) {
            System.out.println("[DENIED] " + user.getName() + " (" + user.getRole() +
                    ") tried to access: " + module.getDisplayName());
            showAccessDeniedPanel(module);
            return false;
        }

        return true;
    }

    /**
     * Show the Access Denied panel
     */
    private void showAccessDeniedPanel(Module module) {
        User user = CurrentSession.getUser();
        switchPanel(new AccessDeniedPanel(module, user, this::showDashboard));
    }

    /**
     * Handle logout
     */
    public void handleLogout() {
        User user = CurrentSession.getUser();
        if (user != null) {
            AuthService authService = new AuthService(userService);
            authService.logout(user);

            showInfo("Goodbye", "You have been logged out successfully.");
            CurrentSession.clear();
            showLogin();
        }
    }

    // ==================== UTILITY METHODS ====================

    private void switchPanel(JPanel newPanel) {
        if (currentPanel != null) {
            remove(currentPanel);
        }
        currentPanel = newPanel;
        add(currentPanel);
        revalidate();
        repaint();
    }

    // Dialog helpers
    public static void showSuccess(String title, String message) {
        UIStyle.showSuccess(null, title, message);
    }

    public static void showError(String title, String message) {
        UIStyle.showError(null, title, message);
    }

    public static void showWarning(String title, String message) {
        UIStyle.showWarning(null, title, message);
    }

    public static void showInfo(String title, String message) {
        UIStyle.showInfo(null, title, message);
    }

    // Legacy methods for backward compatibility
    public static JButton createStyledButton(String text, Color bgColor) {
        JButton button = UIStyle.createPrimaryButton(text);
        button.setBackground(bgColor);
        return button;
    }

    public static JLabel createStyledLabel(String text, int fontSize, Color color) {
        JLabel label = new JLabel(text);
        label.setFont(new Font(UIStyle.FONT_FAMILY, Font.BOLD, fontSize));
        label.setForeground(color);
        return label;
    }

    public static JTextField createStyledTextField() {
        return UIStyle.createTextField();
    }

    public static JPasswordField createStyledPasswordField() {
        return UIStyle.createPasswordField();
    }

    public static JPanel createCard() {
        JPanel card = new JPanel();
        card.setBackground(UIStyle.CARD_BG);
        card.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(UIStyle.BORDER, 1),
                BorderFactory.createEmptyBorder(20, 20, 20, 20)));
        return card;
    }

    // ==================== MAIN METHOD ====================

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            MainGUI gui = new MainGUI();
            gui.setVisible(true);
        });
    }
}