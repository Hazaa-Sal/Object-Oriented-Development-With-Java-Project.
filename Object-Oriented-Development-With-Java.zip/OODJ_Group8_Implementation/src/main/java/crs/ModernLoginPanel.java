/*
 * ModernLoginPanel - Premium Login Screen
 * Matches the Sidebar Dashboard design aesthetic
 * Version 3.0
 */
package crs;

import javax.swing.*;
import java.awt.*;
import java.util.function.Consumer;

public class ModernLoginPanel extends JPanel {
    private final UserService userService;
    private final Consumer<User> onLoginSuccess;

    private JTextField emailField;
    private JPasswordField passwordField;
    private JLabel errorLabel;

    public ModernLoginPanel(UserService userService, Consumer<User> onLoginSuccess) {
        this.userService = userService;
        this.onLoginSuccess = onLoginSuccess;

        setLayout(new GridBagLayout());
        setBackground(UIStyle.BACKGROUND);

        initializeComponents();
    }

    private void initializeComponents() {
        GridBagConstraints gbc = new GridBagConstraints();

        JPanel cardPanel = createLoginCard();

        gbc.gridx = 0;
        gbc.gridy = 0;
        add(cardPanel, gbc);

        passwordField.addActionListener(e -> handleLogin());
    }

    private JPanel createLoginCard() {
        JPanel card = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

                // Shadow
                for (int i = 6; i >= 0; i--) {
                    int alpha = 15 - i * 2;
                    if (alpha < 0)
                        alpha = 0;
                    g2.setColor(new Color(0, 0, 0, alpha));
                    g2.fillRoundRect(i, i + 4, getWidth() - i * 2, getHeight() - i * 2 - 4,
                            UIStyle.CARD_RADIUS, UIStyle.CARD_RADIUS);
                }

                // Card
                g2.setColor(UIStyle.CARD_BG);
                g2.fillRoundRect(0, 0, getWidth() - 6, getHeight() - 8,
                        UIStyle.CARD_RADIUS, UIStyle.CARD_RADIUS);

                // Border
                g2.setColor(UIStyle.BORDER);
                g2.drawRoundRect(0, 0, getWidth() - 7, getHeight() - 9,
                        UIStyle.CARD_RADIUS, UIStyle.CARD_RADIUS);

                g2.dispose();
            }
        };
        card.setOpaque(false);
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        card.setBorder(BorderFactory.createEmptyBorder(
                UIStyle.PADDING_XL, UIStyle.PADDING_XL, UIStyle.PADDING_XL, UIStyle.PADDING_XL));
        card.setPreferredSize(new Dimension(400, 460));

        // Brand
        card.add(createBrandPanel());
        card.add(Box.createRigidArea(new Dimension(0, UIStyle.PADDING_XL)));

        // Email
        emailField = UIStyle.createTextField();
        emailField.setMaximumSize(new Dimension(320, 44));
        emailField.setPreferredSize(new Dimension(320, 44));
        card.add(createFormField("Email Address", emailField));
        card.add(Box.createRigidArea(new Dimension(0, UIStyle.PADDING_MD)));

        // Password
        passwordField = UIStyle.createPasswordField();
        passwordField.setMaximumSize(new Dimension(320, 44));
        passwordField.setPreferredSize(new Dimension(320, 44));
        card.add(createFormField("Password", passwordField));
        card.add(Box.createRigidArea(new Dimension(0, UIStyle.PADDING_SM)));

        // Error
        errorLabel = new JLabel(" ");
        errorLabel.setFont(UIStyle.FONT_SMALL);
        errorLabel.setForeground(UIStyle.DANGER);
        errorLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        card.add(errorLabel);
        card.add(Box.createRigidArea(new Dimension(0, UIStyle.PADDING_MD)));

        // Buttons
        JButton loginButton = createPrimaryButton("Sign In");
        loginButton.addActionListener(e -> handleLogin());
        card.add(loginButton);
        card.add(Box.createRigidArea(new Dimension(0, UIStyle.PADDING_SM)));

        JButton registerButton = createOutlineButton("Create New Account");
        registerButton.addActionListener(e -> handleRegister());
        card.add(registerButton);

        return card;
    }

    private JPanel createBrandPanel() {
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setOpaque(false);
        panel.setAlignmentX(Component.CENTER_ALIGNMENT);

        // Logo
        JPanel logoIcon = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

                GradientPaint gradient = new GradientPaint(
                        0, 0, UIStyle.SIDEBAR_BG,
                        getWidth(), getHeight(), UIStyle.PRIMARY_DARK);
                g2.setPaint(gradient);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 10, 10);
                g2.dispose();
            }
        };
        logoIcon.setOpaque(false);
        logoIcon.setPreferredSize(new Dimension(56, 56));
        logoIcon.setMaximumSize(new Dimension(56, 56));
        logoIcon.setLayout(new GridBagLayout());
        logoIcon.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel logoText = new JLabel("CRS");
        logoText.setFont(new Font(UIStyle.FONT_FAMILY, Font.BOLD, 18));
        logoText.setForeground(UIStyle.TEXT_WHITE);
        logoIcon.add(logoText);

        JLabel titleLabel = UIStyle.createTitleLabel("Course Recovery System");
        titleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel subtitleLabel = UIStyle.createSecondaryLabel("Sign in to your account");
        subtitleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        panel.add(logoIcon);
        panel.add(Box.createRigidArea(new Dimension(0, UIStyle.PADDING_MD)));
        panel.add(titleLabel);
        panel.add(Box.createRigidArea(new Dimension(0, 4)));
        panel.add(subtitleLabel);

        return panel;
    }

    private JPanel createFormField(String labelText, JComponent field) {
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setOpaque(false);
        panel.setAlignmentX(Component.CENTER_ALIGNMENT);
        panel.setMaximumSize(new Dimension(320, 72));

        JLabel label = new JLabel(labelText);
        label.setFont(UIStyle.FONT_BODY_BOLD);
        label.setForeground(UIStyle.TEXT_PRIMARY);
        label.setAlignmentX(Component.LEFT_ALIGNMENT);

        field.setAlignmentX(Component.LEFT_ALIGNMENT);

        panel.add(label);
        panel.add(Box.createRigidArea(new Dimension(0, 6)));
        panel.add(field);

        return panel;
    }

    private JButton createPrimaryButton(String text) {
        JButton button = new JButton(text) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(getBackground());
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 8, 8);
                g2.dispose();
                super.paintComponent(g);
            }
        };
        button.setFont(UIStyle.FONT_BUTTON);
        button.setForeground(UIStyle.TEXT_WHITE);
        button.setBackground(UIStyle.PRIMARY);
        button.setOpaque(false);
        button.setContentAreaFilled(false);
        button.setBorderPainted(false);
        button.setFocusPainted(false);
        button.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        button.setMaximumSize(new Dimension(320, 44));
        button.setPreferredSize(new Dimension(320, 44));
        button.setAlignmentX(Component.CENTER_ALIGNMENT);

        Color hover = UIStyle.PRIMARY.darker();
        button.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent e) {
                button.setBackground(hover);
            }

            public void mouseExited(java.awt.event.MouseEvent e) {
                button.setBackground(UIStyle.PRIMARY);
            }
        });

        return button;
    }

    private JButton createOutlineButton(String text) {
        JButton button = new JButton(text) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(getBackground());
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 8, 8);
                g2.setColor(UIStyle.BORDER);
                g2.setStroke(new BasicStroke(1.5f));
                g2.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 8, 8);
                g2.dispose();
                super.paintComponent(g);
            }
        };
        button.setFont(UIStyle.FONT_BUTTON);
        button.setForeground(UIStyle.TEXT_PRIMARY);
        button.setBackground(UIStyle.CARD_BG);
        button.setOpaque(false);
        button.setContentAreaFilled(false);
        button.setBorderPainted(false);
        button.setFocusPainted(false);
        button.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        button.setMaximumSize(new Dimension(320, 44));
        button.setPreferredSize(new Dimension(320, 44));
        button.setAlignmentX(Component.CENTER_ALIGNMENT);

        button.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent e) {
                button.setBackground(UIStyle.BACKGROUND);
            }

            public void mouseExited(java.awt.event.MouseEvent e) {
                button.setBackground(UIStyle.CARD_BG);
            }
        });

        return button;
    }

    private void handleLogin() {
        String email = emailField.getText().trim();
        String password = new String(passwordField.getPassword());

        if (email.isEmpty() || password.isEmpty()) {
            showError("Please enter both email and password");
            return;
        }

        try {
            AuthService authService = new AuthService(userService);
            User user = authService.authenticate(email, password);

            if (user != null) {
                errorLabel.setText(" ");
                onLoginSuccess.accept(user);
            } else {
                showError("Invalid email or password");
                passwordField.setText("");
            }
        } catch (Exception ex) {
            showError("Login failed: " + ex.getMessage());
            passwordField.setText("");
        }
    }

    private void handleRegister() {
        JDialog dialog = new JDialog((Frame) SwingUtilities.getWindowAncestor(this),
                "Create New Account", true);
        dialog.setSize(440, 580);
        dialog.setLocationRelativeTo(this);
        dialog.getContentPane().setBackground(UIStyle.BACKGROUND);

        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBackground(UIStyle.BACKGROUND);
        panel.setBorder(BorderFactory.createEmptyBorder(
                UIStyle.PADDING_LG, UIStyle.PADDING_LG, UIStyle.PADDING_LG, UIStyle.PADDING_LG));

        JLabel titleLabel = UIStyle.createTitleLabel("Create Account");
        titleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        panel.add(titleLabel);
        panel.add(Box.createRigidArea(new Dimension(0, 8)));
        
        // Validation hint
        JLabel hintLabel = new JLabel("<html><center><small>User ID must start with 'U' (e.g., U001)<br>Email must end with @gmail.com</small></center></html>");
        hintLabel.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        hintLabel.setForeground(UIStyle.TEXT_SECONDARY);
        hintLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        panel.add(hintLabel);
        panel.add(Box.createRigidArea(new Dimension(0, UIStyle.PADDING_MD)));

        JTextField regUserId = UIStyle.createTextField();
        JTextField regName = UIStyle.createTextField();
        JTextField regEmail = UIStyle.createTextField();
        JPasswordField regPassword = UIStyle.createPasswordField();
        JPasswordField regConfirmPassword = UIStyle.createPasswordField();
        String[] roles = { "STUDENT", "ACADEMIC_OFFICER", "COURSE_ADMIN" };
        JComboBox<String> roleCombo = UIStyle.createComboBox(roles);

        panel.add(createFormField("User ID", regUserId));
        panel.add(Box.createRigidArea(new Dimension(0, UIStyle.PADDING_SM)));
        panel.add(createFormField("Full Name", regName));
        panel.add(Box.createRigidArea(new Dimension(0, UIStyle.PADDING_SM)));
        panel.add(createFormField("Email", regEmail));
        panel.add(Box.createRigidArea(new Dimension(0, UIStyle.PADDING_SM)));
        panel.add(createFormField("Password", regPassword));
        panel.add(Box.createRigidArea(new Dimension(0, UIStyle.PADDING_SM)));
        panel.add(createFormField("Confirm Password", regConfirmPassword));
        panel.add(Box.createRigidArea(new Dimension(0, UIStyle.PADDING_SM)));
        panel.add(createFormField("Role", roleCombo));
        panel.add(Box.createRigidArea(new Dimension(0, UIStyle.PADDING_LG)));

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, UIStyle.PADDING_SM, 0));
        buttonPanel.setBackground(UIStyle.BACKGROUND);

        JButton createButton = UIStyle.createSuccessButton("Create Account");
        JButton cancelButton = UIStyle.createSecondaryButton("Cancel");

        createButton.addActionListener(e -> {
            String userId = regUserId.getText().trim();
            String name = regName.getText().trim();
            String email = regEmail.getText().trim();
            String password = new String(regPassword.getPassword());
            String confirmPassword = new String(regConfirmPassword.getPassword());
            String role = (String) roleCombo.getSelectedItem();

            // ============ VALIDATION ============
            
            // 1. Check if all fields are filled
            if (userId.isEmpty() || name.isEmpty() || email.isEmpty() || password.isEmpty()) {
                UIStyle.showError(dialog, "Validation Error", "All fields are required!");
                return;
            }

            // 2. Validate User ID format (must start with U)
            if (!userId.toUpperCase().startsWith("U")) {
                UIStyle.showError(dialog, "Invalid User ID", 
                    "User ID must start with 'U' (e.g., U001, U002, U100)");
                return;
            }
            
            // 3. Check if User ID already exists
            boolean userIdExists = false;
            for (User existingUser : userService.getAllUsers()) {
                if (existingUser.getUserID().equalsIgnoreCase(userId)) {
                    userIdExists = true;
                    break;
                }
            }
            if (userIdExists) {
                UIStyle.showError(dialog, "User ID Exists", 
                    "User ID '" + userId + "' is already taken. Please choose a different ID.");
                return;
            }

            // 4. Validate email format (must contain @ and end with @gmail.com)
            if (!email.contains("@")) {
                UIStyle.showError(dialog, "Invalid Email", 
                    "Email must be a valid email address.");
                return;
            }
            
            if (!email.toLowerCase().endsWith("@gmail.com")) {
                UIStyle.showError(dialog, "Invalid Email Domain", 
                    "Email must end with @gmail.com");
                return;
            }

            // 5. Check if email already exists
            User existingUser = userService.getUserByEmail(email);
            if (existingUser != null) {
                UIStyle.showError(dialog, "Email Exists", 
                    "An account with email '" + email + "' already exists.");
                return;
            }

            // 6. Validate password match
            if (!password.equals(confirmPassword)) {
                UIStyle.showError(dialog, "Password Mismatch", 
                    "Passwords do not match!");
                return;
            }
            
            // 7. Validate password strength (minimum 6 characters)
            if (password.length() < 6) {
                UIStyle.showError(dialog, "Weak Password", 
                    "Password must be at least 6 characters long.");
                return;
            }

            // ============ ALL VALIDATIONS PASSED ============

            try {
                User.Role userRole = User.Role.valueOf(role);
                User newUser = new User(userId, name, email, "", userRole, true);
                newUser.resetPassword(password);
                userService.addUser(newUser, password);

                UIStyle.showSuccess(dialog, "Success", 
                    "Account created successfully!\n\nUser ID: " + userId + "\nEmail: " + email);
                dialog.dispose();
                
            } catch (Exception ex) {
                UIStyle.showError(dialog, "Error", 
                    "Failed to create account: " + ex.getMessage());
            }
        });

        cancelButton.addActionListener(e -> dialog.dispose());

        buttonPanel.add(createButton);
        buttonPanel.add(cancelButton);
        panel.add(buttonPanel);

        dialog.add(new JScrollPane(panel));
        dialog.setVisible(true);
    }

    private void showError(String message) {
        errorLabel.setText(message);
    }
}