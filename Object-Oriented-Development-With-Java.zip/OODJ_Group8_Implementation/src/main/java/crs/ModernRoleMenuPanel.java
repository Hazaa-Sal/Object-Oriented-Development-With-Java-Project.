/*
 * ModernRoleMenuPanel - Premium Dashboard
 * Polished, modern, and professional interface
 * Version 2.0 - Full Premium Edition
 */
package crs;

import javax.swing.*;
import java.awt.*;

public class ModernRoleMenuPanel extends JPanel {
    private User currentUser;
    private UserService userService;
    private EmailService emailService;
    private final Runnable onUserManagement;

    public ModernRoleMenuPanel(User currentUser,
            UserService userService,
            EmailService emailService,
            Runnable onCourseRecovery,
            Runnable onReport,
            Runnable onEligibility,
            Runnable onStudentRecovery,
            Runnable onUserManagement,
            Runnable onLogout) {
        this.currentUser = currentUser;
        this.userService = userService;
        this.emailService = emailService;
        this.onUserManagement = onUserManagement;

        setLayout(new BorderLayout());
        setBackground(UIStyle.BACKGROUND);
        initializeComponents(onCourseRecovery, onReport, onEligibility,
                onStudentRecovery, onLogout);
    }

    private void initializeComponents(Runnable onCourseRecovery,
            Runnable onReport,
            Runnable onEligibility,
            Runnable onStudentRecovery,
            Runnable onLogout) {
        // Gradient Header (reduced height)
        add(createGradientHeader(onLogout), BorderLayout.NORTH);

        // Main Content
        add(createMainContent(onCourseRecovery, onReport, onEligibility, onStudentRecovery),
                BorderLayout.CENTER);

        // Premium Footer with divider
        add(UIStyle.createPremiumFooter("(c) 2024 Course Recovery System   |   Version 1.0"),
                BorderLayout.SOUTH);
    }

    private JPanel createGradientHeader(Runnable onLogout) {
        // Gradient panel: #4A54DF to #3F47C9
        JPanel headerPanel = UIStyle.createGradientPanel(
                new Color(74, 84, 223), // #4A54DF
                new Color(63, 71, 201) // #3F47C9
        );
        headerPanel.setLayout(new BorderLayout());
        headerPanel.setBorder(BorderFactory.createEmptyBorder(
                UIStyle.PADDING_MD, UIStyle.PADDING_XL, UIStyle.PADDING_MD, UIStyle.PADDING_XL));

        // Left side - User info
        JPanel leftPanel = new JPanel();
        leftPanel.setLayout(new BoxLayout(leftPanel, BoxLayout.Y_AXIS));
        leftPanel.setOpaque(false);

        JLabel nameLabel = new JLabel(currentUser.getName());
        nameLabel.setFont(UIStyle.FONT_SUBTITLE);
        nameLabel.setForeground(UIStyle.TEXT_WHITE);
        nameLabel.setAlignmentX(Component.LEFT_ALIGNMENT);

        // Small spacing between name and role
        JLabel roleLabel = new JLabel(formatRole(currentUser.getRole().name()));
        roleLabel.setFont(UIStyle.FONT_SMALL);
        roleLabel.setForeground(new Color(180, 190, 255)); // Light purple-ish
        roleLabel.setAlignmentX(Component.LEFT_ALIGNMENT);

        leftPanel.add(nameLabel);
        leftPanel.add(Box.createRigidArea(new Dimension(0, 3)));
        leftPanel.add(roleLabel);

        // Right side - Logout button aligned vertically with name
        JPanel rightPanel = new JPanel(new GridBagLayout());
        rightPanel.setOpaque(false);

        JButton logoutButton = UIStyle.createSmallRoundedButton("Logout",
                new Color(220, 80, 80)); // Softer red
        logoutButton.addActionListener(e -> {
            if (UIStyle.showConfirm(this, "Confirm Logout", "Are you sure you want to logout?")) {
                onLogout.run();
            }
        });

        rightPanel.add(logoutButton);

        headerPanel.add(leftPanel, BorderLayout.WEST);
        headerPanel.add(rightPanel, BorderLayout.EAST);

        return headerPanel;
    }

    private JPanel createMainContent(Runnable onCourseRecovery,
            Runnable onReport,
            Runnable onEligibility,
            Runnable onStudentRecovery) {
        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBackground(UIStyle.BACKGROUND);
        mainPanel.setBorder(BorderFactory.createEmptyBorder(
                UIStyle.PADDING_LG, UIStyle.PADDING_XL, UIStyle.PADDING_SM, UIStyle.PADDING_XL));

        // Greeting section with breathing room
        JPanel greetingPanel = createGreetingPanel();
        mainPanel.add(greetingPanel, BorderLayout.NORTH);

        // Cards grid with reduced spacing
        JPanel cardsWrapper = new JPanel(new BorderLayout());
        cardsWrapper.setOpaque(false);
        cardsWrapper.setBorder(BorderFactory.createEmptyBorder(UIStyle.PADDING_SM, 0, 0, 0));

        JPanel cardsPanel = createCardsPanel(onCourseRecovery, onReport, onEligibility, onStudentRecovery);
        cardsWrapper.add(cardsPanel, BorderLayout.NORTH);

        mainPanel.add(cardsWrapper, BorderLayout.CENTER);

        return mainPanel;
    }

    private JPanel createGreetingPanel() {
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setOpaque(false);
        panel.setBorder(BorderFactory.createEmptyBorder(0, 0, UIStyle.PADDING_MD, 0));

        JLabel welcomeLabel = UIStyle.createTitleLabel("Welcome back, " + currentUser.getName() + "!");
        welcomeLabel.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel subtitleLabel = UIStyle.createSecondaryLabel("Here are your available tools:");
        subtitleLabel.setAlignmentX(Component.LEFT_ALIGNMENT);

        panel.add(welcomeLabel);
        panel.add(Box.createRigidArea(new Dimension(0, 4)));
        panel.add(subtitleLabel);

        return panel;
    }

    private JPanel createCardsPanel(Runnable onCourseRecovery,
            Runnable onReport,
            Runnable onEligibility,
            Runnable onStudentRecovery) {
        // 2x2 grid with reduced gaps
        JPanel panel = new JPanel(new GridLayout(2, 2, UIStyle.CARD_GAP, UIStyle.CARD_GAP));
        panel.setOpaque(false);

        if ("STUDENT".equals(currentUser.getRole().name())) {
            // Student view
            panel.add(createFeatureCard(
                    "My Recovery Plan",
                    "View and manage your course recovery plans",
                    UIStyle.PRIMARY,
                    UIStyle.createRecoveryIcon(UIStyle.ICON_SIZE, UIStyle.TEXT_WHITE),
                    onStudentRecovery));

            panel.add(createFeatureCard(
                    "Check Eligibility",
                    "Check your eligibility for progression",
                    UIStyle.SUCCESS,
                    UIStyle.createEligibilityIcon(UIStyle.ICON_SIZE, UIStyle.TEXT_WHITE),
                    onEligibility));

            panel.add(createFeatureCard(
                    "Academic Report",
                    "View your academic performance",
                    UIStyle.ACCENT,
                    UIStyle.createReportsIcon(UIStyle.ICON_SIZE, UIStyle.TEXT_WHITE),
                    onReport));

            // Empty placeholder
            JPanel emptyCard = new JPanel();
            emptyCard.setOpaque(false);
            panel.add(emptyCard);

        } else {
            // Admin/Officer view
            panel.add(createFeatureCard(
                    "Course Recovery",
                    "Manage student course recovery programs",
                    UIStyle.PRIMARY,
                    UIStyle.createRecoveryIcon(UIStyle.ICON_SIZE, UIStyle.TEXT_WHITE),
                    onCourseRecovery));

            panel.add(createFeatureCard(
                    "User Management",
                    "Add, update, and manage user accounts",
                    UIStyle.ACCENT,
                    UIStyle.createUsersIcon(UIStyle.ICON_SIZE, UIStyle.TEXT_WHITE),
                    onUserManagement));

            panel.add(createFeatureCard(
                    "Academic Reports",
                    "Generate and analyze performance reports",
                    UIStyle.WARNING,
                    UIStyle.createReportsIcon(UIStyle.ICON_SIZE, UIStyle.TEXT_WHITE),
                    onReport));

            panel.add(createFeatureCard(
                    "Eligibility System",
                    "Check student eligibility and enrollment",
                    UIStyle.SUCCESS,
                    UIStyle.createEligibilityIcon(UIStyle.ICON_SIZE, UIStyle.TEXT_WHITE),
                    onEligibility));
        }

        return panel;
    }

    private JPanel createFeatureCard(String title, String description,
            Color accentColor, ImageIcon icon, Runnable onClick) {
        // Premium card with shadow and hover
        JPanel card = UIStyle.createPremiumCard();
        card.setLayout(new BorderLayout(0, 0));
        card.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 0));

        // Left: Icon bar with rounded left corners
        JPanel iconBar = UIStyle.createIconBar(accentColor, icon);

        // Right: Content area
        JPanel contentPanel = new JPanel();
        contentPanel.setLayout(new BoxLayout(contentPanel, BoxLayout.Y_AXIS));
        contentPanel.setOpaque(false);
        contentPanel.setBorder(BorderFactory.createEmptyBorder(
                UIStyle.PADDING_LG, UIStyle.PADDING_MD, UIStyle.PADDING_LG, UIStyle.PADDING_LG));

        JLabel titleLabel = new JLabel(title);
        titleLabel.setFont(UIStyle.FONT_SUBTITLE);
        titleLabel.setForeground(UIStyle.TEXT_PRIMARY);
        titleLabel.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel descLabel = new JLabel("<html><div style='width:180px'>" + description + "</div></html>");
        descLabel.setFont(UIStyle.FONT_SMALL);
        descLabel.setForeground(UIStyle.TEXT_SECONDARY);
        descLabel.setAlignmentX(Component.LEFT_ALIGNMENT);

        contentPanel.add(titleLabel);
        contentPanel.add(Box.createRigidArea(new Dimension(0, 6)));
        contentPanel.add(descLabel);

        card.add(iconBar, BorderLayout.WEST);
        card.add(contentPanel, BorderLayout.CENTER);

        // Click handler
        card.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent e) {
                onClick.run();
            }
        });

        return card;
    }

    private String formatRole(String role) {
        switch (role) {
            case "ACADEMIC_OFFICER":
                return "Academic Officer";
            case "COURSE_ADMIN":
                return "Course Administrator";
            case "STUDENT":
                return "Student";
            default:
                return role;
        }
    }

    private void showUserManagement() {
        UserManagementPanel userManagementPanel = new UserManagementPanel(
                userService,
                emailService,
                () -> UIStyle.showInfo(this, "Info", "Returning to main menu"));

        JDialog dialog = new JDialog((Frame) SwingUtilities.getWindowAncestor(this),
                "User Management", true);
        dialog.setSize(900, 600);
        dialog.setLocationRelativeTo(this);
        dialog.add(userManagementPanel);
        dialog.setVisible(true);
    }
}