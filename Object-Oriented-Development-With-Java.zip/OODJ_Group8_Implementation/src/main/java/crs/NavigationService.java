/*
 * NavigationService - Centralized Navigation with Permission Checks
 * All module navigation MUST go through this service
 */
package crs;

import crs.PermissionService.Module;
import javax.swing.*;
import java.awt.*;

/**
 * Centralized navigation service that enforces permission checks
 * before opening any module.
 */
public class NavigationService {

    private static MainGUI mainFrame;

    /**
     * Set the main frame reference for navigation
     */
    public static void setMainFrame(MainGUI frame) {
        mainFrame = frame;
    }

    /**
     * Open a module with permission check
     * 
     * @param user   The user requesting access
     * @param module The module to open
     * @return true if module was opened, false if access denied
     */
    public static boolean openModule(User user, Module module) {
        // Check permission first
        if (!PermissionService.hasAccess(user, module)) {
            showAccessDenied(module);
            return false;
        }

        // Log navigation
        System.out.println("[NAV] User '" + user.getName() + "' (" + user.getRole() +
                ") -> " + module.getDisplayName());

        // Delegate to MainGUI for actual panel loading
        if (mainFrame != null) {
            mainFrame.navigateToModule(module);
        }

        return true;
    }

    /**
     * Check if navigation to a module is allowed (without opening)
     * 
     * @param user   The user
     * @param module The target module
     * @return true if allowed, false otherwise
     */
    public static boolean canNavigate(User user, Module module) {
        return PermissionService.hasAccess(user, module);
    }

    /**
     * Show access denied dialog
     */
    private static void showAccessDenied(Module module) {
        Component parent = mainFrame != null ? mainFrame : null;
        UIStyle.showError(parent, "Access Denied",
                PermissionService.getAccessDeniedMessage(module));
    }

    /**
     * Navigate back to dashboard
     */
    public static void goToDashboard() {
        User user = CurrentSession.getUser();
        if (mainFrame != null && user != null) {
            mainFrame.navigateToModule(Module.DASHBOARD);
        }
    }

    /**
     * Handle logout
     */
    public static void logout() {
        if (mainFrame != null) {
            mainFrame.handleLogout();
        }
    }

    // Private constructor
    private NavigationService() {
    }
}
