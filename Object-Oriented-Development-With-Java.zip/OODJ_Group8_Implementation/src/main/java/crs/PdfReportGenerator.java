/*
 * PDF Report Generator using iText
 * Generates academic performance reports as PDF documents
 */
package crs;

import com.crs.model.Student;
import com.crs.model.Component;
import com.itextpdf.text.*;
import com.itextpdf.text.pdf.*;
import com.itextpdf.text.pdf.draw.LineSeparator;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

/**
 * Generates professional PDF academic performance reports using iText library.
 * This class creates structured academic reports with:
 * - Student details header
 * - Course performance table with grades
 * - CGPA calculation and summary
 */
public class PdfReportGenerator {

    // Font definitions for consistent styling
    private static final Font TITLE_FONT = new Font(Font.FontFamily.HELVETICA, 20, Font.BOLD,
            new BaseColor(79, 70, 229));
    private static final Font HEADER_FONT = new Font(Font.FontFamily.HELVETICA, 14, Font.BOLD, BaseColor.DARK_GRAY);
    private static final Font NORMAL_FONT = new Font(Font.FontFamily.HELVETICA, 11, Font.NORMAL, BaseColor.BLACK);
    private static final Font BOLD_FONT = new Font(Font.FontFamily.HELVETICA, 11, Font.BOLD, BaseColor.BLACK);
    private static final Font TABLE_HEADER_FONT = new Font(Font.FontFamily.HELVETICA, 10, Font.BOLD, BaseColor.WHITE);
    private static final Font TABLE_CELL_FONT = new Font(Font.FontFamily.HELVETICA, 10, Font.NORMAL, BaseColor.BLACK);
    private static final Font PASS_FONT = new Font(Font.FontFamily.HELVETICA, 10, Font.BOLD,
            new BaseColor(22, 163, 74));
    private static final Font FAIL_FONT = new Font(Font.FontFamily.HELVETICA, 10, Font.BOLD,
            new BaseColor(220, 38, 38));

    /**
     * Generate a PDF academic report for a student.
     * 
     * @param student The student to generate report for
     * @return File path to the generated PDF
     * @throws DocumentException if PDF creation fails
     * @throws IOException       if file operations fail
     */
    public static String generateAcademicReport(Student student) throws DocumentException, IOException {
        // Create output file in temp directory
        String fileName = "AcademicReport_" + student.getId() + "_" +
                LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss")) + ".pdf";
        String filePath = System.getProperty("java.io.tmpdir") + File.separator + fileName;

        // Create document
        Document document = new Document(PageSize.A4, 50, 50, 50, 50);
        PdfWriter writer = PdfWriter.getInstance(document, new FileOutputStream(filePath));

        document.open();

        // Add report title
        addTitle(document, "Academic Performance Report");

        // Add generation timestamp
        Paragraph timestamp = new Paragraph("Generated: " +
                LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd MMMM yyyy, HH:mm")),
                new Font(Font.FontFamily.HELVETICA, 9, Font.ITALIC, BaseColor.GRAY));
        timestamp.setAlignment(Element.ALIGN_RIGHT);
        document.add(timestamp);

        document.add(Chunk.NEWLINE);

        // Add student details section
        addStudentDetailsSection(document, student);

        document.add(Chunk.NEWLINE);

        // Add course performance table
        addCoursePerformanceTable(document, student);

        document.add(Chunk.NEWLINE);

        // Add summary section
        addSummarySection(document, student);

        // Add footer
        addFooter(document);

        document.close();

        return filePath;
    }

    private static void addTitle(Document document, String title) throws DocumentException {
        Paragraph titlePara = new Paragraph(title, TITLE_FONT);
        titlePara.setAlignment(Element.ALIGN_CENTER);
        titlePara.setSpacingAfter(10);
        document.add(titlePara);

        // Add line separator
        LineSeparator line = new LineSeparator();
        line.setLineColor(new BaseColor(79, 70, 229));
        line.setLineWidth(2);
        document.add(new Chunk(line));
    }

    private static void addStudentDetailsSection(Document document, Student student) throws DocumentException {
        Paragraph sectionTitle = new Paragraph("Student Information", HEADER_FONT);
        sectionTitle.setSpacingBefore(10);
        sectionTitle.setSpacingAfter(10);
        document.add(sectionTitle);

        // Create a table for student details
        PdfPTable detailsTable = new PdfPTable(2);
        detailsTable.setWidthPercentage(60);
        detailsTable.setHorizontalAlignment(Element.ALIGN_LEFT);
        detailsTable.setWidths(new float[] { 1.5f, 3f });

        addDetailRow(detailsTable, "Student ID:", student.getId());
        addDetailRow(detailsTable, "Name:", student.getName());
        addDetailRow(detailsTable, "Course:", student.getMajor() != null ? student.getMajor() : "N/A");
        addDetailRow(detailsTable, "Year:", student.getYear() != null ? student.getYear() : "N/A");
        addDetailRow(detailsTable, "Email:", student.getEmail() != null ? student.getEmail() : "N/A");

        document.add(detailsTable);
    }

    private static void addDetailRow(PdfPTable table, String label, String value) {
        PdfPCell labelCell = new PdfPCell(new Phrase(label, BOLD_FONT));
        labelCell.setBorder(Rectangle.NO_BORDER);
        labelCell.setPadding(5);
        table.addCell(labelCell);

        PdfPCell valueCell = new PdfPCell(new Phrase(value, NORMAL_FONT));
        valueCell.setBorder(Rectangle.NO_BORDER);
        valueCell.setPadding(5);
        table.addCell(valueCell);
    }

    private static void addCoursePerformanceTable(Document document, Student student) throws DocumentException {
        Paragraph sectionTitle = new Paragraph("Course Performance", HEADER_FONT);
        sectionTitle.setSpacingBefore(15);
        sectionTitle.setSpacingAfter(10);
        document.add(sectionTitle);

        List<Component> components = student.getComponents();

        if (components.isEmpty()) {
            document.add(new Paragraph("No course data available.", NORMAL_FONT));
            return;
        }

        // Create table with 5 columns
        PdfPTable table = new PdfPTable(5);
        table.setWidthPercentage(100);
        table.setWidths(new float[] { 3f, 2f, 1.5f, 1.5f, 1.5f });

        // Add header row
        addTableHeader(table, "Course Name");
        addTableHeader(table, "Lecturer");
        addTableHeader(table, "Score");
        addTableHeader(table, "Grade Points");
        addTableHeader(table, "Status");

        // Add data rows
        for (Component comp : components) {
            double gradePoint = scoreToGradePoint(comp.getScore());
            boolean passed = comp.isPassed();

            addTableCell(table, comp.getName(), TABLE_CELL_FONT, Element.ALIGN_LEFT);
            addTableCell(table, comp.getLecturer() != null ? comp.getLecturer() : "N/A", TABLE_CELL_FONT,
                    Element.ALIGN_LEFT);
            addTableCell(table, String.format("%.1f%%", comp.getScore()), TABLE_CELL_FONT, Element.ALIGN_CENTER);
            addTableCell(table, String.format("%.2f", gradePoint), TABLE_CELL_FONT, Element.ALIGN_CENTER);

            Font statusFont = passed ? PASS_FONT : FAIL_FONT;
            addTableCell(table, passed ? "PASS" : "FAIL", statusFont, Element.ALIGN_CENTER);
        }

        document.add(table);
    }

    private static void addTableHeader(PdfPTable table, String text) {
        PdfPCell cell = new PdfPCell(new Phrase(text, TABLE_HEADER_FONT));
        cell.setBackgroundColor(new BaseColor(79, 70, 229));
        cell.setPadding(8);
        cell.setHorizontalAlignment(Element.ALIGN_CENTER);
        cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
        table.addCell(cell);
    }

    private static void addTableCell(PdfPTable table, String text, Font font, int alignment) {
        PdfPCell cell = new PdfPCell(new Phrase(text, font));
        cell.setPadding(6);
        cell.setHorizontalAlignment(alignment);
        cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
        table.addCell(cell);
    }

    private static void addSummarySection(Document document, Student student) throws DocumentException {
        Paragraph sectionTitle = new Paragraph("Academic Summary", HEADER_FONT);
        sectionTitle.setSpacingBefore(15);
        sectionTitle.setSpacingAfter(10);
        document.add(sectionTitle);

        List<Component> components = student.getComponents();

        int totalCourses = components.size();
        int passedCourses = 0;
        int failedCourses = 0;
        double totalGradePoints = 0;

        for (Component comp : components) {
            if (comp.isPassed()) {
                passedCourses++;
            } else {
                failedCourses++;
            }
            totalGradePoints += scoreToGradePoint(comp.getScore());
        }

        double cgpa = totalCourses > 0 ? totalGradePoints / totalCourses : 0;

        // Create summary table
        PdfPTable summaryTable = new PdfPTable(2);
        summaryTable.setWidthPercentage(50);
        summaryTable.setHorizontalAlignment(Element.ALIGN_LEFT);

        addSummaryRow(summaryTable, "Total Courses:", String.valueOf(totalCourses));
        addSummaryRow(summaryTable, "Courses Passed:", String.valueOf(passedCourses));
        addSummaryRow(summaryTable, "Courses Failed:", String.valueOf(failedCourses));
        addSummaryRow(summaryTable, "Cumulative GPA:", String.format("%.2f", cgpa));

        document.add(summaryTable);

        document.add(Chunk.NEWLINE);

        // Add eligibility status
        boolean eligible = cgpa >= 2.0 && failedCourses <= 3;
        String statusText = eligible ? "✓ ELIGIBLE - Meets all requirements"
                : "✗ AT RISK - Academic intervention required";
        Font statusFont = eligible ? new Font(Font.FontFamily.HELVETICA, 12, Font.BOLD, new BaseColor(22, 163, 74))
                : new Font(Font.FontFamily.HELVETICA, 12, Font.BOLD, new BaseColor(220, 38, 38));

        Paragraph status = new Paragraph("Eligibility Status: " + statusText, statusFont);
        status.setSpacingBefore(10);
        document.add(status);
    }

    private static void addSummaryRow(PdfPTable table, String label, String value) {
        PdfPCell labelCell = new PdfPCell(new Phrase(label, BOLD_FONT));
        labelCell.setBackgroundColor(new BaseColor(243, 244, 246));
        labelCell.setPadding(8);
        table.addCell(labelCell);

        PdfPCell valueCell = new PdfPCell(new Phrase(value, NORMAL_FONT));
        valueCell.setPadding(8);
        table.addCell(valueCell);
    }

    private static void addFooter(Document document) throws DocumentException {
        document.add(Chunk.NEWLINE);
        document.add(Chunk.NEWLINE);

        LineSeparator line = new LineSeparator();
        line.setLineColor(BaseColor.LIGHT_GRAY);
        document.add(new Chunk(line));

        Paragraph footer = new Paragraph(
                "This report was generated by the Course Recovery System (CRS).\n" +
                        "For questions or concerns, please contact your academic advisor.",
                new Font(Font.FontFamily.HELVETICA, 9, Font.ITALIC, BaseColor.GRAY));
        footer.setAlignment(Element.ALIGN_CENTER);
        footer.setSpacingBefore(10);
        document.add(footer);
    }

    /**
     * Generate a PDF recovery plan for a student's failed component.
     * 
     * @param studentName   Name of the student
     * @param studentEmail  Email of the student
     * @param componentName Name of the failed component
     * @return File path to the generated PDF
     * @throws DocumentException if PDF creation fails
     * @throws IOException       if file operations fail
     */
    public static String generateRecoveryPlanPdf(String studentName, String studentEmail, String componentName)
            throws DocumentException, IOException {
        // Create output file in temp directory
        String fileName = "RecoveryPlan_" + componentName.replaceAll("\\s+", "_") + "_" +
                LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss")) + ".pdf";
        String filePath = System.getProperty("java.io.tmpdir") + File.separator + fileName;

        // Create document
        Document document = new Document(PageSize.A4, 50, 50, 50, 50);
        PdfWriter writer = PdfWriter.getInstance(document, new FileOutputStream(filePath));

        document.open();

        // Add report title
        addTitle(document, "Course Recovery Plan");

        // Add generation timestamp
        Paragraph timestamp = new Paragraph("Generated: " +
                LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd MMMM yyyy, HH:mm")),
                new Font(Font.FontFamily.HELVETICA, 9, Font.ITALIC, BaseColor.GRAY));
        timestamp.setAlignment(Element.ALIGN_RIGHT);
        document.add(timestamp);

        document.add(Chunk.NEWLINE);

        // Add student information section
        Paragraph studentInfoTitle = new Paragraph("Student Information", HEADER_FONT);
        studentInfoTitle.setSpacingBefore(10);
        studentInfoTitle.setSpacingAfter(10);
        document.add(studentInfoTitle);

        PdfPTable studentTable = new PdfPTable(2);
        studentTable.setWidthPercentage(60);
        studentTable.setHorizontalAlignment(Element.ALIGN_LEFT);
        studentTable.setWidths(new float[] { 1.5f, 3f });

        addDetailRow(studentTable, "Student Name:", studentName);
        addDetailRow(studentTable, "Email:", studentEmail);

        document.add(studentTable);

        document.add(Chunk.NEWLINE);

        // Add failed component section
        Paragraph componentTitle = new Paragraph("Failed Component", HEADER_FONT);
        componentTitle.setSpacingBefore(10);
        componentTitle.setSpacingAfter(10);
        document.add(componentTitle);

        Paragraph componentInfo = new Paragraph("Component: " + componentName, BOLD_FONT);
        componentInfo.setSpacingBefore(5);
        componentInfo.setSpacingAfter(10);
        document.add(componentInfo);

        document.add(Chunk.NEWLINE);

        // Add recovery plan section
        Paragraph planTitle = new Paragraph("Recovery Plan", HEADER_FONT);
        planTitle.setSpacingBefore(15);
        planTitle.setSpacingAfter(10);
        document.add(planTitle);

        // Create recovery plan table
        PdfPTable planTable = new PdfPTable(2);
        planTable.setWidthPercentage(100);
        planTable.setWidths(new float[] { 1.5f, 4f });

        // Add header row
        addTableHeader(planTable, "Timeframe");
        addTableHeader(planTable, "Task");

        // Add recovery tasks
        addRecoveryTaskRow(planTable, "Week 1-2", "Review all lecture topics");
        addRecoveryTaskRow(planTable, "Week 3", "Meeting with module lecturer");
        addRecoveryTaskRow(planTable, "Week 4", "Take recovery exam");

        document.add(planTable);

        document.add(Chunk.NEWLINE);

        // Add important notice
        Paragraph notice = new Paragraph(
                "Please follow this recovery plan and complete the required steps before the deadline.\n" +
                        "If you have questions, contact your Academic Officer.",
                NORMAL_FONT);
        notice.setSpacingBefore(15);
        notice.setSpacingAfter(10);
        document.add(notice);

        // Add footer
        addRecoveryPlanFooter(document);

        document.close();

        return filePath;
    }

    /**
     * Add a recovery task row to the plan table
     */
    private static void addRecoveryTaskRow(PdfPTable table, String timeframe, String task) {
        PdfPCell timeCell = new PdfPCell(new Phrase(timeframe, BOLD_FONT));
        timeCell.setPadding(8);
        timeCell.setBackgroundColor(new BaseColor(243, 244, 246));
        table.addCell(timeCell);

        PdfPCell taskCell = new PdfPCell(new Phrase(task, NORMAL_FONT));
        taskCell.setPadding(8);
        table.addCell(taskCell);
    }

    /**
     * Add footer for recovery plan PDF
     */
    private static void addRecoveryPlanFooter(Document document) throws DocumentException {
        document.add(Chunk.NEWLINE);
        document.add(Chunk.NEWLINE);

        LineSeparator line = new LineSeparator();
        line.setLineColor(BaseColor.LIGHT_GRAY);
        document.add(new Chunk(line));

        Paragraph footer = new Paragraph(
                "This recovery plan was generated by the Course Recovery System (CRS).\n" +
                        "For assistance, please contact your academic advisor.",
                new Font(Font.FontFamily.HELVETICA, 9, Font.ITALIC, BaseColor.GRAY));
        footer.setAlignment(Element.ALIGN_CENTER);
        footer.setSpacingBefore(10);
        document.add(footer);
    }

    /**
     * Convert percentage score to GPA grade points (4.0 scale)
     */
    private static double scoreToGradePoint(double percentageScore) {
        if (percentageScore >= 90)
            return 4.0;
        if (percentageScore >= 80)
            return 3.5;
        if (percentageScore >= 70)
            return 3.0;
        if (percentageScore >= 60)
            return 2.5;
        if (percentageScore >= 50)
            return 2.0;
        if (percentageScore >= 40)
            return 1.5;
        return 0.0;
    }
}
