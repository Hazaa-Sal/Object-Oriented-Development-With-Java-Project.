/*
 * PermissionService - Complete Role-Based Access Control for CRS
 * Authoritative permission definitions and enforcement
 * 
 * ROLE DEFINITIONS (follow these exactly):
 * 
 * 1) COURSE_ADMIN: Dashboard, User Management, Academic Reports, Eligibility Checker, Settings, Logout
 *    - NOT ALLOWED: Course Recovery (explicitly blocked)
 * 
 * 2) ACADEMIC_OFFICER: Full access to everything (all modules)
 * 
 * 3) ADMIN (System Admin / Superuser): Full system access (same as Academic Officer + advanced)
 * 
 * 4) STUDENT: Personal modules only (their own data)
 */
package crs;

import java.util.*;

/**
 * Centralized Permission Service for CRS
 * All access checks must go through this service
 */
public class PermissionService {

    // ==================== MODULE DEFINITIONS ====================

    public enum Module {
        // Common
        DASHBOARD("Dashboard Overview"),
        LOGOUT("Logout"),

        // Student-only modules (view own data)
        MY_PROFILE("My Profile"),
        MY_ACADEMIC_REPORT("My Academic Report"),
        MY_RECOVERY_STATUS("My Recovery Status"),
        MY_ELIGIBILITY("My Eligibility Result"),

        // Staff modules
        COURSE_RECOVERY("Course Recovery Management"),
        ELIGIBILITY_CHECKER("Eligibility Checker"),
        ACADEMIC_REPORTS("Academic Reports"),
        USER_MANAGEMENT("User Management"),
        SETTINGS("Settings"),

        // Admin-only
        SYSTEM_LOGS("System Logs"),
        SYSTEM_CONFIG("System Configuration");

        private final String displayName;

        Module(String displayName) {
            this.displayName = displayName;
        }

        public String getDisplayName() {
            return displayName;
        }
    }

    // ==================== PERMISSION MAPPINGS ====================

    private static final Map<User.Role, Set<Module>> ROLE_PERMISSIONS = new EnumMap<>(User.Role.class);

    static {
        // ========================================
        // STUDENT - Personal/self-service only
        // ========================================
        Set<Module> studentModules = EnumSet.of(
                Module.DASHBOARD,
                Module.MY_PROFILE,
                Module.MY_ACADEMIC_REPORT,
                Module.MY_RECOVERY_STATUS,
                Module.MY_ELIGIBILITY,
                Module.LOGOUT);
        ROLE_PERMISSIONS.put(User.Role.STUDENT, studentModules);

        // ========================================
        // COURSE_ADMIN - User/System management
        // NOTE: Does NOT have Course Recovery access!
        // ========================================
        Set<Module> courseAdminModules = EnumSet.of(
                Module.DASHBOARD,
                Module.USER_MANAGEMENT,
                Module.ACADEMIC_REPORTS,
                Module.ELIGIBILITY_CHECKER,
                Module.SETTINGS,
                Module.LOGOUT
        // COURSE_RECOVERY is explicitly NOT included
        );
        ROLE_PERMISSIONS.put(User.Role.COURSE_ADMIN, courseAdminModules);

        // ========================================
        // ACADEMIC_OFFICER - Full access
        // (All functional modules including Course Recovery)
        // ========================================
        Set<Module> officerModules = EnumSet.of(
                Module.DASHBOARD,
                Module.COURSE_RECOVERY, // Officer CAN access Course Recovery
                Module.ELIGIBILITY_CHECKER,
                Module.ACADEMIC_REPORTS,
                Module.USER_MANAGEMENT,
                Module.SETTINGS,
                Module.LOGOUT);
        ROLE_PERMISSIONS.put(User.Role.ACADEMIC_OFFICER, officerModules);

        // ========================================
        // ADMIN (System Admin / Superuser) - Full access + advanced
        // ========================================
        // If ADMIN role exists, grant everything
        try {
            User.Role adminRole = User.Role.valueOf("ADMIN");
            Set<Module> adminModules = EnumSet.allOf(Module.class);
            ROLE_PERMISSIONS.put(adminRole, adminModules);
        } catch (IllegalArgumentException e) {
            // ADMIN role doesn't exist in enum, that's OK
        }
    }

    // ==================== ACCESS CHECK METHODS ====================

    /**
     * Check if a user has access to a specific module
     * 
     * @param user   The user requesting access
     * @param module The module to access
     * @return true if access is allowed, false otherwise
     */
    public static boolean hasAccess(User user, Module module) {
        if (user == null || module == null) {
            return false;
        }

        Set<Module> allowedModules = ROLE_PERMISSIONS.get(user.getRole());
        if (allowedModules == null) {
            return false;
        }

        return allowedModules.contains(module);
    }

    /**
     * Check access and throw exception if denied
     * Use this for backend enforcement / defense in depth
     * 
     * @param user   The user requesting access
     * @param module The module to access
     * @throws UnauthorizedActionException if access is denied
     */
    public static void checkAccessOrThrow(User user, Module module) throws UnauthorizedActionException {
        if (!hasAccess(user, module)) {
            throw new UnauthorizedActionException(user, module.getDisplayName());
        }
    }

    /**
     * Get all modules a user has access to
     * 
     * @param user The user
     * @return Set of allowed modules
     */
    public static Set<Module> getAllowedModules(User user) {
        if (user == null) {
            return EnumSet.noneOf(Module.class);
        }

        Set<Module> allowed = ROLE_PERMISSIONS.get(user.getRole());
        return allowed != null ? EnumSet.copyOf(allowed) : EnumSet.noneOf(Module.class);
    }

    /**
     * Get sidebar modules for a user's role (in display order)
     * 
     * @param user The user
     * @return List of modules for sidebar
     */
    public static List<Module> getSidebarModules(User user) {
        List<Module> sidebarModules = new ArrayList<>();

        if (user == null) {
            return sidebarModules;
        }

        switch (user.getRole()) {
            case STUDENT:
                sidebarModules.add(Module.DASHBOARD);
                sidebarModules.add(Module.MY_ACADEMIC_REPORT);
                sidebarModules.add(Module.MY_ELIGIBILITY);
                sidebarModules.add(Module.MY_RECOVERY_STATUS);
                sidebarModules.add(Module.MY_PROFILE);
                sidebarModules.add(Module.LOGOUT);
                break;

            case COURSE_ADMIN:
                // Course Admin: NO Course Recovery!
                sidebarModules.add(Module.DASHBOARD);
                sidebarModules.add(Module.USER_MANAGEMENT);
                sidebarModules.add(Module.ACADEMIC_REPORTS);
                sidebarModules.add(Module.ELIGIBILITY_CHECKER);
                sidebarModules.add(Module.SETTINGS);
                sidebarModules.add(Module.LOGOUT);
                break;

            case ACADEMIC_OFFICER:
                // Academic Officer: Full access including Course Recovery
                sidebarModules.add(Module.DASHBOARD);
                sidebarModules.add(Module.COURSE_RECOVERY);
                sidebarModules.add(Module.ELIGIBILITY_CHECKER);
                sidebarModules.add(Module.ACADEMIC_REPORTS);
                sidebarModules.add(Module.USER_MANAGEMENT);
                sidebarModules.add(Module.SETTINGS);
                sidebarModules.add(Module.LOGOUT);
                break;

            default:
                // Unknown role - dashboard and logout only
                sidebarModules.add(Module.DASHBOARD);
                sidebarModules.add(Module.LOGOUT);
                break;
        }

        return sidebarModules;
    }

    /**
     * Get dashboard card modules for a user's role
     * 
     * @param user The user
     * @return List of modules to show as dashboard cards
     */
    public static List<Module> getDashboardCardModules(User user) {
        List<Module> cardModules = new ArrayList<>();

        if (user == null) {
            return cardModules;
        }

        switch (user.getRole()) {
            case STUDENT:
                cardModules.add(Module.MY_ACADEMIC_REPORT);
                cardModules.add(Module.MY_ELIGIBILITY);
                cardModules.add(Module.MY_RECOVERY_STATUS);
                cardModules.add(Module.MY_PROFILE);
                break;

            case COURSE_ADMIN:
                // Course Admin: NO Course Recovery card!
                cardModules.add(Module.USER_MANAGEMENT);
                cardModules.add(Module.ACADEMIC_REPORTS);
                cardModules.add(Module.ELIGIBILITY_CHECKER);
                cardModules.add(Module.SETTINGS);
                break;

            case ACADEMIC_OFFICER:
                // Academic Officer: Full access including Course Recovery
                cardModules.add(Module.COURSE_RECOVERY);
                cardModules.add(Module.ELIGIBILITY_CHECKER);
                cardModules.add(Module.ACADEMIC_REPORTS);
                cardModules.add(Module.USER_MANAGEMENT);
                break;

            default:
                break;
        }

        return cardModules;
    }

    /**
     * Get role display name
     */
    public static String getRoleDisplayName(User.Role role) {
        if (role == null)
            return "Unknown";
        switch (role) {
            case STUDENT:
                return "Student";
            case COURSE_ADMIN:
                return "Course Administrator";
            case ACADEMIC_OFFICER:
                return "Academic Officer";
            default:
                return role.name();
        }
    }

    /**
     * Get role description for display
     */
    public static String getRoleDescription(User.Role role) {
        switch (role) {
            case STUDENT:
                return "Student - View your academic progress and recovery status";
            case COURSE_ADMIN:
                return "Course Administrator - Manage users, reports, and eligibility (No Course Recovery access)";
            case ACADEMIC_OFFICER:
                return "Academic Officer - Full access including Course Recovery management";
            default:
                return "Unknown Role";
        }
    }

    /**
     * Get access denied message for a module
     */
    public static String getAccessDeniedMessage(Module module) {
        return "Access Denied\n\nYou do not have permission to access:\n" + module.getDisplayName() +
                "\n\nPlease contact your administrator if you believe this is an error.";
    }

    /**
     * Print permission summary to console (for testing/verification)
     */
    public static void printPermissionSummary() {
        System.out.println("\n=== CRS PERMISSION SUMMARY ===");
        for (User.Role role : User.Role.values()) {
            System.out.println("\nRole: " + role);
            Set<Module> modules = ROLE_PERMISSIONS.get(role);
            if (modules != null) {
                for (Module m : modules) {
                    System.out.println("  [+] " + m.getDisplayName());
                }
            } else {
                System.out.println("  (No permissions defined)");
            }
        }
        System.out.println("\n==============================\n");
    }

    // Private constructor - utility class
    private PermissionService() {
    }
}
