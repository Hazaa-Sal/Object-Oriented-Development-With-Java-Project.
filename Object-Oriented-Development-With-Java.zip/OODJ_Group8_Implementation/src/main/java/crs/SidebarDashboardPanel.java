/*
 * SidebarDashboardPanel - Role-Based Dashboard with Sidebar
 * Builds dashboard dynamically based on user's role permissions
 * Version 5.0 - Complete RBAC Implementation
 * 
 * ROLE PERMISSIONS:
 * - COURSE_ADMIN: User Management, Academic Reports, Eligibility Checker, Settings (NO Course Recovery!)
 * - ACADEMIC_OFFICER: Full access including Course Recovery
 * - STUDENT: Personal modules only
 */
package crs;

import com.crs.service.StudentService;
import crs.PermissionService.Module;
import javax.swing.*;
import java.awt.*;
import java.util.List;

/**
 * Main Dashboard with Sidebar Navigation
 * Implements complete Role-Based Access Control
 */
public class SidebarDashboardPanel extends JPanel {
    private User currentUser;
    private UserService userService;
    private EmailService emailService;
    private StudentService studentService;

    // Navigation callbacks
    private Runnable onCourseRecovery;
    private Runnable onReport;
    private Runnable onEligibility;
    private Runnable onUserManagement;
    private Runnable onLogout;

    // Current active menu
    private String activeMenu = "Dashboard";

    public SidebarDashboardPanel(User currentUser,
            UserService userService,
            EmailService emailService,
            StudentService studentService,
            Runnable onCourseRecovery,
            Runnable onReport,
            Runnable onEligibility,
            Runnable onUserManagement,
            Runnable onLogout) {
        this.currentUser = currentUser;
        this.userService = userService;
        this.emailService = emailService;
        this.studentService = studentService;
        this.onCourseRecovery = onCourseRecovery;
        this.onReport = onReport;
        this.onEligibility = onEligibility;
        this.onUserManagement = onUserManagement;
        this.onLogout = onLogout;

        setLayout(new BorderLayout());
        setBackground(UIStyle.BACKGROUND);

        // Build role-specific dashboard
        add(buildDashboardForRole(currentUser));
    }

    /**
     * BUILD DASHBOARD FOR ROLE
     * 
     * This is the main method that constructs the entire dashboard
     * based on the user's role permissions.
     * 
     * @param user The logged-in user
     * @return JPanel containing the complete role-specific dashboard
     */
    public JPanel buildDashboardForRole(User user) {
        JPanel dashboard = new JPanel(new BorderLayout());
        dashboard.setBackground(UIStyle.BACKGROUND);

        // Build sidebar based on allowed modules for this role
        List<Module> sidebarModules = PermissionService.getSidebarModules(user);
        JPanel sidebar = buildSidebar(user, sidebarModules);
        dashboard.add(sidebar, BorderLayout.WEST);

        // Build main content with role-specific metrics and cards
        List<Module> cardModules = PermissionService.getDashboardCardModules(user);
        JPanel mainContent = buildMainContent(user, cardModules);
        dashboard.add(mainContent, BorderLayout.CENTER);

        return dashboard;
    }

    // ==================== SIDEBAR BUILDER ====================

    /**
     * Build sidebar from list of allowed modules
     */
    private JPanel buildSidebar(User user, List<Module> allowedModules) {
        JPanel sidebar = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);

                GradientPaint gradient = new GradientPaint(
                        0, 0, UIStyle.SIDEBAR_BG,
                        0, getHeight(), UIStyle.PRIMARY_DARK);
                g2.setPaint(gradient);
                g2.fillRect(0, 0, getWidth(), getHeight());
                g2.dispose();
            }
        };
        sidebar.setPreferredSize(new Dimension(UIStyle.SIDEBAR_WIDTH, 0));
        sidebar.setLayout(new BorderLayout());

        // Top section (Logo + Role Badge + Navigation)
        JPanel topSection = new JPanel();
        topSection.setOpaque(false);
        topSection.setLayout(new BoxLayout(topSection, BoxLayout.Y_AXIS));

        topSection.add(createLogoPanel());
        topSection.add(Box.createRigidArea(new Dimension(0, UIStyle.PADDING_SM)));
        topSection.add(createRoleBadge(user));
        topSection.add(Box.createRigidArea(new Dimension(0, UIStyle.PADDING_LG)));

        // Add sidebar items for allowed modules only
        for (Module module : allowedModules) {
            if (module == Module.LOGOUT)
                continue; // Handle at bottom

            boolean isActive = module == Module.DASHBOARD && "Dashboard".equals(activeMenu);

            topSection.add(UIStyle.createSidebarItem(
                    module.getDisplayName(),
                    getIconForModule(module),
                    isActive,
                    () -> handleModuleClick(module)));
        }

        sidebar.add(topSection, BorderLayout.NORTH);

        // Bottom section (Logout)
        JPanel bottomSection = new JPanel();
        bottomSection.setOpaque(false);
        bottomSection.setLayout(new BoxLayout(bottomSection, BoxLayout.Y_AXIS));

        bottomSection.add(UIStyle.createSidebarItem("Logout",
                UIStyle.createLogoutIcon(UIStyle.ICON_SIZE, UIStyle.TEXT_WHITE),
                false, this::handleLogoutClick));

        bottomSection.add(Box.createRigidArea(new Dimension(0, UIStyle.PADDING_LG)));

        sidebar.add(bottomSection, BorderLayout.SOUTH);

        return sidebar;
    }

    private JPanel createLogoPanel() {
        JPanel logoPanel = new JPanel();
        logoPanel.setOpaque(false);
        logoPanel.setLayout(new FlowLayout(FlowLayout.LEFT, UIStyle.PADDING_LG, UIStyle.PADDING_LG));
        logoPanel.setMaximumSize(new Dimension(UIStyle.SIDEBAR_WIDTH, 70));

        JPanel logoIcon = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(UIStyle.TEXT_WHITE);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 8, 8);
                g2.dispose();
            }
        };
        logoIcon.setOpaque(false);
        logoIcon.setPreferredSize(new Dimension(36, 36));
        logoIcon.setLayout(new GridBagLayout());

        JLabel logoLetter = new JLabel("C");
        logoLetter.setFont(new Font(UIStyle.FONT_FAMILY, Font.BOLD, 18));
        logoLetter.setForeground(UIStyle.SIDEBAR_BG);
        logoIcon.add(logoLetter);

        JLabel logoText = new JLabel("CRS Portal");
        logoText.setFont(UIStyle.FONT_LOGO);
        logoText.setForeground(UIStyle.TEXT_WHITE);

        logoPanel.add(logoIcon);
        logoPanel.add(logoText);

        return logoPanel;
    }

    private JPanel createRoleBadge(User user) {
        JPanel badgePanel = new JPanel(new FlowLayout(FlowLayout.LEFT, UIStyle.PADDING_LG, 0));
        badgePanel.setOpaque(false);
        badgePanel.setMaximumSize(new Dimension(UIStyle.SIDEBAR_WIDTH, 30));

        String roleName = PermissionService.getRoleDisplayName(user.getRole());
        JLabel roleBadge = new JLabel(roleName);
        roleBadge.setFont(UIStyle.FONT_SMALL);
        roleBadge.setForeground(new Color(200, 200, 255));
        roleBadge.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(255, 255, 255, 50), 1),
                BorderFactory.createEmptyBorder(2, 8, 2, 8)));

        badgePanel.add(roleBadge);
        return badgePanel;
    }

    private ImageIcon getIconForModule(Module module) {
        switch (module) {
            case DASHBOARD:
                return UIStyle.createDashboardIcon(UIStyle.ICON_SIZE, UIStyle.TEXT_WHITE);
            case MY_PROFILE:
            case USER_MANAGEMENT:
                return UIStyle.createUsersIcon(UIStyle.ICON_SIZE, UIStyle.TEXT_WHITE);
            case MY_ACADEMIC_REPORT:
            case ACADEMIC_REPORTS:
                return UIStyle.createReportsIcon(UIStyle.ICON_SIZE, UIStyle.TEXT_WHITE);
            case MY_RECOVERY_STATUS:
            case COURSE_RECOVERY:
                return UIStyle.createRecoveryIcon(UIStyle.ICON_SIZE, UIStyle.TEXT_WHITE);
            case MY_ELIGIBILITY:
            case ELIGIBILITY_CHECKER:
                return UIStyle.createEligibilityIcon(UIStyle.ICON_SIZE, UIStyle.TEXT_WHITE);
            case SETTINGS:
                return UIStyle.createSettingsIcon(UIStyle.ICON_SIZE, UIStyle.TEXT_WHITE);
            default:
                return UIStyle.createDashboardIcon(UIStyle.ICON_SIZE, UIStyle.TEXT_WHITE);
        }
    }

    // ==================== NAVIGATION HANDLERS ====================

    private void handleModuleClick(Module module) {
        // Use NavigationService for permission-checked navigation
        if (!PermissionService.hasAccess(currentUser, module)) {
            showAccessDenied(module);
            return;
        }

        System.out.println("[CLICK] " + currentUser.getName() + " -> " + module.getDisplayName());

        switch (module) {
            case DASHBOARD:
                refreshDashboard();
                break;
            case MY_PROFILE:
                showMyProfile();
                break;
            case MY_ACADEMIC_REPORT:
            case ACADEMIC_REPORTS:
                onReport.run();
                break;
            case MY_RECOVERY_STATUS:
            case COURSE_RECOVERY:
                // Double-check: Course Admin should NOT reach here
                if (currentUser.getRole() == User.Role.COURSE_ADMIN) {
                    showAccessDenied(module);
                    return;
                }
                onCourseRecovery.run();
                break;
            case MY_ELIGIBILITY:
            case ELIGIBILITY_CHECKER:
                onEligibility.run();
                break;
            case USER_MANAGEMENT:
                onUserManagement.run();
                break;
            case SETTINGS:
                showSettings();
                break;
            default:
                break;
        }
    }

    private void handleLogoutClick() {
        if (UIStyle.showConfirm(this, "Confirm Logout", "Are you sure you want to logout?")) {
            onLogout.run();
        }
    }

    private void showAccessDenied(Module module) {
        UIStyle.showError(this, "Access Denied", PermissionService.getAccessDeniedMessage(module));
    }

    private void refreshDashboard() {
        removeAll();
        add(buildDashboardForRole(currentUser));
        revalidate();
        repaint();
    }

    private void showMyProfile() {
        UIStyle.showInfo(this, "My Profile",
                "Profile:\n\n" +
                        "Name: " + currentUser.getName() + "\n" +
                        "Email: " + currentUser.getEmail() + "\n" +
                        "Role: " + PermissionService.getRoleDisplayName(currentUser.getRole()));
    }

    private void showSettings() {
        UIStyle.showInfo(this, "Settings",
                "System Settings\n\n" +
                        "Settings panel coming soon.\n\n" +
                        "This area is for authorized administrators only.");
    }

    // ==================== MAIN CONTENT BUILDER ====================

    private JPanel buildMainContent(User user, List<Module> cardModules) {
        JPanel mainContent = new JPanel(new BorderLayout());
        mainContent.setBackground(UIStyle.BACKGROUND);

        JPanel contentWrapper = new JPanel();
        contentWrapper.setLayout(new BoxLayout(contentWrapper, BoxLayout.Y_AXIS));
        contentWrapper.setBackground(UIStyle.BACKGROUND);
        contentWrapper.setBorder(BorderFactory.createEmptyBorder(
                UIStyle.PADDING_XL, UIStyle.PADDING_XL, UIStyle.PADDING_LG, UIStyle.PADDING_XL));

        // Greeting section
        contentWrapper.add(createGreetingSection(user));
        contentWrapper.add(Box.createRigidArea(new Dimension(0, UIStyle.PADDING_LG)));

        // Metrics section (role-specific)
        contentWrapper.add(createMetricsSection(user));
        contentWrapper.add(Box.createRigidArea(new Dimension(0, UIStyle.PADDING_LG)));

        // Module cards section (role-specific)
        contentWrapper.add(createModuleCardsSection(user, cardModules));
        contentWrapper.add(Box.createVerticalGlue());

        JScrollPane scrollPane = new JScrollPane(contentWrapper);
        scrollPane.setBorder(null);
        scrollPane.getVerticalScrollBar().setUnitIncrement(16);

        mainContent.add(scrollPane, BorderLayout.CENTER);
        mainContent.add(UIStyle.createFooter(), BorderLayout.SOUTH);

        return mainContent;
    }

    private JPanel createGreetingSection(User user) {
        JPanel section = new JPanel();
        section.setLayout(new BoxLayout(section, BoxLayout.Y_AXIS));
        section.setOpaque(false);
        section.setAlignmentX(Component.LEFT_ALIGNMENT);
        section.setMaximumSize(new Dimension(Integer.MAX_VALUE, 100));

        JLabel greetingLabel = new JLabel(UIStyle.getGreeting());
        greetingLabel.setFont(UIStyle.FONT_SMALL);
        greetingLabel.setForeground(UIStyle.TEXT_SECONDARY);
        greetingLabel.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel nameLabel = new JLabel("Welcome, " + user.getName() + "!");
        nameLabel.setFont(UIStyle.FONT_TITLE);
        nameLabel.setForeground(UIStyle.TEXT_PRIMARY);
        nameLabel.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel subtitleLabel = new JLabel(getSubtitleForRole(user.getRole()));
        subtitleLabel.setFont(UIStyle.FONT_SMALL);
        subtitleLabel.setForeground(UIStyle.TEXT_SECONDARY);
        subtitleLabel.setAlignmentX(Component.LEFT_ALIGNMENT);

        section.add(greetingLabel);
        section.add(Box.createRigidArea(new Dimension(0, 4)));
        section.add(nameLabel);
        section.add(Box.createRigidArea(new Dimension(0, 4)));
        section.add(subtitleLabel);

        return section;
    }

    private String getSubtitleForRole(User.Role role) {
        switch (role) {
            case STUDENT:
                return "View your academic progress and recovery status.";
            case COURSE_ADMIN:
                return "Manage users, view reports, and check eligibility.";
            case ACADEMIC_OFFICER:
                return "Full access: Manage recovery plans, eligibility, and reports.";
            default:
                return "Here is your system overview.";
        }
    }

    private JPanel createMetricsSection(User user) {
        JPanel section = new JPanel();
        section.setOpaque(false);
        section.setLayout(new BoxLayout(section, BoxLayout.Y_AXIS));
        section.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel sectionTitle = new JLabel(getMetricsTitleForRole(user.getRole()));
        sectionTitle.setFont(UIStyle.FONT_SUBTITLE);
        sectionTitle.setForeground(UIStyle.TEXT_PRIMARY);
        sectionTitle.setAlignmentX(Component.LEFT_ALIGNMENT);
        section.add(sectionTitle);
        section.add(Box.createRigidArea(new Dimension(0, UIStyle.PADDING_MD)));

        JPanel metricsPanel = createMetricsForRole(user);
        section.add(metricsPanel);

        return section;
    }

    private String getMetricsTitleForRole(User.Role role) {
        switch (role) {
            case STUDENT:
                return "Your Academic Status";
            case COURSE_ADMIN:
                return "System Overview";
            case ACADEMIC_OFFICER:
                return "Recovery Management Overview";
            default:
                return "Overview";
        }
    }

    private JPanel createMetricsForRole(User user) {
        switch (user.getRole()) {
            case STUDENT:
                return createStudentMetrics();
            case COURSE_ADMIN:
                return createAdminMetrics();
            case ACADEMIC_OFFICER:
                return createOfficerMetrics();
            default:
                return new JPanel();
        }
    }

    private JPanel createStudentMetrics() {
        JPanel grid = new JPanel(new GridLayout(1, 4, UIStyle.PADDING_MD, 0));
        grid.setOpaque(false);
        grid.setMaximumSize(new Dimension(Integer.MAX_VALUE, UIStyle.METRIC_CARD_HEIGHT));
        grid.setAlignmentX(Component.LEFT_ALIGNMENT);

        grid.add(UIStyle.createMetricCard("Current CGPA", "3.25",
                UIStyle.createReportsIcon(20, UIStyle.TEXT_WHITE), UIStyle.SUCCESS));
        grid.add(UIStyle.createMetricCard("Enrolled Courses", "6",
                UIStyle.createReportsIcon(20, UIStyle.TEXT_WHITE), UIStyle.INFO));
        grid.add(UIStyle.createMetricCard("At Risk", "1",
                UIStyle.createWarningIcon(20, UIStyle.TEXT_WHITE), UIStyle.WARNING));
        grid.add(UIStyle.createMetricCard("Recovery Plans", "1",
                UIStyle.createRecoveryIcon(20, UIStyle.TEXT_WHITE), UIStyle.ACCENT));

        return grid;
    }

    private JPanel createAdminMetrics() {
        JPanel grid = new JPanel(new GridLayout(1, 4, UIStyle.PADDING_MD, 0));
        grid.setOpaque(false);
        grid.setMaximumSize(new Dimension(Integer.MAX_VALUE, UIStyle.METRIC_CARD_HEIGHT));
        grid.setAlignmentX(Component.LEFT_ALIGNMENT);

        int totalUsers = userService != null ? userService.getAllUsers().size() : 0;
        int totalStudents = studentService != null ? studentService.getAll().size() : 0;

        grid.add(UIStyle.createMetricCard("Total Users", String.valueOf(totalUsers),
                UIStyle.createUsersIcon(20, UIStyle.TEXT_WHITE), UIStyle.PRIMARY));
        grid.add(UIStyle.createMetricCard("Total Students", String.valueOf(totalStudents),
                UIStyle.createUsersIcon(20, UIStyle.TEXT_WHITE), UIStyle.INFO));
        grid.add(UIStyle.createMetricCard("Active Sessions", "1",
                UIStyle.createDashboardIcon(20, UIStyle.TEXT_WHITE), UIStyle.SUCCESS));
        grid.add(UIStyle.createMetricCard("System Status", "OK",
                UIStyle.createSettingsIcon(20, UIStyle.TEXT_WHITE), UIStyle.SUCCESS));

        return grid;
    }

    private JPanel createOfficerMetrics() {
        JPanel grid = new JPanel(new GridLayout(1, 4, UIStyle.PADDING_MD, 0));
        grid.setOpaque(false);
        grid.setMaximumSize(new Dimension(Integer.MAX_VALUE, UIStyle.METRIC_CARD_HEIGHT));
        grid.setAlignmentX(Component.LEFT_ALIGNMENT);

        int atRiskCount = 0, failedCount = 0, pendingPlans = 0, totalStudents = 0;

        if (studentService != null) {
            for (var student : studentService.getAll()) {
                totalStudents++;
                var components = student.getComponents();
                int failed = 0;
                double totalScore = 0;
                for (var comp : components) {
                    if (!comp.isPassed())
                        failed++;
                    totalScore += comp.getScore();
                }
                double avg = components.isEmpty() ? 0 : totalScore / components.size();

                if (avg < 2.0 || failed > 3)
                    failedCount++;
                else if (avg <= 2.2 || failed == 3)
                    atRiskCount++;

                if (failed > 0)
                    pendingPlans++;
            }
        }

        grid.add(UIStyle.createMetricCard("At Risk", String.valueOf(atRiskCount),
                UIStyle.createWarningIcon(20, UIStyle.TEXT_WHITE), UIStyle.WARNING));
        grid.add(UIStyle.createMetricCard("Failed", String.valueOf(failedCount),
                UIStyle.createEligibilityIcon(20, UIStyle.TEXT_WHITE), UIStyle.DANGER));
        grid.add(UIStyle.createMetricCard("Pending Plans", String.valueOf(pendingPlans),
                UIStyle.createPendingIcon(20, UIStyle.TEXT_WHITE), UIStyle.INFO));
        grid.add(UIStyle.createMetricCard("Total Students", String.valueOf(totalStudents),
                UIStyle.createUsersIcon(20, UIStyle.TEXT_WHITE), UIStyle.SUCCESS));

        return grid;
    }

    private JPanel createModuleCardsSection(User user, List<Module> cardModules) {
        JPanel section = new JPanel();
        section.setOpaque(false);
        section.setLayout(new BoxLayout(section, BoxLayout.Y_AXIS));
        section.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel sectionTitle = new JLabel("Available Modules");
        sectionTitle.setFont(UIStyle.FONT_SUBTITLE);
        sectionTitle.setForeground(UIStyle.TEXT_PRIMARY);
        sectionTitle.setAlignmentX(Component.LEFT_ALIGNMENT);
        section.add(sectionTitle);
        section.add(Box.createRigidArea(new Dimension(0, UIStyle.PADDING_MD)));

        // Create grid based on number of cards
        int cols = Math.min(cardModules.size(), 2);
        int rows = (int) Math.ceil(cardModules.size() / 2.0);
        if (rows == 0)
            rows = 1;
        if (cols == 0)
            cols = 1;

        JPanel cardsGrid = new JPanel(new GridLayout(rows, cols, UIStyle.PADDING_MD, UIStyle.PADDING_MD));
        cardsGrid.setOpaque(false);
        cardsGrid.setMaximumSize(new Dimension(Integer.MAX_VALUE,
                UIStyle.MODULE_CARD_HEIGHT * rows + UIStyle.PADDING_MD * (rows - 1)));
        cardsGrid.setAlignmentX(Component.LEFT_ALIGNMENT);

        for (Module module : cardModules) {
            cardsGrid.add(createModuleCard(module));
        }

        section.add(cardsGrid);
        return section;
    }

    private JPanel createModuleCard(Module module) {
        String description = getModuleDescription(module);
        Color color = getModuleColor(module);
        ImageIcon icon = getIconForModule(module);

        return UIStyle.createModuleCard(
                module.getDisplayName(),
                description,
                icon,
                color,
                () -> handleModuleClick(module));
    }

    private String getModuleDescription(Module module) {
        switch (module) {
            case MY_PROFILE:
                return "View and update your personal information";
            case MY_ACADEMIC_REPORT:
                return "View your grades and academic performance";
            case MY_RECOVERY_STATUS:
                return "Check your course recovery plan status";
            case MY_ELIGIBILITY:
                return "View your progression eligibility result";
            case COURSE_RECOVERY:
                return "Create and manage student recovery plans";
            case ELIGIBILITY_CHECKER:
                return "Check student eligibility for progression";
            case ACADEMIC_REPORTS:
                return "Generate and view student performance reports";
            case USER_MANAGEMENT:
                return "Add, update, and manage user accounts";
            case SETTINGS:
                return "Configure system settings and preferences";
            default:
                return "Access this module";
        }
    }

    private Color getModuleColor(Module module) {
        switch (module) {
            case MY_PROFILE:
            case USER_MANAGEMENT:
                return UIStyle.ACCENT;
            case MY_ACADEMIC_REPORT:
            case ACADEMIC_REPORTS:
                return UIStyle.WARNING;
            case MY_RECOVERY_STATUS:
            case COURSE_RECOVERY:
                return UIStyle.PRIMARY;
            case MY_ELIGIBILITY:
            case ELIGIBILITY_CHECKER:
                return UIStyle.SUCCESS;
            case SETTINGS:
                return UIStyle.TEXT_SECONDARY;
            default:
                return UIStyle.PRIMARY;
        }
    }
}
