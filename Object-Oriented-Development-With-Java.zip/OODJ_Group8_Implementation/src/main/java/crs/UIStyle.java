/*
 * UIStyle - Premium Sidebar Dashboard Theme
 * Complete styling system for modern sidebar-based UI
 * Version 3.0 - Sidebar Edition
 */
package crs;

import javax.swing.*;
import javax.swing.border.*;
import javax.swing.table.*;
import java.awt.*;
import java.awt.geom.*;
import java.awt.image.BufferedImage;
import java.time.LocalTime;

/**
 * Premium UI Style System for CRS Dashboard
 */
public final class UIStyle {

    // ==================== COLOR PALETTE ====================

    // Sidebar Colors
    public static final Color SIDEBAR_BG = new Color(78, 73, 233); // #4E49E9 Indigo
    public static final Color SIDEBAR_HOVER = new Color(92, 107, 192); // #5C6BC0
    public static final Color SIDEBAR_ACTIVE = new Color(255, 255, 255, 25); // Translucent white

    // Primary Colors
    public static final Color PRIMARY = new Color(78, 73, 233); // #4E49E9
    public static final Color PRIMARY_DARK = new Color(63, 81, 181); // #3F51B5
    public static final Color PRIMARY_LIGHT = new Color(121, 134, 203); // #7986CB

    // Accent Colors
    public static final Color ACCENT = new Color(92, 107, 192); // #5C6BC0
    public static final Color ACCENT_CYAN = new Color(38, 198, 218); // #26C6DA
    public static final Color ACCENT_TEAL = new Color(0, 150, 136); // #009688

    // Status Colors
    public static final Color SUCCESS = new Color(76, 175, 80); // #4CAF50
    public static final Color WARNING = new Color(255, 152, 0); // #FF9800
    public static final Color DANGER = new Color(244, 67, 54); // #F44336
    public static final Color INFO = new Color(33, 150, 243); // #2196F3

    // Background Colors
    public static final Color BACKGROUND = new Color(246, 247, 251); // #F6F7FB
    public static final Color CARD_BG = Color.WHITE;
    public static final Color BORDER = new Color(224, 224, 224); // #E0E0E0
    public static final Color DIVIDER = new Color(238, 238, 238); // #EEEEEE

    // Text Colors
    public static final Color TEXT_PRIMARY = new Color(33, 33, 33); // #212121
    public static final Color TEXT_SECONDARY = new Color(102, 102, 102); // #666666
    public static final Color TEXT_MUTED = new Color(158, 158, 158); // #9E9E9E
    public static final Color TEXT_WHITE = Color.WHITE;

    // Shadow
    public static final Color SHADOW = new Color(0, 0, 0, 15);

    // Backward compatibility aliases
    public static final Color BORDER_LIGHT = BORDER;
    public static final Color TABLE_ROW_ALT = BACKGROUND;
    public static final int CARD_GAP = 12;

    // ==================== FONTS ====================

    public static final String FONT_FAMILY = "Segoe UI";
    public static final String FONT_FALLBACK = "SansSerif";

    public static final Font FONT_LOGO = createFont(22, Font.BOLD);
    public static final Font FONT_TITLE = createFont(22, Font.BOLD);
    public static final Font FONT_SUBTITLE = createFont(18, Font.BOLD);
    public static final Font FONT_SECTION = createFont(16, Font.BOLD);
    public static final Font FONT_BODY = createFont(14, Font.PLAIN);
    public static final Font FONT_BODY_BOLD = createFont(14, Font.BOLD);
    public static final Font FONT_SMALL = createFont(13, Font.PLAIN);
    public static final Font FONT_SIDEBAR = createFont(15, Font.PLAIN);
    public static final Font FONT_SIDEBAR_BOLD = createFont(15, Font.BOLD);
    public static final Font FONT_METRIC = createFont(28, Font.BOLD);
    public static final Font FONT_FOOTER = createFont(12, Font.PLAIN);
    public static final Font FONT_BUTTON = createFont(13, Font.BOLD);

    // ==================== DIMENSIONS ====================

    public static final int SIDEBAR_WIDTH = 240;
    public static final int SIDEBAR_ITEM_HEIGHT = 48;
    public static final int CARD_RADIUS = 12;
    public static final int ICON_SIZE = 22;
    public static final int METRIC_CARD_HEIGHT = 100;
    public static final int MODULE_CARD_HEIGHT = 120;

    public static final int PADDING_XS = 4;
    public static final int PADDING_SM = 8;
    public static final int PADDING_MD = 12;
    public static final int PADDING_LG = 20;
    public static final int PADDING_XL = 30;

    // ==================== INITIALIZATION ====================

    public static void applyGlobalTheme() {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            try {
                UIManager.setLookAndFeel(UIManager.getCrossPlatformLookAndFeelClassName());
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }

        UIManager.put("Panel.background", BACKGROUND);
        UIManager.put("OptionPane.background", CARD_BG);
        UIManager.put("OptionPane.messageFont", FONT_BODY);
        UIManager.put("Button.font", FONT_BUTTON);
        UIManager.put("Label.font", FONT_BODY);
    }

    // ==================== FONT HELPERS ====================

    private static Font createFont(int size, int style) {
        Font font = new Font(FONT_FAMILY, style, size);
        if (!font.getFamily().equalsIgnoreCase(FONT_FAMILY)) {
            font = new Font(FONT_FALLBACK, style, size);
        }
        return font;
    }

    // ==================== GREETING HELPER ====================

    public static String getGreeting() {
        int hour = LocalTime.now().getHour();
        if (hour < 12)
            return "Good Morning";
        if (hour < 17)
            return "Good Afternoon";
        return "Good Evening";
    }

    // ==================== ICON GENERATION ====================

    /** Dashboard icon - 4 squares grid */
    public static ImageIcon createDashboardIcon(int size, Color color) {
        BufferedImage img = new BufferedImage(size, size, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2 = img.createGraphics();
        setupGraphics(g2);
        g2.setColor(color);

        int box = size / 2 - 3;
        int gap = 2;
        g2.fillRoundRect(1, 1, box, box, 3, 3);
        g2.fillRoundRect(size / 2 + gap, 1, box, box, 3, 3);
        g2.fillRoundRect(1, size / 2 + gap, box, box, 3, 3);
        g2.fillRoundRect(size / 2 + gap, size / 2 + gap, box, box, 3, 3);

        g2.dispose();
        return new ImageIcon(img);
    }

    /** Recovery icon - circular arrows */
    public static ImageIcon createRecoveryIcon(int size, Color color) {
        BufferedImage img = new BufferedImage(size, size, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2 = img.createGraphics();
        setupGraphics(g2);
        g2.setColor(color);
        g2.setStroke(new BasicStroke(2.5f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));

        int margin = 3;
        g2.drawArc(margin, margin, size - margin * 2, size - margin * 2, 45, 270);

        // Arrow
        int ax = size / 2 + 5, ay = margin + 1;
        g2.fillPolygon(new int[] { ax, ax - 4, ax + 2 }, new int[] { ay, ay + 5, ay + 5 }, 3);

        g2.dispose();
        return new ImageIcon(img);
    }

    /** Users icon - person silhouette */
    public static ImageIcon createUsersIcon(int size, Color color) {
        BufferedImage img = new BufferedImage(size, size, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2 = img.createGraphics();
        setupGraphics(g2);
        g2.setColor(color);

        int headR = size / 4;
        g2.fillOval(size / 2 - headR, 2, headR * 2, headR * 2);
        g2.fillArc(size / 4, size / 2 - 2, size / 2, size / 2 + 2, 0, 180);

        g2.dispose();
        return new ImageIcon(img);
    }

    /** Reports icon - bar chart */
    public static ImageIcon createReportsIcon(int size, Color color) {
        BufferedImage img = new BufferedImage(size, size, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2 = img.createGraphics();
        setupGraphics(g2);
        g2.setColor(color);

        int barW = size / 5;
        int[] heights = { (int) (size * 0.5), (int) (size * 0.8), (int) (size * 0.6) };
        for (int i = 0; i < 3; i++) {
            int x = 2 + i * (barW + 2);
            int h = heights[i];
            g2.fillRoundRect(x, size - h - 2, barW, h, 2, 2);
        }

        g2.dispose();
        return new ImageIcon(img);
    }

    /** Eligibility icon - check badge */
    public static ImageIcon createEligibilityIcon(int size, Color color) {
        BufferedImage img = new BufferedImage(size, size, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2 = img.createGraphics();
        setupGraphics(g2);

        g2.setColor(color);
        g2.fillOval(2, 2, size - 4, size - 4);

        g2.setColor(Color.WHITE);
        g2.setStroke(new BasicStroke(2.5f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
        int cx = size / 2, cy = size / 2;
        g2.drawLine(cx - 4, cy, cx - 1, cy + 4);
        g2.drawLine(cx - 1, cy + 4, cx + 5, cy - 3);

        g2.dispose();
        return new ImageIcon(img);
    }

    /** Settings icon - gear */
    public static ImageIcon createSettingsIcon(int size, Color color) {
        BufferedImage img = new BufferedImage(size, size, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2 = img.createGraphics();
        setupGraphics(g2);
        g2.setColor(color);

        int cx = size / 2, cy = size / 2;
        g2.setStroke(new BasicStroke(2f));
        g2.drawOval(cx - 4, cy - 4, 8, 8);

        for (int i = 0; i < 8; i++) {
            double angle = i * Math.PI / 4;
            int x1 = (int) (cx + 5 * Math.cos(angle));
            int y1 = (int) (cy + 5 * Math.sin(angle));
            int x2 = (int) (cx + 8 * Math.cos(angle));
            int y2 = (int) (cy + 8 * Math.sin(angle));
            g2.drawLine(x1, y1, x2, y2);
        }

        g2.dispose();
        return new ImageIcon(img);
    }

    /** Logout icon - door with arrow */
    public static ImageIcon createLogoutIcon(int size, Color color) {
        BufferedImage img = new BufferedImage(size, size, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2 = img.createGraphics();
        setupGraphics(g2);
        g2.setColor(color);
        g2.setStroke(new BasicStroke(2f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));

        // Door frame
        g2.drawLine(size / 2, 3, size / 2, size - 3);
        g2.drawLine(size / 2, 3, size - 3, 3);
        g2.drawLine(size / 2, size - 3, size - 3, size - 3);
        g2.drawLine(size - 3, 3, size - 3, size - 3);

        // Arrow
        g2.drawLine(3, size / 2, size / 2 - 2, size / 2);
        g2.drawLine(3, size / 2, 7, size / 2 - 4);
        g2.drawLine(3, size / 2, 7, size / 2 + 4);

        g2.dispose();
        return new ImageIcon(img);
    }

    /** Warning/Alert icon */
    public static ImageIcon createWarningIcon(int size, Color color) {
        BufferedImage img = new BufferedImage(size, size, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2 = img.createGraphics();
        setupGraphics(g2);
        g2.setColor(color);

        int[] xPoints = { size / 2, 2, size - 2 };
        int[] yPoints = { 2, size - 2, size - 2 };
        g2.fillPolygon(xPoints, yPoints, 3);

        g2.setColor(Color.WHITE);
        g2.setStroke(new BasicStroke(2f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
        g2.drawLine(size / 2, 7, size / 2, 13);
        g2.fillOval(size / 2 - 1, 15, 3, 3);

        g2.dispose();
        return new ImageIcon(img);
    }

    /** Pending/Clock icon */
    public static ImageIcon createPendingIcon(int size, Color color) {
        BufferedImage img = new BufferedImage(size, size, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2 = img.createGraphics();
        setupGraphics(g2);
        g2.setColor(color);
        g2.setStroke(new BasicStroke(2f));

        g2.drawOval(2, 2, size - 4, size - 4);
        int cx = size / 2, cy = size / 2;
        g2.drawLine(cx, cy, cx, cy - 4);
        g2.drawLine(cx, cy, cx + 3, cy + 2);

        g2.dispose();
        return new ImageIcon(img);
    }

    /** Document icon */
    public static ImageIcon createDocumentIcon(int size, Color color) {
        BufferedImage img = new BufferedImage(size, size, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2 = img.createGraphics();
        setupGraphics(g2);
        g2.setColor(color);

        g2.fillRoundRect(3, 1, size - 6, size - 2, 3, 3);

        g2.setColor(Color.WHITE);
        g2.setStroke(new BasicStroke(1.5f));
        for (int i = 0; i < 3; i++) {
            g2.drawLine(6, 6 + i * 4, size - 6, 6 + i * 4);
        }

        g2.dispose();
        return new ImageIcon(img);
    }

    private static void setupGraphics(Graphics2D g2) {
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2.setRenderingHint(RenderingHints.KEY_STROKE_CONTROL, RenderingHints.VALUE_STROKE_PURE);
    }

    // ==================== CARD FACTORIES ====================

    /** Create a metric card (small info card) */
    public static JPanel createMetricCard(String title, String value, ImageIcon icon, Color iconBg) {
        JPanel card = new JPanel() {
            private boolean hovered = false;
            {
                setOpaque(false);
                addMouseListener(new java.awt.event.MouseAdapter() {
                    public void mouseEntered(java.awt.event.MouseEvent e) {
                        hovered = true;
                        repaint();
                    }

                    public void mouseExited(java.awt.event.MouseEvent e) {
                        hovered = false;
                        repaint();
                    }
                });
            }

            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                setupGraphics(g2);

                // Shadow
                int shadowY = hovered ? 6 : 3;
                for (int i = 4; i >= 0; i--) {
                    g2.setColor(new Color(0, 0, 0, 10 - i * 2));
                    g2.fillRoundRect(i, i + shadowY, getWidth() - i * 2, getHeight() - i * 2 - shadowY, CARD_RADIUS,
                            CARD_RADIUS);
                }

                // Card
                g2.setColor(CARD_BG);
                g2.fillRoundRect(0, 0, getWidth() - 4, getHeight() - 6, CARD_RADIUS, CARD_RADIUS);
                g2.setColor(BORDER);
                g2.drawRoundRect(0, 0, getWidth() - 5, getHeight() - 7, CARD_RADIUS, CARD_RADIUS);

                g2.dispose();
            }
        };
        card.setLayout(new BorderLayout(PADDING_MD, 0));
        card.setBorder(BorderFactory.createEmptyBorder(PADDING_LG, PADDING_LG, PADDING_LG, PADDING_LG));
        card.setPreferredSize(new Dimension(0, METRIC_CARD_HEIGHT));

        // Icon panel
        JPanel iconPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                setupGraphics(g2);
                g2.setColor(iconBg);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 10, 10);
                g2.dispose();
            }
        };
        iconPanel.setOpaque(false);
        iconPanel.setPreferredSize(new Dimension(50, 50));
        iconPanel.setLayout(new GridBagLayout());
        iconPanel.add(new JLabel(icon));

        // Text panel
        JPanel textPanel = new JPanel();
        textPanel.setOpaque(false);
        textPanel.setLayout(new BoxLayout(textPanel, BoxLayout.Y_AXIS));

        JLabel valueLabel = new JLabel(value);
        valueLabel.setFont(FONT_METRIC);
        valueLabel.setForeground(TEXT_PRIMARY);

        JLabel titleLabel = new JLabel(title);
        titleLabel.setFont(FONT_SMALL);
        titleLabel.setForeground(TEXT_SECONDARY);

        textPanel.add(valueLabel);
        textPanel.add(Box.createRigidArea(new Dimension(0, 2)));
        textPanel.add(titleLabel);

        card.add(iconPanel, BorderLayout.WEST);
        card.add(textPanel, BorderLayout.CENTER);

        return card;
    }

    /** Create a module card (large feature card) */
    public static JPanel createModuleCard(String title, String description, ImageIcon icon, Color iconBg,
            Runnable onClick) {
        JPanel card = new JPanel() {
            private boolean hovered = false;
            {
                setOpaque(false);
                setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
                addMouseListener(new java.awt.event.MouseAdapter() {
                    public void mouseEntered(java.awt.event.MouseEvent e) {
                        hovered = true;
                        repaint();
                    }

                    public void mouseExited(java.awt.event.MouseEvent e) {
                        hovered = false;
                        repaint();
                    }

                    public void mouseClicked(java.awt.event.MouseEvent e) {
                        onClick.run();
                    }
                });
            }

            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                setupGraphics(g2);

                // Shadow
                int shadowY = hovered ? 8 : 4;
                for (int i = 5; i >= 0; i--) {
                    int alpha = hovered ? (15 - i * 2) : (10 - i * 2);
                    if (alpha < 0)
                        alpha = 0;
                    g2.setColor(new Color(0, 0, 0, alpha));
                    g2.fillRoundRect(i, i + shadowY, getWidth() - i * 2, getHeight() - i * 2 - shadowY, CARD_RADIUS,
                            CARD_RADIUS);
                }

                // Card
                g2.setColor(hovered ? new Color(252, 252, 255) : CARD_BG);
                g2.fillRoundRect(0, 0, getWidth() - 5, getHeight() - 8, CARD_RADIUS, CARD_RADIUS);
                g2.setColor(hovered ? PRIMARY_LIGHT : BORDER);
                g2.setStroke(new BasicStroke(hovered ? 1.5f : 1f));
                g2.drawRoundRect(0, 0, getWidth() - 6, getHeight() - 9, CARD_RADIUS, CARD_RADIUS);

                g2.dispose();
            }
        };
        card.setLayout(new BorderLayout(PADDING_MD, 0));
        card.setBorder(BorderFactory.createEmptyBorder(PADDING_LG, PADDING_LG, PADDING_LG, PADDING_LG));
        card.setPreferredSize(new Dimension(0, MODULE_CARD_HEIGHT));

        // Icon panel
        JPanel iconPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                setupGraphics(g2);
                g2.setColor(iconBg);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 10, 10);
                g2.dispose();
            }
        };
        iconPanel.setOpaque(false);
        iconPanel.setPreferredSize(new Dimension(56, 56));
        iconPanel.setLayout(new GridBagLayout());
        iconPanel.add(new JLabel(icon));

        // Text panel
        JPanel textPanel = new JPanel();
        textPanel.setOpaque(false);
        textPanel.setLayout(new BoxLayout(textPanel, BoxLayout.Y_AXIS));

        JLabel titleLabel = new JLabel(title);
        titleLabel.setFont(FONT_SECTION);
        titleLabel.setForeground(TEXT_PRIMARY);

        JLabel descLabel = new JLabel("<html><div style='width:180px'>" + description + "</div></html>");
        descLabel.setFont(FONT_SMALL);
        descLabel.setForeground(TEXT_SECONDARY);

        textPanel.add(titleLabel);
        textPanel.add(Box.createRigidArea(new Dimension(0, 4)));
        textPanel.add(descLabel);

        card.add(iconPanel, BorderLayout.WEST);
        card.add(textPanel, BorderLayout.CENTER);

        return card;
    }

    // ==================== SIDEBAR ITEM ====================

    /**
     * Create a sidebar navigation item - FIXED for long text like "Course Recovery
     * Management"
     */
    public static JPanel createSidebarItem(String text, ImageIcon icon, boolean isActive, Runnable onClick) {
        // Fixed height for all sidebar items
        final int ITEM_HEIGHT = 48;
        final int ICON_SIZE = 20;
        final int LEFT_PADDING = 18;
        final int ICON_TEXT_GAP = 12;

        JPanel item = new JPanel() {
            private boolean hovered = false;
            {
                setOpaque(false);
                setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
                addMouseListener(new java.awt.event.MouseAdapter() {
                    public void mouseEntered(java.awt.event.MouseEvent e) {
                        hovered = true;
                        repaint();
                    }

                    public void mouseExited(java.awt.event.MouseEvent e) {
                        hovered = false;
                        repaint();
                    }

                    public void mouseClicked(java.awt.event.MouseEvent e) {
                        if (onClick != null)
                            onClick.run();
                    }
                });
            }

            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                setupGraphics(g2);

                if (isActive || hovered) {
                    g2.setColor(isActive ? SIDEBAR_ACTIVE : new Color(255, 255, 255, 15));
                    g2.fillRoundRect(8, 2, getWidth() - 16, getHeight() - 4, 8, 8);
                }

                g2.dispose();
            }
        };

        // Use BorderLayout for proper icon + text alignment
        item.setLayout(new BorderLayout());
        item.setPreferredSize(new Dimension(SIDEBAR_WIDTH, ITEM_HEIGHT));
        item.setMaximumSize(new Dimension(SIDEBAR_WIDTH, ITEM_HEIGHT));
        item.setMinimumSize(new Dimension(SIDEBAR_WIDTH, ITEM_HEIGHT));
        item.setBorder(BorderFactory.createEmptyBorder(0, LEFT_PADDING, 0, PADDING_SM));

        // Icon panel - fixed width
        JPanel iconPanel = new JPanel(new GridBagLayout());
        iconPanel.setOpaque(false);
        iconPanel.setPreferredSize(new Dimension(ICON_SIZE + ICON_TEXT_GAP, ITEM_HEIGHT));

        // Scale icon if needed
        JLabel iconLabel = new JLabel();
        if (icon != null) {
            Image scaledIcon = icon.getImage().getScaledInstance(ICON_SIZE, ICON_SIZE, Image.SCALE_SMOOTH);
            iconLabel.setIcon(new ImageIcon(scaledIcon));
        }
        iconPanel.add(iconLabel);

        // Text label - uses remaining space, properly constrained
        JLabel textLabel = new JLabel(text);
        textLabel.setFont(isActive ? FONT_SIDEBAR_BOLD : FONT_SIDEBAR);
        textLabel.setForeground(TEXT_WHITE);
        textLabel.setHorizontalAlignment(SwingConstants.LEFT);
        textLabel.setVerticalAlignment(SwingConstants.CENTER);
        // Ensure text doesn't overflow - will truncate with ellipsis if too long
        textLabel.setPreferredSize(
                new Dimension(SIDEBAR_WIDTH - LEFT_PADDING - ICON_SIZE - ICON_TEXT_GAP - PADDING_SM, ITEM_HEIGHT));
        textLabel.setMaximumSize(
                new Dimension(SIDEBAR_WIDTH - LEFT_PADDING - ICON_SIZE - ICON_TEXT_GAP - PADDING_SM, ITEM_HEIGHT));

        item.add(iconPanel, BorderLayout.WEST);
        item.add(textLabel, BorderLayout.CENTER);

        return item;
    }

    // ==================== FOOTER ====================

    public static JPanel createFooter() {
        JPanel footer = new JPanel(new BorderLayout());
        footer.setBackground(BACKGROUND);
        footer.setBorder(BorderFactory.createEmptyBorder(0, PADDING_XL, PADDING_LG, PADDING_XL));

        // Divider
        JPanel divider = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                g.setColor(DIVIDER);
                g.fillRect(0, 0, getWidth(), 1);
            }
        };
        divider.setPreferredSize(new Dimension(0, 1));
        divider.setOpaque(false);

        JLabel footerText = new JLabel("(c) 2024 Course Recovery System  |  Version 1.0");
        footerText.setFont(FONT_FOOTER);
        footerText.setForeground(TEXT_MUTED);
        footerText.setHorizontalAlignment(SwingConstants.CENTER);
        footerText.setBorder(BorderFactory.createEmptyBorder(PADDING_MD, 0, 0, 0));

        footer.add(divider, BorderLayout.NORTH);
        footer.add(footerText, BorderLayout.CENTER);

        return footer;
    }

    // ==================== BUTTON FACTORIES ====================

    public static JButton createPrimaryButton(String text) {
        return createButton(text, PRIMARY, TEXT_WHITE);
    }

    public static JButton createSecondaryButton(String text) {
        return createButton(text, BORDER, TEXT_PRIMARY);
    }

    public static JButton createSuccessButton(String text) {
        return createButton(text, SUCCESS, TEXT_WHITE);
    }

    public static JButton createDangerButton(String text) {
        return createButton(text, DANGER, TEXT_WHITE);
    }

    private static JButton createButton(String text, Color bg, Color fg) {
        JButton button = new JButton(text) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                setupGraphics(g2);
                g2.setColor(getBackground());
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 8, 8);
                g2.dispose();
                super.paintComponent(g);
            }
        };
        button.setFont(FONT_BUTTON);
        button.setForeground(fg);
        button.setBackground(bg);
        button.setOpaque(false);
        button.setContentAreaFilled(false);
        button.setBorderPainted(false);
        button.setFocusPainted(false);
        button.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        button.setBorder(BorderFactory.createEmptyBorder(PADDING_SM, PADDING_LG, PADDING_SM, PADDING_LG));

        Color hover = bg.darker();
        button.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent e) {
                button.setBackground(hover);
            }

            public void mouseExited(java.awt.event.MouseEvent e) {
                button.setBackground(bg);
            }
        });

        return button;
    }

    // ==================== TEXT FIELD ====================

    public static JTextField createTextField() {
        JTextField field = new JTextField();
        field.setFont(FONT_BODY);
        field.setBorder(BorderFactory.createCompoundBorder(
                new RoundedBorder(BORDER, 1, 8),
                BorderFactory.createEmptyBorder(PADDING_SM, PADDING_MD, PADDING_SM, PADDING_MD)));
        field.setPreferredSize(new Dimension(0, 40));
        return field;
    }

    public static JPasswordField createPasswordField() {
        JPasswordField field = new JPasswordField();
        field.setFont(FONT_BODY);
        field.setBorder(BorderFactory.createCompoundBorder(
                new RoundedBorder(BORDER, 1, 8),
                BorderFactory.createEmptyBorder(PADDING_SM, PADDING_MD, PADDING_SM, PADDING_MD)));
        field.setPreferredSize(new Dimension(0, 40));
        return field;
    }

    public static <T> JComboBox<T> createComboBox(T[] items) {
        JComboBox<T> combo = new JComboBox<>(items);
        combo.setFont(FONT_BODY);
        combo.setBackground(CARD_BG);
        return combo;
    }

    // ==================== LABELS ====================

    public static JLabel createTitleLabel(String text) {
        JLabel label = new JLabel(text);
        label.setFont(FONT_TITLE);
        label.setForeground(TEXT_PRIMARY);
        return label;
    }

    public static JLabel createSubtitleLabel(String text) {
        JLabel label = new JLabel(text);
        label.setFont(FONT_SUBTITLE);
        label.setForeground(TEXT_PRIMARY);
        return label;
    }

    public static JLabel createSecondaryLabel(String text) {
        JLabel label = new JLabel(text);
        label.setFont(FONT_SMALL);
        label.setForeground(TEXT_SECONDARY);
        return label;
    }

    // ==================== TABLE STYLING ====================

    public static void styleTable(JTable table) {
        table.setFont(FONT_BODY);
        table.setRowHeight(36);
        table.setShowGrid(true);
        table.setGridColor(DIVIDER);
        table.setSelectionBackground(new Color(232, 234, 246));
        table.setSelectionForeground(TEXT_PRIMARY);
        table.setFillsViewportHeight(true);

        JTableHeader header = table.getTableHeader();
        header.setPreferredSize(new Dimension(0, 44));
        header.setDefaultRenderer(new DefaultTableCellRenderer() {
            {
                setHorizontalAlignment(CENTER);
                setOpaque(true);
            }

            @Override
            public Component getTableCellRendererComponent(JTable table, Object value,
                    boolean isSelected, boolean hasFocus, int row, int column) {
                setText(value != null ? value.toString() : "");
                setFont(FONT_BODY_BOLD);
                setBackground(PRIMARY);
                setForeground(TEXT_WHITE);
                setBorder(BorderFactory.createMatteBorder(0, 0, 1, 1, PRIMARY_LIGHT));
                return this;
            }
        });

        table.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable table, Object value,
                    boolean isSelected, boolean hasFocus, int row, int column) {
                super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
                setBackground(isSelected ? new Color(232, 234, 246) : (row % 2 == 0 ? CARD_BG : BACKGROUND));
                setForeground(TEXT_PRIMARY);
                setBorder(BorderFactory.createEmptyBorder(0, PADDING_SM, 0, PADDING_SM));
                return this;
            }
        });
    }

    // ==================== DIALOG HELPERS ====================

    public static void showInfo(Component parent, String title, String message) {
        JOptionPane.showMessageDialog(parent, message, title, JOptionPane.INFORMATION_MESSAGE);
    }

    public static void showSuccess(Component parent, String title, String message) {
        JOptionPane.showMessageDialog(parent, message, title, JOptionPane.INFORMATION_MESSAGE);
    }

    public static void showWarning(Component parent, String title, String message) {
        JOptionPane.showMessageDialog(parent, message, title, JOptionPane.WARNING_MESSAGE);
    }

    public static void showError(Component parent, String title, String message) {
        JOptionPane.showMessageDialog(parent, message, title, JOptionPane.ERROR_MESSAGE);
    }

    public static boolean showConfirm(Component parent, String title, String message) {
        return JOptionPane.showConfirmDialog(parent, message, title,
                JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION;
    }

    // ==================== ROUNDED BORDER ====================

    public static class RoundedBorder extends AbstractBorder {
        private Color color;
        private int thickness;
        private int radius;

        public RoundedBorder(Color color, int thickness, int radius) {
            this.color = color;
            this.thickness = thickness;
            this.radius = radius;
        }

        @Override
        public void paintBorder(Component c, Graphics g, int x, int y, int width, int height) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(color);
            g2.setStroke(new BasicStroke(thickness));
            g2.drawRoundRect(x, y, width - 1, height - 1, radius, radius);
            g2.dispose();
        }

        @Override
        public Insets getBorderInsets(Component c) {
            return new Insets(thickness, thickness, thickness, thickness);
        }
    }

    // ==================== BACKWARD COMPATIBILITY METHODS ====================

    /** Create a basic card panel */
    public static JPanel createCard() {
        JPanel card = new JPanel();
        card.setBackground(CARD_BG);
        card.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER, 1),
                BorderFactory.createEmptyBorder(PADDING_LG, PADDING_LG, PADDING_LG, PADDING_LG)));
        return card;
    }

    /** Create a simple label */
    public static JLabel createLabel(String text) {
        JLabel label = new JLabel(text);
        label.setFont(FONT_BODY);
        label.setForeground(TEXT_PRIMARY);
        return label;
    }

    /** Create an accent-colored button */
    public static JButton createAccentButton(String text) {
        return createButton(text, ACCENT, TEXT_WHITE);
    }

    /** Create a gradient panel with two colors */
    public static JPanel createGradientPanel(Color startColor, Color endColor) {
        return new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
                GradientPaint gradient = new GradientPaint(
                        0, 0, startColor,
                        getWidth(), getHeight(), endColor);
                g2.setPaint(gradient);
                g2.fillRect(0, 0, getWidth(), getHeight());
                g2.dispose();
            }
        };
    }

    /** Create a premium card with shadow and hover effects */
    public static JPanel createPremiumCard() {
        return new JPanel() {
            private boolean hovered = false;
            {
                setOpaque(false);
                setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
                addMouseListener(new java.awt.event.MouseAdapter() {
                    public void mouseEntered(java.awt.event.MouseEvent e) {
                        hovered = true;
                        repaint();
                    }

                    public void mouseExited(java.awt.event.MouseEvent e) {
                        hovered = false;
                        repaint();
                    }
                });
            }

            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                setupGraphics(g2);
                int shadowY = hovered ? 6 : 3;
                for (int i = 4; i >= 0; i--) {
                    int alpha = hovered ? (20 - i * 3) : (12 - i * 2);
                    if (alpha < 0)
                        alpha = 0;
                    g2.setColor(new Color(0, 0, 0, alpha));
                    g2.fillRoundRect(i, i + shadowY, getWidth() - i * 2, getHeight() - i * 2 - shadowY, CARD_RADIUS,
                            CARD_RADIUS);
                }
                g2.setColor(hovered ? new Color(252, 252, 255) : CARD_BG);
                g2.fillRoundRect(0, 0, getWidth() - 4, getHeight() - 6, CARD_RADIUS, CARD_RADIUS);
                g2.setColor(hovered ? PRIMARY_LIGHT : BORDER);
                g2.drawRoundRect(0, 0, getWidth() - 5, getHeight() - 7, CARD_RADIUS, CARD_RADIUS);
                g2.dispose();
            }
        };
    }

    /** Create an icon bar for card left side */
    public static JPanel createIconBar(Color bgColor, ImageIcon icon) {
        JPanel iconBar = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                setupGraphics(g2);
                g2.setColor(bgColor);
                g2.fillRoundRect(0, 0, getWidth() + 12, getHeight(), 12, 12);
                g2.fillRect(getWidth() - 12, 0, 12, getHeight());
                g2.dispose();
            }
        };
        iconBar.setOpaque(false);
        iconBar.setPreferredSize(new Dimension(48, 0));
        iconBar.setLayout(new GridBagLayout());
        if (icon != null) {
            iconBar.add(new JLabel(icon));
        }
        return iconBar;
    }

    /** Create a premium footer with divider line */
    public static JPanel createPremiumFooter(String text) {
        JPanel footer = new JPanel(new BorderLayout());
        footer.setBackground(BACKGROUND);
        footer.setBorder(BorderFactory.createEmptyBorder(0, PADDING_XL, PADDING_LG, PADDING_XL));

        JPanel divider = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                g.setColor(DIVIDER);
                g.fillRect(0, 0, getWidth(), 1);
            }
        };
        divider.setPreferredSize(new Dimension(0, 1));
        divider.setOpaque(false);

        JLabel footerLabel = new JLabel(text);
        footerLabel.setFont(FONT_FOOTER);
        footerLabel.setForeground(TEXT_MUTED);
        footerLabel.setHorizontalAlignment(SwingConstants.CENTER);
        footerLabel.setBorder(BorderFactory.createEmptyBorder(PADDING_MD, 0, 0, 0));

        footer.add(divider, BorderLayout.NORTH);
        footer.add(footerLabel, BorderLayout.CENTER);
        return footer;
    }

    /** Create a small rounded button */
    public static JButton createSmallRoundedButton(String text, Color bgColor) {
        JButton button = new JButton(text) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                setupGraphics(g2);
                g2.setColor(getBackground());
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 12, 12);
                g2.dispose();
                super.paintComponent(g);
            }
        };
        button.setFont(createFont(11, Font.BOLD));
        button.setForeground(TEXT_WHITE);
        button.setBackground(bgColor);
        button.setOpaque(false);
        button.setContentAreaFilled(false);
        button.setBorderPainted(false);
        button.setFocusPainted(false);
        button.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        button.setBorder(BorderFactory.createEmptyBorder(PADDING_SM, PADDING_MD, PADDING_SM, PADDING_MD));
        button.setPreferredSize(new Dimension(80, 32));

        Color hover = bgColor.darker();
        button.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent e) {
                button.setBackground(hover);
            }

            public void mouseExited(java.awt.event.MouseEvent e) {
                button.setBackground(bgColor);
            }
        });
        return button;
    }

    private UIStyle() {
    }
}
