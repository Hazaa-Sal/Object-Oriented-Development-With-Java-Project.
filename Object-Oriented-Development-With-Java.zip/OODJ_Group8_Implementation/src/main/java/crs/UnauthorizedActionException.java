/*
 * UnauthorizedActionException - Thrown when user lacks permission
 * Part of CRS Role-Based Access Control System
 */
package crs;

/**
 * Exception thrown when a user attempts to access a module or perform
 * an action they do not have permission for.
 */
public class UnauthorizedActionException extends RuntimeException {

    private final User user;
    private final String module;

    public UnauthorizedActionException(User user, String module) {
        super("User '" + (user != null ? user.getName() : "null") +
                "' does not have permission to access: " + module);
        this.user = user;
        this.module = module;
    }

    public UnauthorizedActionException(String message) {
        super(message);
        this.user = null;
        this.module = null;
    }

    public User getUser() {
        return user;
    }

    public String getModule() {
        return module;
    }
}
