/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package crs;

import java.time.LocalDateTime;

public class User {

    public enum Role {
        COURSE_ADMIN,
        ACADEMIC_OFFICER,
        STUDENT
    }

    private String userID;
    private String name;
    private String email;
    private String passwordHash;
    private Role role;
    private boolean active;
    private LocalDateTime lastLogin;
    private LocalDateTime lastLogout;

    public User(String userID, String name, String email, String passwordHash, Role role, boolean active) {
        this.userID = userID;
        this.name = name;
        this.email = email;
        this.passwordHash = passwordHash;
        this.role = role;
        this.active = active;
    }

    // Getters
    public String getUserID() { return userID; }
    public String getName() { return name; }
    public String getEmail() { return email; }
    public Role getRole() { return role; }
    public boolean isActive() { return active; }
    public LocalDateTime getLastLogin() { return lastLogin; }
    public LocalDateTime getLastLogout() { return lastLogout; }
    public String getPasswordHash() { return passwordHash; }

    // Setters
    public void setName(String name) { this.name = name; }
    public void setEmail(String email) { this.email = email; }
    public void setRole(Role role) { this.role = role; }
    public void setActive(boolean active) { this.active = active; }
    public void setPasswordHash(String hash) { this.passwordHash = hash; }

    // Password handling
    public boolean checkPassword(String password) {
        System.out.println("DEBUG >>> Checking password");
        System.out.println("DEBUG >>> Raw typed password = " + password);
        System.out.println("DEBUG >>> Stored hash       = " + passwordHash);
        System.out.println("DEBUG >>> Typed hash        = " + sha256(password));
        return passwordHash != null && passwordHash.equals(sha256(password));
    }

    public void resetPassword(String newPassword) {
        this.passwordHash = sha256(newPassword);
    }

    private String sha256(String input) {
        try {
            java.security.MessageDigest md = java.security.MessageDigest.getInstance("SHA-256");
            byte[] bytes = md.digest(input.getBytes("UTF-8"));
            StringBuilder sb = new StringBuilder();
            for (byte b : bytes) sb.append(String.format("%02x", b));
            return sb.toString();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public void login() {
        lastLogin = LocalDateTime.now();
        System.out.println(name + " logged in at " + lastLogin);
    }

    public void logout() {
        lastLogout = LocalDateTime.now();
        System.out.println(name + " logged out at " + lastLogout);
    }

    @Override
    public String toString() {
        return "User{" +
                "userID='" + userID + '\'' +
                ", name='" + name + '\'' +
                ", email='" + email + '\'' +
                ", role=" + role +
                ", active=" + active +
                '}';
    }
}

