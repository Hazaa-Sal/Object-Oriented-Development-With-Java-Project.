/*
 * UserManagementPanel - Modernized with UIStyle
 * Manage user accounts and permissions
 */
package crs;

import javax.swing.*;
import javax.swing.table.*;
import java.awt.*;
import java.util.Collection;

public class UserManagementPanel extends JPanel {
    private UserService userService;
    private EmailService emailService;
    private Runnable onBack;

    private JTable userTable;
    private DefaultTableModel tableModel;
    private JTextField searchField;

    public UserManagementPanel(UserService userService, EmailService emailService, Runnable onBack) {
        this.userService = userService;
        this.emailService = emailService;
        this.onBack = onBack;

        setLayout(new BorderLayout());
        setBackground(UIStyle.BACKGROUND);

        initializeComponents();
        loadUsers();
    }

    private void initializeComponents() {
        // Header
        add(createHeaderPanel(), BorderLayout.NORTH);

        // Main content (table)
        add(createTablePanel(), BorderLayout.CENTER);

        // Action buttons
        add(createActionPanel(), BorderLayout.SOUTH);
    }

    private JPanel createHeaderPanel() {
        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBackground(UIStyle.CARD_BG);
        headerPanel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(0, 0, 2, 0, UIStyle.BORDER_LIGHT),
                BorderFactory.createEmptyBorder(20, 30, 20, 30)));

        // Left: Title
        JPanel leftPanel = new JPanel();
        leftPanel.setLayout(new BoxLayout(leftPanel, BoxLayout.Y_AXIS));
        leftPanel.setBackground(UIStyle.CARD_BG);

        JLabel titleLabel = UIStyle.createTitleLabel("User Management");
        titleLabel.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel subtitleLabel = UIStyle.createLabel("Manage user accounts and permissions");
        subtitleLabel.setForeground(UIStyle.TEXT_SECONDARY);
        subtitleLabel.setAlignmentX(Component.LEFT_ALIGNMENT);

        leftPanel.add(titleLabel);
        leftPanel.add(Box.createRigidArea(new Dimension(0, 5)));
        leftPanel.add(subtitleLabel);

        // Center: Search
        JPanel centerPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        centerPanel.setBackground(UIStyle.CARD_BG);

        searchField = UIStyle.createTextField();
        searchField.setPreferredSize(new Dimension(250, 35));

        searchField.addActionListener(e -> filterUsers());

        JButton searchBtn = UIStyle.createPrimaryButton("Search");
        searchBtn.setPreferredSize(new Dimension(100, 35));
        searchBtn.addActionListener(e -> filterUsers());

        centerPanel.add(searchField);
        centerPanel.add(searchBtn);

        // Right: Back button
        JPanel rightPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        rightPanel.setBackground(UIStyle.CARD_BG);

        JButton backBtn = UIStyle.createSecondaryButton("Back");
        backBtn.setPreferredSize(new Dimension(100, 40));
        backBtn.addActionListener(e -> onBack.run());
        rightPanel.add(backBtn);

        headerPanel.add(leftPanel, BorderLayout.WEST);
        headerPanel.add(centerPanel, BorderLayout.CENTER);
        headerPanel.add(rightPanel, BorderLayout.EAST);

        return headerPanel;
    }

    private JPanel createTablePanel() {
        JPanel tablePanel = new JPanel(new BorderLayout());
        tablePanel.setBackground(UIStyle.CARD_BG);
        tablePanel.setBorder(BorderFactory.createEmptyBorder(20, 30, 20, 30));

        // Create table
        String[] columns = { "User ID", "Name", "Email", "Role", "Status" };
        tableModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; // Make table read-only
            }
        };

        userTable = new JTable(tableModel);

        // Apply UIStyle table styling
        UIStyle.styleTable(userTable);

        // Column widths
        userTable.getColumnModel().getColumn(0).setPreferredWidth(80);
        userTable.getColumnModel().getColumn(1).setPreferredWidth(150);
        userTable.getColumnModel().getColumn(2).setPreferredWidth(200);
        userTable.getColumnModel().getColumn(3).setPreferredWidth(120);
        userTable.getColumnModel().getColumn(4).setPreferredWidth(80);

        // Custom renderer for status column
        userTable.getColumnModel().getColumn(4).setCellRenderer(new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable table, Object value,
                    boolean isSelected, boolean hasFocus, int row, int column) {
                Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);

                if (value != null) {
                    String status = value.toString();
                    if ("Active".equals(status)) {
                        setForeground(UIStyle.SUCCESS);
                        setText("[+] Active");
                    } else {
                        setForeground(UIStyle.DANGER);
                        setText("[-] Inactive");
                    }
                    setFont(UIStyle.FONT_BODY_BOLD);
                }

                if (!isSelected) {
                    setBackground(row % 2 == 0 ? UIStyle.CARD_BG : UIStyle.TABLE_ROW_ALT);
                }

                return c;
            }
        });

        JScrollPane scrollPane = new JScrollPane(userTable);
        scrollPane.setBorder(BorderFactory.createLineBorder(UIStyle.BORDER_LIGHT));

        tablePanel.add(scrollPane, BorderLayout.CENTER);

        return tablePanel;
    }

    private JPanel createActionPanel() {
        JPanel actionPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 20));
        actionPanel.setBackground(UIStyle.BACKGROUND);

        JButton addBtn = UIStyle.createSuccessButton("Add User");
        addBtn.setPreferredSize(new Dimension(130, 45));
        addBtn.addActionListener(e -> showAddUserDialog());

        JButton editBtn = UIStyle.createAccentButton("Edit User");
        editBtn.setPreferredSize(new Dimension(130, 45));
        editBtn.addActionListener(e -> showEditUserDialog());

        JButton toggleBtn = UIStyle.createPrimaryButton("Toggle Status");
        toggleBtn.setPreferredSize(new Dimension(150, 45));
        toggleBtn.addActionListener(e -> toggleUserStatus());

        JButton resetPwBtn = UIStyle.createAccentButton("Reset Password");
        resetPwBtn.setPreferredSize(new Dimension(160, 45));
        resetPwBtn.addActionListener(e -> resetUserPassword());

        JButton refreshBtn = UIStyle.createSecondaryButton("Refresh");
        refreshBtn.setPreferredSize(new Dimension(120, 45));
        refreshBtn.addActionListener(e -> loadUsers());

        actionPanel.add(addBtn);
        actionPanel.add(editBtn);
        actionPanel.add(toggleBtn);
        actionPanel.add(resetPwBtn);
        actionPanel.add(refreshBtn);

        return actionPanel;
    }

    private void loadUsers() {
        tableModel.setRowCount(0); // Clear table

        Collection<User> users = userService.getAllUsers();
        for (User user : users) {
            Object[] row = {
                    user.getUserID(),
                    user.getName(),
                    user.getEmail(),
                    user.getRole().name(),
                    user.isActive() ? "Active" : "Inactive"
            };
            tableModel.addRow(row);
        }
    }

    private void filterUsers() {
        String searchTerm = searchField.getText().trim().toLowerCase();

        if (searchTerm.isEmpty()) {
            loadUsers();
            return;
        }

        tableModel.setRowCount(0);

        Collection<User> users = userService.getAllUsers();
        for (User user : users) {
            if (user.getName().toLowerCase().contains(searchTerm) ||
                    user.getEmail().toLowerCase().contains(searchTerm) ||
                    user.getUserID().toLowerCase().contains(searchTerm)) {

                Object[] row = {
                        user.getUserID(),
                        user.getName(),
                        user.getEmail(),
                        user.getRole().name(),
                        user.isActive() ? "Active" : "Inactive"
                };
                tableModel.addRow(row);
            }
        }
    }

private void showAddUserDialog() {
    // Create the dialog
    Window parentWindow = SwingUtilities.getWindowAncestor(this);
    JDialog dialog = parentWindow instanceof Frame ? 
        new JDialog((Frame) parentWindow, "Add New User", true) :
        new JDialog((Dialog) parentWindow, "Add New User", true);
    dialog.setSize(500, 550);
    dialog.setLocationRelativeTo(this);

    // Main panel
    JPanel mainPanel = new JPanel();
    mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));
    mainPanel.setBorder(BorderFactory.createEmptyBorder(25, 30, 25, 30));
    mainPanel.setBackground(UIStyle.BACKGROUND);

    // Title
    JLabel titleLabel = UIStyle.createTitleLabel("Create New User");
    titleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
    mainPanel.add(titleLabel);
    mainPanel.add(Box.createRigidArea(new Dimension(0, 20)));

    // User ID Field
    JLabel userIdLabel = new JLabel("User ID (Format: U001, U002, etc.)");
    userIdLabel.setFont(UIStyle.FONT_BODY_BOLD);
    userIdLabel.setForeground(UIStyle.TEXT_PRIMARY);
    JTextField userIdField = UIStyle.createTextField();
    userIdField.setMaximumSize(new Dimension(400, 40));

    mainPanel.add(userIdLabel);
    mainPanel.add(Box.createRigidArea(new Dimension(0, 5)));
    mainPanel.add(userIdField);
    mainPanel.add(Box.createRigidArea(new Dimension(0, 15)));

    // Name Field
    JLabel nameLabel = new JLabel("Full Name");
    nameLabel.setFont(UIStyle.FONT_BODY_BOLD);
    nameLabel.setForeground(UIStyle.TEXT_PRIMARY);
    JTextField nameField = UIStyle.createTextField();
    nameField.setMaximumSize(new Dimension(400, 40));

    mainPanel.add(nameLabel);
    mainPanel.add(Box.createRigidArea(new Dimension(0, 5)));
    mainPanel.add(nameField);
    mainPanel.add(Box.createRigidArea(new Dimension(0, 15)));

    // Email Field
    JLabel emailLabel = new JLabel("Email (@gmail.com)");
    emailLabel.setFont(UIStyle.FONT_BODY_BOLD);
    emailLabel.setForeground(UIStyle.TEXT_PRIMARY);
    JTextField emailField = UIStyle.createTextField();
    emailField.setMaximumSize(new Dimension(400, 40));

    mainPanel.add(emailLabel);
    mainPanel.add(Box.createRigidArea(new Dimension(0, 5)));
    mainPanel.add(emailField);
    mainPanel.add(Box.createRigidArea(new Dimension(0, 15)));

    // Password Field
    JLabel passwordLabel = new JLabel("Password (minimum 8 characters)");
    passwordLabel.setFont(UIStyle.FONT_BODY_BOLD);
    passwordLabel.setForeground(UIStyle.TEXT_PRIMARY);
    JPasswordField passwordField = new JPasswordField();
    passwordField.setFont(UIStyle.FONT_BODY);
    passwordField.setPreferredSize(new Dimension(400, 40));
    passwordField.setMaximumSize(new Dimension(400, 40));
    passwordField.setBorder(BorderFactory.createCompoundBorder(
        BorderFactory.createLineBorder(UIStyle.BORDER_LIGHT, 1),
        BorderFactory.createEmptyBorder(8, 12, 8, 12)
    ));

    mainPanel.add(passwordLabel);
    mainPanel.add(Box.createRigidArea(new Dimension(0, 5)));
    mainPanel.add(passwordField);
    mainPanel.add(Box.createRigidArea(new Dimension(0, 15)));

    // Role Selection
    JLabel roleLabel = new JLabel("Role");
    roleLabel.setFont(UIStyle.FONT_BODY_BOLD);
    roleLabel.setForeground(UIStyle.TEXT_PRIMARY);
    String[] roles = { "STUDENT", "ACADEMIC_OFFICER", "COURSE_ADMIN" };
    JComboBox<String> roleCombo = new JComboBox<>(roles);
    roleCombo.setFont(UIStyle.FONT_BODY);
    roleCombo.setMaximumSize(new Dimension(400, 40));
    roleCombo.setBackground(Color.WHITE);

    mainPanel.add(roleLabel);
    mainPanel.add(Box.createRigidArea(new Dimension(0, 5)));
    mainPanel.add(roleCombo);
    mainPanel.add(Box.createRigidArea(new Dimension(0, 25)));

    // Buttons
    JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 0));
    buttonPanel.setBackground(UIStyle.BACKGROUND);
    buttonPanel.setMaximumSize(new Dimension(500, 50));

    JButton createBtn = UIStyle.createSuccessButton("Create User");
    createBtn.setPreferredSize(new Dimension(140, 45));

    JButton cancelBtn = UIStyle.createSecondaryButton("Cancel");
    cancelBtn.setPreferredSize(new Dimension(120, 45));

    buttonPanel.add(createBtn);
    buttonPanel.add(cancelBtn);
    mainPanel.add(buttonPanel);

    // Cancel button action
    cancelBtn.addActionListener(e -> dialog.dispose());

    // Create button action with validation
    createBtn.addActionListener(e -> {
        // Get values
        String userId = userIdField.getText().trim().toUpperCase();
        String name = nameField.getText().trim();
        String email = emailField.getText().trim().toLowerCase();
        String password = new String(passwordField.getPassword());
        String role = (String) roleCombo.getSelectedItem();

        // Validate User ID
        if (userId.isEmpty()) {
            UIStyle.showError(dialog, "Validation Error", "User ID cannot be empty!");
            userIdField.requestFocus();
            return;
        }

        if (!userId.matches("U\\d+")) {
            UIStyle.showError(dialog, "Invalid Format", 
                "User ID must be in format: U001, U002, U123, etc.\n" +
                "It must start with 'U' followed by numbers.");
            userIdField.requestFocus();
            return;
        }

        // Check if User ID already exists
        for (User existingUser : userService.getAllUsers()) {
            if (existingUser.getUserID().equalsIgnoreCase(userId)) {
                UIStyle.showError(dialog, "ID Exists", 
                    "User ID '" + userId + "' already exists!\n" +
                    "Please use a different ID.");
                userIdField.requestFocus();
                return;
            }
        }

        // Validate Name
        if (name.isEmpty()) {
            UIStyle.showError(dialog, "Validation Error", "Name cannot be empty!");
            nameField.requestFocus();
            return;
        }

        if (name.length() < 2) {
            UIStyle.showError(dialog, "Invalid Name", 
                "Name must be at least 2 characters long!");
            nameField.requestFocus();
            return;
        }

        // Validate Email
        if (email.isEmpty()) {
            UIStyle.showError(dialog, "Validation Error", "Email cannot be empty!");
            emailField.requestFocus();
            return;
        }

        if (!email.matches("^[a-zA-Z0-9._%+-]+@gmail\\.com$")) {
            UIStyle.showError(dialog, "Invalid Email", 
                "Email must be a valid Gmail address!\n" +
                "Format: username@gmail.com");
            emailField.requestFocus();
            return;
        }

        // Check if email already exists
        if (userService.getUserByEmail(email) != null) {
            UIStyle.showError(dialog, "Email Exists", 
                "An account with email '" + email + "' already exists!");
            emailField.requestFocus();
            return;
        }

        // Validate Password
        if (password.length() < 8) {
            UIStyle.showError(dialog, "Invalid Password", 
                "Password must be at least 8 characters long!\n" +
                "Current length: " + password.length());
            passwordField.requestFocus();
            return;
        }

        // All validation passed - create user
        try {
            User.Role userRole = User.Role.valueOf(role);
            User newUser = new User(userId, name, email, "", userRole, true);

            userService.addUser(newUser, password);

            // Send welcome email
            if (emailService != null) {
                emailService.sendWelcomeEmail(newUser);
            }

            UIStyle.showSuccess(UserManagementPanel.this, "Success",
                "User created successfully!\n\n" +
                "User ID: " + userId + "\n" +
                "Name: " + name + "\n" +
                "Email: " + email + "\n" +
                "Role: " + role + "\n\n" +
                "Welcome email sent!");

            loadUsers();
            dialog.dispose();

        } catch (Exception ex) {
            UIStyle.showError(dialog, "Error", 
                "Failed to create user: " + ex.getMessage());
            ex.printStackTrace();
        }
    });

    dialog.add(mainPanel);
    dialog.setVisible(true);
}

    private void showEditUserDialog() {
        int selectedRow = userTable.getSelectedRow();
        if (selectedRow == -1) {
            UIStyle.showWarning(this, "No Selection", "Please select a user to edit.");
            return;
        }

        String email = tableModel.getValueAt(selectedRow, 2).toString();
        User user = userService.getUserByEmail(email);

        if (user == null) {
            UIStyle.showError(this, "Error", "User not found!");
            return;
        }

        Window parentWindow = SwingUtilities.getWindowAncestor(this);
        JDialog dialog = parentWindow instanceof Frame ? new JDialog((Frame) parentWindow, "Edit User", true)
                : new JDialog((Dialog) parentWindow, "Edit User", true);
        dialog.setSize(450, 400);
        dialog.setLocationRelativeTo(parentWindow);

        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 30, 20, 30));
        panel.setBackground(UIStyle.BACKGROUND);

        JLabel title = UIStyle.createSubtitleLabel("Edit User: " + user.getName());
        title.setForeground(UIStyle.PRIMARY);
        title.setAlignmentX(Component.CENTER_ALIGNMENT);
        panel.add(title);
        panel.add(Box.createRigidArea(new Dimension(0, 20)));

        JTextField nameField = UIStyle.createTextField();
        nameField.setText(user.getName());

        JTextField emailField = UIStyle.createTextField();
        emailField.setText(user.getEmail());
        emailField.setEditable(false);
        emailField.setBackground(UIStyle.BORDER_LIGHT);

        panel.add(createFormField("Full Name:", nameField));
        panel.add(Box.createRigidArea(new Dimension(0, 10)));
        panel.add(createFormField("Email:", emailField));
        panel.add(Box.createRigidArea(new Dimension(0, 20)));

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 0));
        buttonPanel.setBackground(UIStyle.BACKGROUND);

        JButton saveBtn = UIStyle.createSuccessButton("Save");
        JButton cancelBtn = UIStyle.createSecondaryButton("Cancel");

        saveBtn.addActionListener(e -> {
            try {
                user.setName(nameField.getText().trim());
                userService.updateUser(user);
                emailService.sendAccountUpdateEmail(user);

                UIStyle.showSuccess(this, "Success", "User updated and notification email sent!");
                loadUsers();
                dialog.dispose();

            } catch (Exception ex) {
                UIStyle.showError(this, "Error", "Failed to update user: " + ex.getMessage());
            }
        });

        cancelBtn.addActionListener(e -> dialog.dispose());

        buttonPanel.add(saveBtn);
        buttonPanel.add(cancelBtn);
        panel.add(buttonPanel);

        dialog.add(panel);
        dialog.setVisible(true);
    }

private void toggleUserStatus() {
    int selectedRow = userTable.getSelectedRow();
    if (selectedRow == -1) {
        UIStyle.showWarning(this, "No Selection", "Please select a user to toggle status.");
        return;
    }

    String email = tableModel.getValueAt(selectedRow, 2).toString();
    User user = userService.getUserByEmail(email);

    if (user == null) {
        UIStyle.showError(this, "Error", "User not found!");
        return;
    }

    try {
        boolean newStatus = !user.isActive();
        user.setActive(newStatus);
        userService.updateUser(user);
        
        // Send email notification
        emailService.sendAccountUpdateEmail(user);

        String statusMsg = newStatus ? "activated" : "deactivated";
        UIStyle.showSuccess(this, "Success", 
            "User has been " + statusMsg + ".\nNotification email sent to user.");
        
        loadUsers();

    } catch (Exception ex) {
        UIStyle.showError(this, "Error", "Failed to toggle status: " + ex.getMessage());
    }
}

    private void resetUserPassword() {
        int selectedRow = userTable.getSelectedRow();
        if (selectedRow == -1) {
            UIStyle.showWarning(this, "No Selection", "Please select a user to reset password.");
            return;
        }

        String email = tableModel.getValueAt(selectedRow, 2).toString();
        User user = userService.getUserByEmail(email);

        if (user == null) {
            UIStyle.showError(this, "Error", "User not found!");
            return;
        }

        String newPassword = JOptionPane.showInputDialog(this,
                "Enter new password for " + user.getName() + ":",
                "Reset Password",
                JOptionPane.PLAIN_MESSAGE);

        if (newPassword != null && !newPassword.trim().isEmpty()) {
            try {
                userService.resetPassword(email, newPassword);
                emailService.sendPasswordResetEmail(user);

                UIStyle.showSuccess(this, "Success",
                        "Password reset successfully!\nNotification email sent to user.");

            } catch (Exception ex) {
                UIStyle.showError(this, "Error", "Failed to reset password: " + ex.getMessage());
            }
        }
    }

    private JPanel createFormField(String label, JComponent field) {
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBackground(UIStyle.BACKGROUND);
        panel.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel labelComp = new JLabel(label);
        labelComp.setFont(UIStyle.FONT_BODY_BOLD);
        labelComp.setForeground(UIStyle.TEXT_PRIMARY);
        labelComp.setAlignmentX(Component.LEFT_ALIGNMENT);

        field.setAlignmentX(Component.LEFT_ALIGNMENT);

        panel.add(labelComp);
        panel.add(Box.createRigidArea(new Dimension(0, 5)));
        panel.add(field);

        return panel;
    }
}
