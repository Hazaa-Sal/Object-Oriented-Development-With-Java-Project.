/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package crs;

import java.io.IOException;
import java.util.*;

public class UserService {
    private final FileHandler fileHandler;
    private final Map<String, User> users = new HashMap<>();

    public UserService(FileHandler fh) {
        this.fileHandler = fh;
        try {
            Map<String, User> loaded = fh.loadUsers();
            users.putAll(loaded);
        } catch (IOException e) {
            System.err.println("Warning: could not load users file: " + e.getMessage());
        }
    }

    // Get a user by email
    public User getUserByEmail(String email) {
        if (email == null) return null;
        return users.get(email.toLowerCase());
    }

    // Get all users
    public Collection<User> getAllUsers() {
        return users.values();
    }

    // Add a new user
    public void addUser(User u, String password) throws IOException {
        if (u != null) {
            u.resetPassword(password); // hash and set password
            users.put(u.getEmail().toLowerCase(), u);
            saveUsers();
        }
    }

    // Update an existing user
    public void updateUser(User u) throws IOException {
        if (u != null && users.containsKey(u.getEmail().toLowerCase())) {
            users.put(u.getEmail().toLowerCase(), u);
            saveUsers();
        }
    }

    // Deactivate a user
    public void deactivateUser(String email) throws IOException {
        User u = getUserByEmail(email);
        if (u != null) {
            u.setActive(false);
            saveUsers();
        }
    }

    // Reactivate a user
    public void activateUser(String email) throws IOException {
        User u = getUserByEmail(email);
        if (u != null) {
            u.setActive(true);
            saveUsers();
        }
    }

    // Reset user password
    public void resetPassword(String email, String newPassword) throws IOException {
        User u = getUserByEmail(email);
        if (u != null) {
            u.resetPassword(newPassword);
            saveUsers();
        }
    }

    // Persist users to file
    private void saveUsers() throws IOException {
        fileHandler.saveUsers(users.values());
    }
}
