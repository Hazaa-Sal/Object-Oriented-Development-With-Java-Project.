package crs.cli;

import crs.export.ConsoleReportExporter;
import crs.export.PdfReportExporter;
import crs.export.ReportExporter;
import crs.export.TextFileReportExporter;
import crs.model.EligibilityStatus;
import crs.model.StudentReport;
import crs.notification.ConsoleNotificationService;
import crs.notification.NotificationService;
import crs.repository.*;
import crs.service.*;

import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

public class Demo {

    public static void main(String[] args) {

        // 1) Paths to your data files (relative to project root)
        Path studentCsv = Paths.get("D:/Degree Level 02/Assignment/OODJ/student_information.csv/");
        Path courseCsv  = Paths.get("D:/Degree Level 02/Assignment/OODJ/course_assessment_information.csv");
        Path gradesTxt  = Paths.get("D:/Degree Level 02/Assignment/OODJ/oussef_THE_GOAT_code/data/grades.txt");
        Path reportsDir = Paths.get("D:/Degree Level 02/Assignment/OODJ/youssef_THE_GOAT_code/data/reports");

        // 2) Repositories (data access)
        StudentRepository studentRepo = new CsvStudentRepository(studentCsv);
        CourseRepository  courseRepo  = new CsvCourseRepository(courseCsv); // ready for later use
        GradeRepository   gradeRepo   = new TextGradeRepository(gradesTxt);

        // 3) Services
        EligibilityChecker eligibilityService =
                new DefaultEligibilityService(studentRepo, gradeRepo);

        ReportService reportService =
                new DefaultReportService(studentRepo, gradeRepo);

        // 4) Exporters + Notification
        ReportExporter consoleExporter = new ConsoleReportExporter();
        ReportExporter textExporter    = new TextFileReportExporter();
        ReportExporter pdfExporter     = new PdfReportExporter();
        NotificationService notifier   = new ConsoleNotificationService();

        // pick a student ID that exists in your CSV and grades.txt, e.g. "S001"
        String studentId = "S001";

        // === A) Eligibility check for one student ===
        System.out.println("=== ELIGIBILITY CHECK ===");
        EligibilityStatus status = eligibilityService.check(studentId);
        printEligibility(status);

        // === B) List all ineligible students ===
        System.out.println("\n=== INELIGIBLE STUDENTS LIST ===");
        DefaultEligibilityService impl = (DefaultEligibilityService) eligibilityService;
        List<EligibilityStatus> ineligible = impl.listIneligibleStudents();
        if (ineligible.isEmpty()) {
            System.out.println("No ineligible students.");
        } else {
            for (EligibilityStatus s : ineligible) {
                printEligibility(s);
            }
        }

        // === C) Generate performance report for a semester ===
        System.out.println("\n=== GENERATE SEMESTER REPORT ===");
        StudentReport report = reportService.buildSemesterReport(studentId, "Fall", 2024);

        // print to console
        consoleExporter.export(report, null);

        // write to text file
        Path textFile = textExporter.export(report, reportsDir);

        // write to PDF file
        Path pdfFile  = pdfExporter.export(report, reportsDir);

        // === D) Send fake notification ===
        notifier.sendPerformanceReport(
                report.getStudent().getEmail(),
                "Your Academic Performance Report",
                "Your report has been generated.\n"
                        + "Text file : " + textFile.toAbsolutePath() + "\n"
                        + "PDF file  : " + pdfFile.toAbsolutePath()
        );
    }

    private static void printEligibility(EligibilityStatus r) {
        System.out.println(r.getStudent()
                + " | CGPA=" + String.format("%.2f", r.getCgpa())
                + " | failed=" + r.getFailedCourses()
                + " | eligible=" + r.isEligible());
        if (!r.isEligible()) {
            System.out.println("  Reasons: " + r.getReasons());
        }
    }
}
