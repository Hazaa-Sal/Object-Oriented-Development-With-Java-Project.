package crs.export;

import crs.model.GradeRecord;
import crs.model.StudentReport;

import java.nio.file.Path;

public class ConsoleReportExporter implements ReportExporter {

    @Override
    public Path export(StudentReport report, Path targetDir) {

        System.out.println("====================================");
        System.out.println("      ACADEMIC PERFORMANCE REPORT   ");
        System.out.println("====================================");
        System.out.println("Student : " + report.getStudent().getFullName()
                + " (" + report.getStudent().getId() + ")");
        System.out.println("Email   : " + report.getStudent().getEmail());
        System.out.println("Semester: " + report.getSemester() + " " + report.getYear());
        System.out.println("------------------------------------");
        System.out.println("Courses:");
        for (GradeRecord g : report.getRecords()) {
            System.out.printf(" - %s | %s | gp=%.1f | credits=%d%n",
                    g.getCourseId(), g.getGradeLetter(),
                    g.getGradePoint(), g.getCredits());
        }
        System.out.println("------------------------------------");
        System.out.printf("Cumulative CGPA: %.2f%n", report.getCumulativeCgpa());
        System.out.println("====================================");

        return null;  // nothing written to disk
    }
}
