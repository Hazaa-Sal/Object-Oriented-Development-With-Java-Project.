package crs.export;

import crs.model.GradeRecord;
import crs.model.StudentReport;

import com.itextpdf.text.*;
import com.itextpdf.text.pdf.*;

import java.io.BufferedReader;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.Reader;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Map;

public class PdfReportExporter implements ReportExporter {

    // ===== COLOR PALETTE (Extracted from Image) =====
    private static final BaseColor CLR_BG          = new BaseColor(250, 248, 242); // Cream/Beige
    private static final BaseColor CLR_NAVY        = new BaseColor(21, 43, 73);    // Dark Navy
    private static final BaseColor CLR_GOLD        = new BaseColor(196, 154, 72);  // Gold
    private static final BaseColor CLR_GREEN       = new BaseColor(46, 160, 73);   // Status Green
    private static final BaseColor CLR_RED         = new BaseColor(220, 53, 69);   // Status Red
    private static final BaseColor CLR_BAR_BLUE    = new BaseColor(30, 55, 90);    // Bar Blue
    private static final BaseColor CLR_BAR_GOLD    = new BaseColor(196, 154, 72);  // Bar Gold
    private static final BaseColor CLR_BAR_RED     = new BaseColor(220, 53, 69);   // Bar Red
    private static final BaseColor CLR_BAR_BG      = new BaseColor(220, 220, 220); // Light Grey Bar Background

    // ===== COURSE TITLES (loaded from course_assessment_information.csv) =====
    private static final Map<String, String> COURSE_TITLES = loadCourseTitles();

    @Override
    public Path export(StudentReport report, Path targetDir) {
        try {
            if (targetDir == null) targetDir = Paths.get("data", "reports");
            Files.createDirectories(targetDir);
            Path out = targetDir.resolve("report_" + report.getStudent().getId() + ".pdf");

            // 1. Setup Document with Margin
            Document document = new Document(PageSize.A4, 40, 40, 40, 40);
            PdfWriter writer = PdfWriter.getInstance(document, new FileOutputStream(out.toFile()));
            document.open();

            // 2. Draw Full Page Background Color
            PdfContentByte canvas = writer.getDirectContentUnder();
            canvas.setColorFill(CLR_BG);
            canvas.rectangle(0, 0, PageSize.A4.getWidth(), PageSize.A4.getHeight());
            canvas.fill();

            // 3. Fonts
            Font fTitleGold = new Font(Font.FontFamily.HELVETICA, 24, Font.BOLD, CLR_GOLD);
            Font fTitleNavy = new Font(Font.FontFamily.HELVETICA, 24, Font.BOLD, CLR_NAVY);
            Font fHeader    = new Font(Font.FontFamily.HELVETICA, 10, Font.BOLD, CLR_NAVY);
            Font fLabel     = new Font(Font.FontFamily.HELVETICA, 10, Font.NORMAL, BaseColor.DARK_GRAY);
            Font fValue     = new Font(Font.FontFamily.HELVETICA, 10, Font.BOLD, BaseColor.BLACK);
            Font fCgpa      = new Font(Font.FontFamily.HELVETICA, 36, Font.BOLD, CLR_NAVY);
            Font fCgpaLabel = new Font(Font.FontFamily.HELVETICA, 9, Font.NORMAL, BaseColor.GRAY);
            Font fTableHead = new Font(Font.FontFamily.HELVETICA, 11, Font.BOLD, BaseColor.WHITE);

            // ================= HEADER SECTION =================
            Paragraph titleP = new Paragraph();
            titleP.add(new Chunk("ACADEMIC PERFORMANCE ", fTitleGold));
            titleP.add(new Chunk("REPORT", fTitleNavy));
            titleP.setAlignment(Element.ALIGN_LEFT);
            titleP.setSpacingAfter(20);
            document.add(titleP);
            
            // Optional logo
            try {
                Image logo = Image.getInstance("logo.png"); 
                logo.scaleToFit(50, 50);
                logo.setAbsolutePosition(270, 750); // Adjust if you actually add a logo
                // document.add(logo); // uncomment when logo.png exists
            } catch (Exception ignored) {}

            // ================= STUDENT INFO CARD =================
            Paragraph pInfo = new Paragraph("STUDENT INFORMATION", fHeader);
            pInfo.setSpacingAfter(5);
            document.add(pInfo);

            PdfPTable cardTable = new PdfPTable(2);
            cardTable.setWidthPercentage(100);
            cardTable.setWidths(new float[]{3, 1}); // 75% Info, 25% CGPA
            cardTable.setSpacingAfter(20);

            // Left: details
            PdfPCell infoCell = new PdfPCell();
            infoCell.setBorder(Rectangle.NO_BORDER);
            infoCell.setPadding(15);
            infoCell.addElement(createDetailRow("Student ID:",        report.getStudent().getId(),               fLabel, fValue));
            infoCell.addElement(createDetailRow("Name:",              report.getStudent().getFullName(),         fLabel, fValue));
            infoCell.addElement(createDetailRow("Email:",             report.getStudent().getEmail(),            fLabel, fValue));
            infoCell.addElement(createDetailRow("Semester:",          report.getSemester() + " " + report.getYear(), fLabel, fValue));
            infoCell.addElement(createDetailRow("Cumulative CGPA:",   String.format("%.2f", report.getCumulativeCgpa()), fLabel, fValue));

            // Right: big CGPA
            PdfPCell cgpaCell = new PdfPCell();
            cgpaCell.setBorder(Rectangle.NO_BORDER);
            cgpaCell.setBorderWidthLeft(1f);
            cgpaCell.setBorderColorLeft(new BaseColor(230,230,230));
            cgpaCell.setPadding(10);
            cgpaCell.setVerticalAlignment(Element.ALIGN_MIDDLE);
            
            Paragraph cgpaLabelP = new Paragraph("Cumulative CGPA:", fCgpaLabel);
            cgpaLabelP.setAlignment(Element.ALIGN_RIGHT);
            cgpaCell.addElement(cgpaLabelP);

            Paragraph cgpaValueP = new Paragraph(String.format("%.2f", report.getCumulativeCgpa()), fCgpa);
            cgpaValueP.setAlignment(Element.ALIGN_RIGHT);
            cgpaCell.addElement(cgpaValueP);

            cardTable.addCell(infoCell);
            cardTable.addCell(cgpaCell);

            // Rounded card wrapper
            PdfPTable outerCard = new PdfPTable(1);
            outerCard.setWidthPercentage(100);
            PdfPCell outerCell = new PdfPCell(cardTable);
            outerCell.setPadding(0);
            outerCell.setBorder(Rectangle.NO_BORDER);
            outerCell.setCellEvent(new RoundBorder(BaseColor.WHITE, 10));
            outerCard.addCell(outerCell);
            
            document.add(outerCard);
            document.add(Chunk.NEWLINE);

            // ================= STATUS SECTION =================
            int failedCount = (int) report.getRecords().stream().filter(GradeRecord::isFailed).count();
            boolean isPassed = report.getCumulativeCgpa() >= 2.0 && failedCount <= 3;

            Paragraph pStatus = new Paragraph("OVERALL STATUS", fHeader);
            document.add(pStatus);

            Paragraph pStatusVal = new Paragraph();
            if (isPassed) {
                Chunk check = new Chunk("\u2714  ",
                        new Font(Font.FontFamily.HELVETICA, 14, Font.BOLD, CLR_GREEN));
                Chunk text = new Chunk("PASSED (Eligible)",
                        new Font(Font.FontFamily.HELVETICA, 14, Font.BOLD, CLR_GREEN));
                pStatusVal.add(check);
                pStatusVal.add(text);
            } else {
                Chunk cross = new Chunk("\u2716  ",
                        new Font(Font.FontFamily.HELVETICA, 14, Font.BOLD, CLR_RED));
                Chunk text = new Chunk("FAILED / AT RISK",
                        new Font(Font.FontFamily.HELVETICA, 14, Font.BOLD, CLR_RED));
                pStatusVal.add(cross);
                pStatusVal.add(text);
            }
            pStatusVal.setSpacingAfter(5);
            document.add(pStatusVal);

            Paragraph pFailCount = new Paragraph("Failed courses this term: " + failedCount, fLabel);
            pFailCount.setSpacingAfter(10);
            document.add(pFailCount);

            // ===== Academic Standing / Honours =====
            double cgpa = report.getCumulativeCgpa();
            String standing;
            if (cgpa >= 3.70) {
                standing = "First Class Honours";
            } else if (cgpa >= 3.30) {
                standing = "Second Class Upper (2:1)";
            } else if (cgpa >= 3.00) {
                standing = "Second Class Lower (2:2)";
            } else if (cgpa >= 2.00) {
                standing = "Pass";
            } else {
                standing = "Fail / At Risk";
            }
            Paragraph standingPara = new Paragraph("Academic Standing: " + standing, fValue);
            standingPara.setSpacingAfter(6f);
            document.add(standingPara);

            // ===== Recommendation text =====
            String rec;
            if (cgpa >= 3.70) {
                rec = "Excellent performance. Strongly recommended for advanced modules or honours track.";
            } else if (cgpa >= 3.30) {
                rec = "Very good performance. You are on track for upper-second class honours.";
            } else if (cgpa >= 3.00) {
                rec = "Good performance. Consider improving weaker modules to reach a higher standing.";
            } else if (cgpa >= 2.00) {
                rec = "Satisfactory performance. Focus on core courses and seek help in challenging topics.";
            } else {
                rec = "Performance is below passing threshold. Immediate academic advising is recommended.";
            }
            Paragraph recPara = new Paragraph("Recommendation: " + rec, fLabel);
            recPara.setSpacingAfter(20f);
            document.add(recPara);

            // ================= RESULTS TABLE =================
            Paragraph pResults = new Paragraph("COURSE RESULTS", fHeader);
            pResults.setSpacingAfter(5);
            document.add(pResults);

            PdfPTable table = new PdfPTable(4);
            table.setWidthPercentage(100);
            table.setWidths(new float[]{3f, 1f, 2.5f, 1f});
            
            // Header
            addHeader(table, "Course",      fTableHead);
            addHeader(table, "Grade",       fTableHead);
            addHeader(table, "Grade Point", fTableHead);
            addHeader(table, "Credits",     fTableHead);

            Font fRow = new Font(Font.FontFamily.HELVETICA, 10, Font.NORMAL, BaseColor.BLACK);
            
            for (GradeRecord g : report.getRecords()) {
                // course code + title
                String code = g.getCourseId();
                String title = COURSE_TITLES.get(code);
                String displayCourse = (title != null && !title.isEmpty())
                        ? code + " - " + title
                        : code;

                BaseColor barColor = CLR_BAR_BLUE;
                if (g.getGradePoint() < 2.0)      barColor = CLR_BAR_RED;
                else if (g.getGradePoint() < 3.0) barColor = CLR_BAR_GOLD;

                table.addCell(createCell(displayCourse,      Element.ALIGN_LEFT,   fRow));
                table.addCell(createCell(g.getGradeLetter(), Element.ALIGN_CENTER, fRow));
                
                PdfPCell progressCell = new PdfPCell(new Phrase(String.format("%.1f", g.getGradePoint()), fRow));
                progressCell.setVerticalAlignment(Element.ALIGN_MIDDLE);
                progressCell.setHorizontalAlignment(Element.ALIGN_RIGHT);
                progressCell.setPaddingRight(10);
                progressCell.setPaddingTop(8);
                progressCell.setPaddingBottom(8);
                progressCell.setBorderColor(new BaseColor(230,230,230));
                progressCell.setCellEvent(new GradeProgressBar(g.getGradePoint(), 4.0, barColor));
                table.addCell(progressCell);

                table.addCell(createCell(String.valueOf(g.getCredits()), Element.ALIGN_CENTER, fRow));
            }

            document.add(table);
            document.add(Chunk.NEWLINE);

            // ===== Semester Summary =====
            int totalCredits = report.getRecords().stream()
                    .mapToInt(GradeRecord::getCredits)
                    .sum();
            Paragraph summary = new Paragraph(
                    String.format("Summary for %s %d: %d courses, %d total credits.",
                            report.getSemester(), report.getYear(),
                            report.getRecords().size(), totalCredits),
                    fLabel
            );
            summary.setSpacingAfter(10f);
            document.add(summary);

            // ================= FOOTER RULE =================
            PdfPTable footerTable = new PdfPTable(1);
            footerTable.setWidthPercentage(100);
            PdfPCell ruleCell = new PdfPCell();
            ruleCell.setBorder(Rectangle.TOP);
            ruleCell.setBorderColor(BaseColor.LIGHT_GRAY);
            ruleCell.setBorderWidthTop(1f);
            ruleCell.setBorderWidthBottom(0);
            ruleCell.setBorderWidthLeft(0);
            ruleCell.setBorderWidthRight(0);
            ruleCell.setPaddingTop(10);
            ruleCell.addElement(new Phrase(
                    "Eligibility rule: CGPA 2.0 and at most 3 failed courses.",
                    new Font(Font.FontFamily.HELVETICA, 8, Font.ITALIC, BaseColor.GRAY)
            ));
            footerTable.addCell(ruleCell);
            document.add(footerTable);

            document.close();
            return out;

        } catch (IOException | DocumentException e) {
            throw new RuntimeException("Failed to export PDF", e);
        }
    }

    // ===== Load course titles from CSV =====
    private static Map<String, String> loadCourseTitles() {
        Map<String, String> map = new HashMap<>();
        Path csv = Paths.get("data", "course_assessment_information.csv");
        if (!Files.exists(csv)) {
            return map;
        }

        try (Reader reader = Files.newBufferedReader(csv);
             BufferedReader br = new BufferedReader(reader)) {

            String headerLine = br.readLine();
            if (headerLine == null) return map;

            String[] headers = headerLine.split(",");
            int codeIdx = -1;
            int titleIdx = -1;

            for (int i = 0; i < headers.length; i++) {
                String h = headers[i].trim().toLowerCase();
                if (h.contains("course") && (h.contains("code") || h.contains("id"))) {
                    codeIdx = i;
                }
                if (h.contains("course") && (h.contains("name") || h.contains("title"))) {
                    titleIdx = i;
                }
            }

            if (codeIdx == -1 || titleIdx == -1) {
                return map; // can't detect columns
            }

            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length <= Math.max(codeIdx, titleIdx)) continue;
                String code = parts[codeIdx].trim();
                String title = parts[titleIdx].trim();
                if (!code.isEmpty() && !title.isEmpty()) {
                    map.put(code, title);
                }
            }

        } catch (IOException ignored) {
        }

        return map;
    }

    // Helper for info rows
    private Paragraph createDetailRow(String label, String value, Font fLabel, Font fValue) {
        Paragraph p = new Paragraph();
        p.add(new Chunk("\u2022 " + label + " ", fLabel));
        p.add(new Chunk(value, fValue));
        p.setSpacingAfter(4);
        return p;
    }

    private void addHeader(PdfPTable table, String text, Font font) {
        PdfPCell cell = new PdfPCell(new Phrase(text, font));
        cell.setBackgroundColor(CLR_NAVY);
        cell.setPadding(8);
        cell.setHorizontalAlignment(Element.ALIGN_CENTER);
        cell.setBorderColor(BaseColor.WHITE);
        table.addCell(cell);
    }

    private PdfPCell createCell(String text, int align, Font font) {
        PdfPCell cell = new PdfPCell(new Phrase(text, font));
        cell.setPadding(8);
        cell.setHorizontalAlignment(align);
        cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
        cell.setBorderColor(new BaseColor(230,230,230));
        return cell;
    }

    // ===== INNER CLASS: Rounded card background =====
    static class RoundBorder implements PdfPCellEvent {
        BaseColor color;
        float radius;

        public RoundBorder(BaseColor color, float radius) {
            this.color = color;
            this.radius = radius;
        }

        @Override
        public void cellLayout(PdfPCell cell, Rectangle position, PdfContentByte[] canvases) {
            PdfContentByte canvas = canvases[PdfPTable.BACKGROUNDCANVAS];
            canvas.saveState();

            // Drop shadow
            canvas.setColorFill(new BaseColor(220, 220, 220));
            canvas.roundRectangle(position.getLeft() + 2, position.getBottom() - 2,
                    position.getWidth(), position.getHeight(), radius);
            canvas.fill();
            
            // White card
            canvas.setColorFill(color);
            canvas.roundRectangle(position.getLeft(), position.getBottom(),
                    position.getWidth(), position.getHeight(), radius);
            canvas.fill();

            canvas.restoreState();
        }
    }

    // ===== INNER CLASS: Grade progress bar =====
    static class GradeProgressBar implements PdfPCellEvent {
        double current;
        double max;
        BaseColor color;

        public GradeProgressBar(double current, double max, BaseColor color) {
            this.current = current;
            this.max = max;
            this.color = color;
        }

        @Override
        public void cellLayout(PdfPCell cell, Rectangle position, PdfContentByte[] canvases) {
            PdfContentByte canvas = canvases[PdfPTable.BACKGROUNDCANVAS];
            canvas.saveState();

            float padding = 8;
            float height = 8;
            float totalWidth = position.getWidth() * 0.6f;
            float startX = position.getLeft() + padding;
            float startY = position.getBottom() + (position.getHeight() - height) / 2;

            // Background bar
            canvas.setColorFill(CLR_BAR_BG);
            canvas.roundRectangle(startX, startY, totalWidth, height, height / 2);
            canvas.fill();

            // Filled bar
            float filledWidth = (float) ((current / max) * totalWidth);
            if (filledWidth > 0) {
                canvas.setColorFill(color);
                canvas.roundRectangle(startX, startY, filledWidth, height, height / 2);
                canvas.fill();
            }

            canvas.restoreState();
        }
    }
}
