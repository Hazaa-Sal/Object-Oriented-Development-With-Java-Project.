package crs.export;

import crs.model.StudentReport;
import java.nio.file.Path;

public interface ReportExporter {

    /**
     * Export the given report.
     *
     * @param report    Report to export
     * @param targetDir Directory where output file will be stored (can be null for console exporters)
     * @return Path to created file, or null if nothing was created
     */
    Path export(StudentReport report, Path targetDir);
}
