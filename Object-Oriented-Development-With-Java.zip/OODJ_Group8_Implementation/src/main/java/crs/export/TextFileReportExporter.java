package crs.export;

import crs.model.GradeRecord;
import crs.model.StudentReport;

import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.file.*;

public class TextFileReportExporter implements ReportExporter {

    @Override
    public Path export(StudentReport report, Path targetDir) {
        try {
            if (targetDir != null) {
                Files.createDirectories(targetDir);
            } else {
                targetDir = Paths.get("reports");
                Files.createDirectories(targetDir);
            }

            Path out = targetDir.resolve("report_" + report.getStudent().getId() + ".txt");

            try (BufferedWriter bw = Files.newBufferedWriter(out)) {
                bw.write("ACADEMIC PERFORMANCE REPORT\n");
                bw.write("===========================\n");
                bw.write("Student : " + report.getStudent().getFullName()
                        + " (" + report.getStudent().getId() + ")\n");
                bw.write("Email   : " + report.getStudent().getEmail() + "\n");
                bw.write("Semester: " + report.getSemester() + " " + report.getYear() + "\n\n");

                bw.write("Courses:\n");
                for (GradeRecord g : report.getRecords()) {
                    bw.write(String.format(" - %s | %s | gp=%.1f | credits=%d%n",
                            g.getCourseId(), g.getGradeLetter(),
                            g.getGradePoint(), g.getCredits()));
                }
                bw.write("\n");
                bw.write(String.format("Cumulative CGPA: %.2f%n", report.getCumulativeCgpa()));
            }

            return out;
        } catch (IOException e) {
            throw new RuntimeException("Failed to export report to text file", e);
        }
    }
}
