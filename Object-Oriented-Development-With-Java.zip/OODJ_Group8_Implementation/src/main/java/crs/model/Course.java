package crs.model;

public class Course {

    private final String id;
    private final String name;
    private final int credits;
    private final String semester;
    private final String instructor;
    private final int examWeight;
    private final int assignmentWeight;

    public Course(String id, String name, int credits,
                  String semester, String instructor,
                  int examWeight, int assignmentWeight) {
        this.id = id;
        this.name = name;
        this.credits = credits;
        this.semester = semester;
        this.instructor = instructor;
        this.examWeight = examWeight;
        this.assignmentWeight = assignmentWeight;
    }

    public String getId() { return id; }
    public String getName() { return name; }
    public int getCredits() { return credits; }
    public String getSemester() { return semester; }
    public String getInstructor() { return instructor; }
    public int getExamWeight() { return examWeight; }
    public int getAssignmentWeight() { return assignmentWeight; }
}
