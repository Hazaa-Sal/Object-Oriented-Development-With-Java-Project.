package crs.model;

import java.util.List;

public class EligibilityStatus {

    private final Student student;
    private final double cgpa;
    private final int failedCourses;
    private final boolean eligible;
    private final List<String> reasons;

    public EligibilityStatus(Student student,
                             double cgpa,
                             int failedCourses,
                             boolean eligible,
                             List<String> reasons) {

        this.student = student;
        this.cgpa = cgpa;
        this.failedCourses = failedCourses;
        this.eligible = eligible;
        this.reasons = reasons;
    }

    public Student getStudent() { return student; }
    public double getCgpa() { return cgpa; }
    public int getFailedCourses() { return failedCourses; }
    public boolean isEligible() { return eligible; }
    public List<String> getReasons() { return reasons; }
}
