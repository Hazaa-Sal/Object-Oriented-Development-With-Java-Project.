package crs.model;

public class GradeRecord {

    private final String studentId;
    private final String courseId;
    private final String semester;
    private final int year;
    private final int credits;
    private final String gradeLetter;
    private final double gradePoint;

    public GradeRecord(String studentId, String courseId,
                       String semester, int year, int credits,
                       String gradeLetter, double gradePoint) {
        this.studentId = studentId;
        this.courseId = courseId;
        this.semester = semester;
        this.year = year;
        this.credits = credits;
        this.gradeLetter = gradeLetter;
        this.gradePoint = gradePoint;
    }

    public String getStudentId() { return studentId; }
    public String getCourseId() { return courseId; }
    public String getSemester() { return semester; }
    public int getYear() { return year; }
    public int getCredits() { return credits; }
    public String getGradeLetter() { return gradeLetter; }
    public double getGradePoint() { return gradePoint; }

    public boolean isFailed() {
        return gradePoint < 2.0;
    }
}
