package crs.model;

public abstract class Person {   // abstract = cannot be instantiated directly
    protected String firstName;
    protected String lastName;
    protected String email;

    protected Person(String firstName, String lastName, String email) {
        this.firstName = firstName;
        this.lastName  = lastName;
        this.email     = email;
    }

    public String getFirstName() { return firstName; }
    public String getLastName()  { return lastName; }
    public String getEmail()     { return email; }

    public String getFullName() {
        return firstName + " " + lastName;
    }
}
