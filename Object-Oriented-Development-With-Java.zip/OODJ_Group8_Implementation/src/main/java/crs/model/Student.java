package crs.model;

public class Student extends Person {

    private final String id;
    private final String major;
    private final String year;

    public Student(String id, String firstName, String lastName,
                   String major, String year, String email) {
        super(firstName, lastName, email);
        this.id = id;
        this.major = major;
        this.year = year;
    }

    public String getId()     { return id; }
    public String getMajor()  { return major; }
    public String getYear()   { return year; }

    @Override
    public String toString() {
        return id + " - " + getFullName() + " (" + major + ", " + year + ")";
    }
}
