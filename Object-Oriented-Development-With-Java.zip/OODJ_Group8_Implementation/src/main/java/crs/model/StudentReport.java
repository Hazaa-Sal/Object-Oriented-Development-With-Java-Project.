package crs.model;

import java.util.List;

public class StudentReport {

    private final Student student;
    private final String semester;
    private final int year;
    private final List<GradeRecord> records;
    private final double cumulativeCgpa;

    public StudentReport(Student student, String semester, int year,
                         List<GradeRecord> records, double cumulativeCgpa) {
        this.student = student;
        this.semester = semester;
        this.year = year;
        this.records = records;
        this.cumulativeCgpa = cumulativeCgpa;
    }

    public Student getStudent() { return student; }
    public String getSemester() { return semester; }
    public int getYear() { return year; }
    public List<GradeRecord> getRecords() { return records; }
    public double getCumulativeCgpa() { return cumulativeCgpa; }
}
