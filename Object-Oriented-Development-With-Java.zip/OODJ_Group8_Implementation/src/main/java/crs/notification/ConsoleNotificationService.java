package crs.notification;

public class ConsoleNotificationService implements NotificationService {

    @Override
    public void sendPerformanceReport(String recipientEmail, String subject, String body) {
        System.out.println("[NOTIFICATION] =======================");
        System.out.println("To      : " + recipientEmail);
        System.out.println("Subject : " + subject);
        System.out.println("Body    : " + body);
        System.out.println("=====================================");
    }
}
