package crs.notification;

public interface NotificationService {

    void sendPerformanceReport(String recipientEmail, String subject, String body);
}
