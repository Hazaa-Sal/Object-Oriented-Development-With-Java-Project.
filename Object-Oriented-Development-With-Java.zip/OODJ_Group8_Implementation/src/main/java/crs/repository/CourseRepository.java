package crs.repository;

import crs.model.Course;
import java.util.List;
import java.util.Optional;

public interface CourseRepository {

    Optional<Course> findById(String id);

    List<Course> findAll();
}
