package crs.repository;

import crs.model.Course;

import java.io.BufferedReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;

public class CsvCourseRepository implements CourseRepository {

    private final Map<String, Course> courses = new HashMap<>();

    public CsvCourseRepository(Path csvPath) {
        load(csvPath);
    }

    private void load(Path csvPath) {
        try (BufferedReader br = Files.newBufferedReader(csvPath)) {

            String header = br.readLine(); // skip header
            String line;

            while ((line = br.readLine()) != null) {
                String[] p = line.split(",", -1);
                // CourseID, CourseName, Credits, Semester, Instructor, ExamWeight, AssignmentWeight
                if (p.length < 7) continue;

                Course c = new Course(
                        p[0].trim(),
                        p[1].trim(),
                        Integer.parseInt(p[2].trim()),
                        p[3].trim(),
                        p[4].trim(),
                        Integer.parseInt(p[5].trim()),
                        Integer.parseInt(p[6].trim())
                );
                courses.put(c.getId(), c);
            }
        } catch (IOException e) {
            throw new RuntimeException("Failed to load courses from " + csvPath, e);
        }
    }

    @Override
    public Optional<Course> findById(String id) {
        return Optional.ofNullable(courses.get(id));
    }

    @Override
    public List<Course> findAll() {
        return new ArrayList<>(courses.values());
    }
}
