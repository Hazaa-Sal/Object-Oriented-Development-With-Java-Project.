package crs.repository;

import crs.model.Student;

import java.io.BufferedReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;

public class CsvStudentRepository implements StudentRepository {

    private final Map<String, Student> students = new HashMap<>();

    public CsvStudentRepository(Path csvPath) {
        load(csvPath);
    }

    private void load(Path csvPath) {
        try (BufferedReader br = Files.newBufferedReader(csvPath)) {

            String header = br.readLine(); // skip header line
            String line;

            while ((line = br.readLine()) != null) {
                String[] p = line.split(",", -1);
                // StudentID,FirstName,LastName,Major,Year,Email
                if (p.length < 6) continue;

                Student s = new Student(
                        p[0].trim(), // id
                        p[1].trim(), // firstName
                        p[2].trim(), // lastName
                        p[3].trim(), // major
                        p[4].trim(), // year
                        p[5].trim()  // email
                );
                students.put(s.getId(), s);
            }
        } catch (IOException e) {
            throw new RuntimeException("Failed to load students from " + csvPath, e);
        }
    }

    @Override
    public Optional<Student> findById(String id) {
        return Optional.ofNullable(students.get(id));
    }

    @Override
    public List<Student> findAll() {
        return new ArrayList<>(students.values());
    }
}
