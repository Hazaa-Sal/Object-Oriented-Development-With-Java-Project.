package crs.repository;

import crs.model.GradeRecord;
import java.util.List;

public interface GradeRepository {

    List<GradeRecord> findByStudent(String studentId);

    List<GradeRecord> findAll();

    void save(GradeRecord record);   // used when updating/adding grades later
}
