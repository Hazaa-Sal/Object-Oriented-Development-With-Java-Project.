package crs.repository;

import crs.model.Student;
import java.util.List;
import java.util.Optional;

public interface StudentRepository {

    Optional<Student> findById(String id);

    List<Student> findAll();
}
