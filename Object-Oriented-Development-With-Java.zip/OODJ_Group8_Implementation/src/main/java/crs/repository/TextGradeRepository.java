package crs.repository;

import crs.model.GradeRecord;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.file.*;
import java.util.ArrayList;
import java.util.List;

public class TextGradeRepository implements GradeRepository {

    private final Path path;
    private final List<GradeRecord> records = new ArrayList<>();

    public TextGradeRepository(Path path) {
        this.path = path;
        if (Files.exists(path)) {
            load();
        }
    }

    private void load() {
        try (BufferedReader br = Files.newBufferedReader(path)) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] p = line.split("\\|", -1);
                if (p.length < 7) continue;

                String studentId   = p[0].trim();
                String courseId    = p[1].trim();
                String semester    = p[2].trim();
                int year           = Integer.parseInt(p[3].trim());
                int credits        = Integer.parseInt(p[4].trim());
                String gradeLetter = p[5].trim();
                double gradePoint  = Double.parseDouble(p[6].trim());

                records.add(new GradeRecord(studentId, courseId, semester, year,
                        credits, gradeLetter, gradePoint));
            }
        } catch (IOException e) {
            throw new RuntimeException("Failed to load grade records", e);
        }
    }

    private void persist() {
        try (BufferedWriter bw = Files.newBufferedWriter(path)) {
            for (GradeRecord g : records) {
                bw.write(String.join("|",
                        g.getStudentId(),
                        g.getCourseId(),
                        g.getSemester(),
                        String.valueOf(g.getYear()),
                        String.valueOf(g.getCredits()),
                        g.getGradeLetter(),
                        String.valueOf(g.getGradePoint())
                ));
                bw.newLine();
            }
        } catch (IOException e) {
            throw new RuntimeException("Failed to save grade records", e);
        }
    }

    @Override
    public List<GradeRecord> findByStudent(String studentId) {
        List<GradeRecord> result = new ArrayList<>();
        for (GradeRecord g : records) {
            if (g.getStudentId().equals(studentId)) {
                result.add(g);
            }
        }
        return result;
    }

    @Override
    public List<GradeRecord> findAll() {
        return new ArrayList<>(records);
    }

    @Override
    public void save(GradeRecord record) {
        records.add(record);
        persist();
    }
}
