package crs.service;

import crs.model.GradeRecord;
import java.util.List;

public class CgpaService {

    // CGPA = sum(gradePoint * credits) / sum(credits)
    public double computeCgpa(List<GradeRecord> grades) {
        double totalPoints = 0.0;
        int totalCredits = 0;

        for (GradeRecord g : grades) {
            totalPoints += g.getGradePoint() * g.getCredits();
            totalCredits += g.getCredits();
        }

        if (totalCredits == 0) {
            return 0.0;
        }
        return totalPoints / totalCredits;
    }

    // count how many courses are failed (gradePoint < 2.0)
    public int countFailed(List<GradeRecord> grades) {
        int failed = 0;
        for (GradeRecord g : grades) {
            if (g.isFailed()) {
                failed++;
            }
        }
        return failed;
    }
}
