package crs.service;

import crs.model.EligibilityStatus;
import crs.model.GradeRecord;
import crs.model.Student;
import crs.repository.GradeRepository;
import crs.repository.StudentRepository;

import java.util.ArrayList;
import java.util.List;

public class DefaultEligibilityService implements EligibilityChecker {

    private final StudentRepository studentRepo;
    private final GradeRepository gradeRepo;
    private final CgpaService cgpaService = new CgpaService();

    public DefaultEligibilityService(StudentRepository studentRepo,
                                     GradeRepository gradeRepo) {
        this.studentRepo = studentRepo;
        this.gradeRepo = gradeRepo;
    }

    // RULE: CGPA >= 2.0 AND failed <= 3
    @Override
    public EligibilityStatus check(String studentId) {

        Student student = studentRepo.findById(studentId)
                .orElseThrow(() ->
                        new IllegalArgumentException("Student not found: " + studentId));

        List<GradeRecord> grades = gradeRepo.findByStudent(studentId);

        double cgpa = cgpaService.computeCgpa(grades);
        int failed  = cgpaService.countFailed(grades);

        boolean eligible = (cgpa >= 2.0) && (failed <= 3);

        List<String> reasons = new ArrayList<>();
        if (cgpa < 2.0) {
            reasons.add("CGPA below 2.0 (" + String.format("%.2f", cgpa) + ")");
        }
        if (failed > 3) {
            reasons.add("More than 3 failed courses (" + failed + ")");
        }

        return new EligibilityStatus(student, cgpa, failed, eligible, reasons);
    }

    // convenience method for "Display Ineligible Students List"
    public List<EligibilityStatus> listIneligibleStudents() {
        List<EligibilityStatus> result = new ArrayList<>();
        for (Student s : studentRepo.findAll()) {
            EligibilityStatus status = check(s.getId());
            if (!status.isEligible()) {
                result.add(status);
            }
        }
        return result;
    }
}
