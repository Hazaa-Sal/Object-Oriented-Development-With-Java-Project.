package crs.service;

import crs.model.GradeRecord;
import crs.model.Student;
import crs.model.StudentReport;
import crs.repository.GradeRepository;
import crs.repository.StudentRepository;

import java.util.ArrayList;
import java.util.List;

public class DefaultReportService implements ReportService {

    private final StudentRepository studentRepo;
    private final GradeRepository gradeRepo;
    private final CgpaService cgpaService = new CgpaService();

    public DefaultReportService(StudentRepository studentRepo,
                                GradeRepository gradeRepo) {
        this.studentRepo = studentRepo;
        this.gradeRepo = gradeRepo;
    }

    @Override
    public StudentReport buildSemesterReport(String studentId,
                                             String semester,
                                             int year) {

        // 1) Load student from repository
        Student student = studentRepo.findById(studentId)
                .orElseThrow(() ->
                        new IllegalArgumentException("Student not found: " + studentId));

        // 2) Get all grades for this student
        List<GradeRecord> allGrades = gradeRepo.findByStudent(studentId);

        // 3) Filter grades for that specific semester + year
        List<GradeRecord> termGrades = new ArrayList<>();
        for (GradeRecord g : allGrades) {
            if (g.getSemester().equalsIgnoreCase(semester)
                    && g.getYear() == year) {
                termGrades.add(g);
            }
        }

        // 4) Compute cumulative CGPA over ALL grades
        double cumulativeCgpa = cgpaService.computeCgpa(allGrades);

        // 5) Build report object
        return new StudentReport(student, semester, year, termGrades, cumulativeCgpa);
    }
}
