package crs.service;

import crs.model.EligibilityStatus;

public interface EligibilityChecker {

    // check one student by ID and return full status
    EligibilityStatus check(String studentId);
}
