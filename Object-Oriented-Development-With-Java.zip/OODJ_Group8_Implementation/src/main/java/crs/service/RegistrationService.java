package crs.service;

import crs.model.EligibilityStatus;
import crs.repository.StudentRepository;

/**
 * Simple service to "allow registration" based on eligibility.
 * Right now it just prints to the console, but it can later
 * be extended to write to an enrolment file or database.
 */
public class RegistrationService {

    private final EligibilityChecker eligibilityChecker;
    private final StudentRepository studentRepo;

    public RegistrationService(EligibilityChecker eligibilityChecker,
                               StudentRepository studentRepo) {
        this.eligibilityChecker = eligibilityChecker;
        this.studentRepo = studentRepo;
    }

    /**
     * Try to register the student for the next semester.
     * Returns true if registration is allowed, false otherwise.
     */
    public boolean registerForNextSemester(String studentId) {
        EligibilityStatus status = eligibilityChecker.check(studentId);

        if (!status.isEligible()) {
            System.out.println("REGISTRATION RESULT:");
            System.out.println("  Student : " + status.getStudent().getFullName()
                    + " (" + status.getStudent().getId() + ")");
            System.out.println("  -> NOT ALLOWED to register for next semester.");
            System.out.println("  Reasons: " + status.getReasons());
            return false;
        }

        // Here you could write to a file like "enrolment.txt"
        // For now we just simulate success.
        System.out.println("REGISTRATION RESULT:");
        System.out.println("  Student : " + status.getStudent().getFullName()
                + " (" + status.getStudent().getId() + ")");
        System.out.println("  -> Registration for next semester ALLOWED.");
        return true;
    }
}
