package crs.service;

import crs.model.StudentReport;

public interface ReportService {

    // Build a performance report for one student, for a specific semester and year
    StudentReport buildSemesterReport(String studentId, String semester, int year);
}
